const QUESTIONS=[
{id:'l',category:'Linux',type:'single',q:'Quelle commande affiche les sockets réseau en écoute ?',c:['ls -l','ss -lntup','df -h','chmod 755'],a:1,e:'ss signifie socket statistics ; -l affiche les sockets en écoute.'},
{id:'d',category:'DNS / DHCP',type:'text',q:'Quel protocole permet de résoudre un nom de domaine en adresse IP ?',answers:['dns','domain name system'],display:'DNS',e:'DNS signifie Domain Name System.'},
{id:'a',category:'Active Directory',type:'text',q:'Description : « Rôle FSMO chargé d’allouer des pools d’identifiants relatifs aux contrôleurs de domaine. » Quel est son intitulé ?',answers:['rid master','relative id master','rid'],display:'RID Master',e:'Le RID Master attribue les pools de Relative IDs.'},
{id:'p',category:'Ports & protocoles',type:'single',q:'Quel port est utilisé par LDAPS ?',c:['389/TCP','636/TCP','53/UDP','443/TCP'],a:1,e:'LDAPS utilise TCP 636.'},
{id:'ip',category:'Réseaux',type:'text',q:'Calcul IPv4 : pour 192.168.50.130/26, saisis uniquement l’adresse de broadcast.',answers:['192.168.50.191'],display:'192.168.50.191',e:'Un /26 vaut 255.255.255.192 : bloc .128 à .191 ; réseau .128, première .129, dernière .190, broadcast .191.'},
{id:'bin',category:'Réseaux',type:'single',q:'Binaire vers décimal : 11000000 correspond à :',c:['128','160','192','224'],a:2,e:'128 + 64 = 192.'}
];