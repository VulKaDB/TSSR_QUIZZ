let pool=[],i=0,pick=null,mode='free',timer=null,remaining=0,matchRight=[],orderState=[],chronoSeconds=45;
let progress=JSON.parse(localStorage.getItem('tssr-progress')||'{}');
let mistakes=JSON.parse(localStorage.getItem('tssr-mistakes')||'{}');
let stats=JSON.parse(localStorage.getItem('tssr-stats')||'{}');
const app=document.querySelector('#app'),count=document.getElementById('count'),cats=[...new Set(Q.map(x=>x.cat))];
count.textContent=Q.length+' questions de cours';

// Mode sombre : applique la préférence mémorisée dès le chargement.
if(localStorage.getItem('tssr-dark')==='1')document.body.classList.add('dark');
function toggleDark(){document.body.classList.toggle('dark');localStorage.setItem('tssr-dark',document.body.classList.contains('dark')?'1':'0')}

// Nettoyage : retire de la progression et des erreurs sauvegardées les questions qui n'existent
// plus (renommées/supprimées lors d'une mise à jour de la banque de questions), pour que les
// compteurs "x/N" ne dépassent jamais le total actuel d'une catégorie.
(function cleanStoredData(){
  let validByCat={};
  Q.forEach(x=>{(validByCat[x.cat]=validByCat[x.cat]||new Set()).add(x.q)});
  let changedP=false,changedM=false;
  Object.keys(progress).forEach(cat=>{
    let valid=validByCat[cat]||new Set();
    let cleaned=[...new Set(progress[cat]||[])].filter(q=>valid.has(q));
    if(cleaned.length!==(progress[cat]||[]).length)changedP=true;
    progress[cat]=cleaned;
  });
  Object.keys(mistakes).forEach(cat=>{
    let valid=validByCat[cat]||new Set();
    let cleaned=[...new Set(mistakes[cat]||[])].filter(q=>valid.has(q));
    if(cleaned.length!==(mistakes[cat]||[]).length)changedM=true;
    mistakes[cat]=cleaned;
  });
  if(changedP)localStorage.setItem('tssr-progress',JSON.stringify(progress));
  if(changedM)localStorage.setItem('tssr-mistakes',JSON.stringify(mistakes));
})();

function shuffle(a){for(let j=a.length-1;j>0;j--){let k=Math.floor(Math.random()*(j+1));[a[j],a[k]]=[a[k],a[j]]}return a}
function norm(s){return String(s).trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,' ')}
function escAttr(s){return String(s).replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}
function escapeAttr(s){return escAttr(s)}
function escapeHtml(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;')}
function catProgress(c){let total=Q.filter(x=>x.cat===c).length,done=progress[c]?.length||0;return {total,done,pct:Math.min(100,Math.round(done/total*100))}}

// --- Outils de calcul IP (pour les exercices réseau à tirage aléatoire) ---
function ip2int(ip){return ip.split('.').reduce((acc,o)=>(acc*256)+Number(o),0)>>>0}
function int2ip(n){return [(n>>>24)&255,(n>>>16)&255,(n>>>8)&255,n&255].join('.')}
function subnetInfo(ipStr,prefix){
  let ip=ip2int(ipStr);
  let mask=prefix===0?0:(0xFFFFFFFF<<(32-prefix))>>>0;
  let network=(ip&mask)>>>0;
  let broadcast=(network|(~mask>>>0))>>>0;
  let first=prefix>=31?network:(network+1)>>>0;
  let last=prefix>=31?broadcast:(broadcast-1)>>>0;
  let hosts=prefix>=31?(prefix===32?1:2):(Math.pow(2,32-prefix)-2);
  return {mask:int2ip(mask),network:int2ip(network),broadcast:int2ip(broadcast),first:int2ip(first),last:int2ip(last),hosts:String(hosts)};
}
function randomIPv4(){let o1=Math.floor(Math.random()*222)+1;if(o1===127)o1=126;return [o1,Math.floor(Math.random()*256),Math.floor(Math.random()*256),Math.floor(Math.random()*256)].join('.')}
const IPRANDOM_LABELS={mask:"Masque en notation décimale",network:"Adresse réseau",broadcast:"Adresse de broadcast",first:"Première IP utilisable",last:"Dernière IP utilisable",hosts:"Nombre d'hôtes utilisables"};
function genIpExercise(x){
  if(!x._gen){
    let prefixes=x.prefixes||[24,25,26,27,28,29,30];
    let prefix=prefixes[Math.floor(Math.random()*prefixes.length)];
    let ip=randomIPv4();
    x._gen={ip,prefix,info:subnetInfo(ip,prefix)};
  }
  return x._gen;
}
function explainIpExercise(x){
  let {ip,prefix,info}=x._gen;
  let hostBits=32-prefix;
  let blockSize=Math.pow(2,hostBits);
  let lastOctet=Number(ip.split('.')[3]);
  let blockStart=Math.floor(lastOctet/blockSize)*blockSize;
  let blockEnd=blockStart+blockSize-1;
  return `Le préfixe /${prefix} laisse ${hostBits} bit${hostBits>1?'s':''} pour la partie hôte (32 − ${prefix} = ${hostBits}), soit des blocs de 2^${hostBits} = ${blockSize} adresses. Le masque correspondant est ${info.mask}. Dans ${ip}, le dernier octet vaut ${lastOctet} : cette valeur se situe dans le bloc [${blockStart}–${blockEnd}] du dernier octet. L'adresse réseau (début du bloc) est donc ${info.network}, et l'adresse de broadcast (fin du bloc) est ${info.broadcast}. La première IP utilisable est réseau + 1 = ${info.first}, la dernière est broadcast − 1 = ${info.last}, ce qui donne ${blockSize} − 2 = ${info.hosts} hôtes utilisables.`;
}

// --- Bilan de fin de série / revoir mes erreurs ---
function questionDisplayText(x){
  if(x.type==='iprandom'&&x._gen)return x.q.replace('{ip}',x._gen.ip).replace('{prefix}',x._gen.prefix);
  return x.q;
}
function expectedAnswerText(x){
  let type=x.type||'qcm';
  if(type==='qcm'||type==='scenario')return x.c[x.a];
  if(type==='text')return x.reponse||x.answer||'';
  if(type==='match')return x.pairs.map(p=>`${p.l} → ${p.r}`).join(' · ');
  if(type==='order')return x.items.join(' → ');
  if(type==='calculation')return x.fields.map(f=>`${f.label} : ${f.answer}`).join(' · ');
  if(type==='iprandom'){let info=(x._gen&&x._gen.info)||{};return x.ask.map(k=>`${IPRANDOM_LABELS[k]} : ${info[k]||'?'}`).join(' · ')}
  return '';
}
function getAcceptedAnswerValues(x){
  let values=[];
  let add=(arr)=>{(arr||[]).forEach(v=>{if(typeof v==='string'&&v.trim())values.push(v.trim())})};
  if(Array.isArray(x.acceptedAnswers))add(x.acceptedAnswers);
  if(x.answer)add([x.answer]);
  if(Array.isArray(x.accept))add(x.accept);
  if(x.reponse)add([x.reponse]);
  if(x.aliases&&typeof x.aliases==='object'){Object.values(x.aliases).forEach(v=>add(Array.isArray(v)?v:[v]))}
  return [...new Set(values)];
}
function getDisplayAnswerValues(x){
  let values=[];
  if(Array.isArray(x.displayAnswers))values.push(...x.displayAnswers.filter(v=>typeof v==='string'&&v.trim()));
  if(!values.length)values.push(...getAcceptedAnswerValues(x));
  return [...new Set(values.filter(Boolean))];
}
function answerMatchesQuestion(x,raw){
  if(x.type!=='text')return false;
  let value=norm(raw||'');
  if(!value)return false;
  return getAcceptedAnswerValues(x).map(norm).includes(value);
}
function mistakesCount(){return Object.values(mistakes).reduce((s,a)=>s+((a&&a.length)||0),0)}
function answeredCount(){return Object.values(progress).reduce((s,a)=>s+((a&&a.length)||0),0)}
function masteredCount(){return Math.max(0, answeredCount()-mistakesCount())}
function getDashboardStats(){
  let total=Q.length;
  let answered=answeredCount();
  let review=mistakesCount();
  let mastered=masteredCount();
  let success=total?Math.round((answered/total)*100):0;
  return {total,answered,review,mastered,success,lastScore:stats.lastScore||'—',lastPct:stats.lastPct!=null?`${stats.lastPct}%`:'—',runs:stats.completedRuns||0};
}
function startMistakes(){
  let list=[];
  Object.keys(mistakes).forEach(cat=>{(mistakes[cat]||[]).forEach(qtext=>{let found=Q.find(x=>x.cat===cat&&x.q===qtext);if(found)list.push(found)})});
  if(!list.length){home();return}
  mode='mistakes';
  currentSessionId=null;
  pool=buildPool(list);
  i=0;
  show();
}
function finishSeries(){
  clearSession();
  let total=pool.length;
  let correctCount=pool.filter(x=>x._ok===true).length;
  let missed=pool.filter(x=>x._ok===false);
  let pct=total?Math.round(correctCount/total*100):0;
  stats.completedRuns=(stats.completedRuns||0)+1;
  stats.lastScore=`${correctCount}/${total}`;
  stats.lastPct=pct;
  stats.bestPct=Math.max(stats.bestPct||0,pct);
  localStorage.setItem('tssr-stats',JSON.stringify(stats));
  let list=missed.map(x=>`<div class=review-item><p class=review-cat>${x.cat}</p><p class=review-q><b>${questionDisplayText(x)}</b></p><p class=review-a><strong>Réponse attendue :</strong> ${expectedAnswerText(x)}</p><p class=review-exp>${x.type==='iprandom'?explainIpExercise(x):x.exp}</p></div>`).join('');
  let mc=mistakesCount();
  app.innerHTML=`<section class=panel><h2>Série terminée</h2><div class=score-block><div class=score-number>${correctCount}/${total}</div><div class=progress><span style="width:${pct}%;--progress:${pct}"></span></div><p class=score-pct>${pct}% de bonnes réponses</p></div>${missed.length?`<h3>À revoir (${missed.length})</h3><div class=review-list>${list}</div>`:'<p class=perfect>Sans faute, bravo ! 🎉</p>'}<div class=actions>${mc>0?`<button class=primary onclick=startMistakes()>Revoir mes erreurs (${mc})</button>`:''}<button onclick=home()>Accueil</button></div></section>`;
}

// --- PWA : cache hors-ligne (aucun effet si le fichier est ouvert directement en file://) ---
if('serviceWorker' in navigator){
  window.addEventListener('load',()=>{navigator.serviceWorker.register('sw.js').catch(()=>{})});
}

// --- Raccourcis clavier : Entrée (valider/suivant), flèches (navigation), 1-4 (choix QCM) ---
document.addEventListener('keydown',function(e){
  if(!pool.length||i>=pool.length)return;
  if(e.target&&/^(INPUT|SELECT|TEXTAREA)$/.test(e.target.tagName)&&e.key!=='Enter')return;
  if(e.key==='Enter'){
    e.preventDefault();
    let vBtn=document.getElementById('btn-valider');
    if(vBtn&&!vBtn.disabled){vBtn.click();return}
    let sBtn=[...document.querySelectorAll('.actions button')].find(b=>b.textContent.includes('Suivante'));
    if(sBtn)sBtn.click();
  } else if(e.key==='ArrowRight'){
    let sBtn=[...document.querySelectorAll('.actions button')].find(b=>b.textContent.includes('Suivante'));
    if(sBtn)sBtn.click();
  } else if(e.key==='ArrowLeft'){
    let pBtn=[...document.querySelectorAll('.actions button')].find(b=>b.textContent.includes('Précédent'));
    if(pBtn)pBtn.click();
  } else if(['1','2','3','4'].includes(e.key)){
    let x=pool[i],type=x.type||'qcm';
    if(type==='qcm'||type==='scenario'){
      let idx=Number(e.key)-1;
      let btns=[...document.querySelectorAll('.ans')];
      if(btns[idx]&&!btns[idx].disabled)sel(idx,btns[idx]);
    }
  }
});

const SESSIONS_KEY='tssr-sessions';
const MAX_SESSIONS=10;
let currentSessionId=null;

// Migration douce : récupère l'ancienne sauvegarde mono-série (versions précédentes) si elle existe.
(function migrateOldSession(){
  let old=localStorage.getItem('tssr-session');
  if(!old)return;
  try{
    let s=JSON.parse(old);
    if(s&&Array.isArray(s.pool)&&s.pool.length&&typeof s.i==='number'&&s.i<s.pool.length){
      let sessions=JSON.parse(localStorage.getItem(SESSIONS_KEY)||'{}');
      let id='sess_'+Date.now()+'_migr';
      sessions[id]={mode:s.mode,pool:s.pool,i:s.i,chronoSeconds:s.chronoSeconds||45,savedAt:Date.now()};
      localStorage.setItem(SESSIONS_KEY,JSON.stringify(sessions));
    }
  }catch(e){}
  localStorage.removeItem('tssr-session');
})();

function newSessionId(){return 'sess_'+Date.now()+'_'+Math.random().toString(36).slice(2,8)}
function readSessions(){try{return JSON.parse(localStorage.getItem(SESSIONS_KEY)||'{}')}catch(e){return {}}}
function writeSessions(sessions){try{localStorage.setItem(SESSIONS_KEY,JSON.stringify(sessions))}catch(e){}}
function isValidSession(s){return s&&Array.isArray(s.pool)&&s.pool.length&&typeof s.i==='number'&&s.i<s.pool.length}
function getAllSessions(){
  let sessions=readSessions(),valid={},changed=false;
  Object.keys(sessions).forEach(id=>{if(isValidSession(sessions[id]))valid[id]=sessions[id];else changed=true});
  if(changed)writeSessions(valid);
  return valid;
}
function saveSession(){
  if(!currentSessionId)currentSessionId=newSessionId();
  let sessions=readSessions();
  sessions[currentSessionId]={mode,pool,i,chronoSeconds,savedAt:Date.now()};
  // Limite le nombre de séries mémorisées : on retire la plus ancienne au-delà de MAX_SESSIONS.
  let ids=Object.keys(sessions).sort((a,b)=>(sessions[a].savedAt||0)-(sessions[b].savedAt||0));
  while(ids.length>MAX_SESSIONS){let old=ids.shift();delete sessions[old]}
  writeSessions(sessions);
}
function clearSession(){
  if(currentSessionId){let sessions=readSessions();delete sessions[currentSessionId];writeSessions(sessions)}
  currentSessionId=null;
}
function clearAllSessions(){writeSessions({});currentSessionId=null}
function sessionLabel(s){
  let modeLabel={free:'Révision libre',chrono:'Mode chrono',exam:'Examen blanc',mistakes:'Revoir mes erreurs'}[s.mode]||'';
  let catsInPool=[...new Set(s.pool.map(q=>q.cat))];
  let catLabel=catsInPool.length===1?catsInPool[0]:catsInPool.length+' catégories';
  return modeLabel?`${modeLabel} · ${catLabel}`:catLabel;
}
function resumeSessionById(id){
  let sessions=readSessions(),s=sessions[id];
  if(!isValidSession(s)){home();return}
  currentSessionId=id;mode=s.mode;pool=s.pool;i=s.i;chronoSeconds=s.chronoSeconds||45;
  show();
}
function discardSessionById(id){
  let sessions=readSessions();delete sessions[id];writeSessions(sessions);
  if(id===currentSessionId)currentSessionId=null;
  home();
}
function resetProgress(){
  if(!confirm('Réinitialiser toute ta progression (toutes catégories, y compris les séries en cours) ? Cette action est irréversible.'))return;
  localStorage.removeItem('tssr-progress');
  localStorage.removeItem('tssr-mistakes');
  clearAllSessions();
  progress={};mistakes={};
  home();
}
// Filet de sécurité navigateur : prévient avant de fermer/rafraîchir la page si une série est en cours.
// (support variable sur mobile selon le navigateur — la sauvegarde de session ci-dessus reste la protection principale)
window.addEventListener('beforeunload',function(e){
  if(pool.length&&i<pool.length){e.preventDefault();e.returnValue=''}
});

function home(){
  clearInterval(timer);
  let sessions=getAllSessions();
  let ids=Object.keys(sessions).sort((a,b)=>(sessions[b].savedAt||0)-(sessions[a].savedAt||0));
  let resumeBanner='';
  if(ids.length){
    resumeBanner=`<div class=resume-wrap><h2>Série${ids.length>1?'s':''} en cours (${ids.length})</h2>${ids.map(id=>{
      let s=sessions[id];
      return `<div class=resume-banner><p><strong>${sessionLabel(s)}</strong> · question ${s.i+1}/${s.pool.length}.</p><p><button class=primary onclick="resumeSessionById('${id}')">Reprendre</button> <button onclick="discardSessionById('${id}')">Supprimer</button></p></div>`;
    }).join('')}</div>`;
  }
  let dash=getDashboardStats();
  app.innerHTML=`${resumeBanner}<section class="panel dashboard"><div class="dashboard-head"><div><h1>Révise, comprends, progresse.</h1><p class="bank-sub">Une vue rapide de ton niveau et des prochains points à travailler.</p></div><div class="pill">${dash.runs} série${dash.runs>1?'s':''} complétée${dash.runs>1?'s':''}</div></div><div class="stats-grid"><div class="stat-card"><span>Total de questions</span><strong>${dash.total}</strong></div><div class="stat-card"><span>Questions répondues</span><strong>${dash.answered}</strong></div><div class="stat-card"><span>À revoir</span><strong>${dash.review}</strong></div><div class="stat-card"><span>Maîtrisées</span><strong>${dash.mastered}</strong></div><div class="stat-card"><span>Taux de progression</span><strong>${dash.success}%</strong></div><div class="stat-card"><span>Dernier score</span><strong>${dash.lastScore}</strong></div></div></section><div class="section-separator" aria-hidden="true"></div><div class="grid modes-grid"><button class=tile onclick="setup('free')"><b>Révision libre</b><small>Choisis tes catégories · ordre aléatoire.</small></button><button class=tile onclick="setup('chrono')"><b>Mode chrono</b><small>Temps réglable par question.</small></button><button class=tile onclick="setup('exam')"><b>Examen blanc</b><small>Correction à la fin.</small></button><button class=tile onclick="showQuestionBank()"><b>Banque de questions</b><small>Consultez toutes les questions disponibles.</small></button><button class=tile onclick=memo()><b>Mémo / Annexes</b><small>Repères de révision.</small></button>${mistakesCount()>0?`<button class=tile onclick=startMistakes()><b>Revoir mes erreurs</b><small>${mistakesCount()} question(s) à retravailler.</small></button>`:''}</div><div class="section-separator" aria-hidden="true"></div><h2>Réviser par catégorie</h2><div class=grid>${cats.map(c=>{let p=catProgress(c);let hasMistakes=(mistakes[c]||[]).length>0;return `<div class="tile category-tile"><button class="category-main" onclick="startCat('${c}')"><b>${c}</b><small>${p.done}/${p.total} questions répondues</small><div class="progress"><span style="width:${p.pct}%;--progress:${p.pct}"></span></div></button>${hasMistakes?`<button class="category-action" onclick="event.stopPropagation();startCatMistakes('${c}')">Erreurs</button>`:''}</div>`}).join('')}</div><p class=reset-wrap><button class=link-btn onclick=resetProgress()>Réinitialiser toute ma progression</button></p>`;
}

function questionBankMatches(q,query,cat){
  let normalizedQuery=String(query||'').trim().toLowerCase();
  if(cat!=='all'&&q.cat!==cat)return false;
  if(!normalizedQuery)return true;
  let haystack=[q.cat,q.q,q.exp||'',...(Array.isArray(q.c)?q.c:[]),...(Array.isArray(q.pairs)?q.pairs.flatMap(p=>[p.l,p.r]):[]),...(Array.isArray(q.items)?q.items:[]),...(Array.isArray(q.fields)?q.fields.flatMap(f=>[f.label,f.answer]):[]),...(Array.isArray(q.ask)?q.ask:[]),q.reponse||''].join(' ').toLowerCase();
  return haystack.includes(normalizedQuery);
}

function renderQuestionBankItem(q,idx){
  let typeLabel={qcm:'QCM',scenario:'Scénario',text:'Réponse libre',match:'Association',order:'Ordre',calculation:'Calcul',iprandom:'IPv4'}[q.type||'qcm']||'Question';
  let details='';
  if(q.type==='qcm'||q.type==='scenario'){
    details=`<div class="bank-options">${(q.c||[]).map((opt,idx)=>`<div class="bank-option"><strong>${'ABCD'[idx]}.</strong><span>${escapeHtml(opt)}</span></div>`).join('')}</div>`;
  } else if(q.type==='match'){
    details=`<div class="bank-options">${(q.pairs||[]).map(p=>`<div class="bank-option"><strong>↔</strong><span>${escapeHtml(p.l)} → ${escapeHtml(p.r)}</span></div>`).join('')}</div>`;
  } else if(q.type==='order'){
    details=`<div class="bank-options">${(q.items||[]).map((item,idx)=>`<div class="bank-option"><strong>${idx+1}.</strong><span>${escapeHtml(item)}</span></div>`).join('')}</div>`;
  } else if(q.type==='calculation'){
    details=`<div class="bank-options">${(q.fields||[]).map(f=>`<div class="bank-option"><strong>•</strong><span>${escapeHtml(f.label)} : ${escapeHtml(f.answer)}</span></div>`).join('')}</div>`;
  } else if(q.type==='text'){
    details=`<p class="bank-answer"><strong>Réponse attendue :</strong> ${escapeHtml(q.reponse||'')}</p>`;
  } else if(q.type==='iprandom'){
    details=`<p class="bank-answer"><strong>Réponse attendue :</strong> ${escapeHtml((q.ask||[]).join(' · '))}</p>`;
  }
  let cardId=`bank-card-${idx}`;
  return `<article id="${cardId}" class="bank-card"><div class="bank-meta"><span class="bank-cat">${escapeHtml(q.cat)}</span><span class="bank-type">${escapeHtml(typeLabel)}</span></div><h3>${escapeHtml(q.q)}</h3><div class="bank-actions"><button class="bank-toggle" type="button" onclick="toggleQuestionBankCard('${cardId}')">Afficher la réponse</button></div><div class="bank-details" hidden>${details}${q.exp?`<p class="bank-exp">${escapeHtml(q.exp)}</p>`:''}</div></article>`;
}
function toggleQuestionBankCard(id){
  let card=document.getElementById(id);
  if(!card)return;
  let details=card.querySelector('.bank-details');
  let btn=card.querySelector('.bank-toggle');
  if(!details||!btn)return;
  let opened=!details.hidden;
  details.hidden=opened;
  btn.textContent=opened?'Afficher la réponse':'Masquer la réponse';
}
function filterQuestionBank(){
  let query=document.getElementById('bank-search')?.value||'';
  let cat=document.getElementById('bank-cat')?.value||'all';
  let items=Q.filter(q=>questionBankMatches(q,query,cat));
  let list=document.getElementById('bank-list');
  let count=document.getElementById('bank-count');
  if(!list)return;
  if(!items.length){list.innerHTML='<p class="bank-empty">Aucune question ne correspond à votre recherche.</p>';if(count)count.textContent='0 / 0 questions';return}
  list.innerHTML=items.map((q,idx)=>renderQuestionBankItem(q,idx)).join('');
  if(count)count.textContent=`${items.length} / ${Q.length} question${items.length>1?'s':''} affichée${items.length>1?'s':''}`;
}
function showQuestionBank(){
  clearInterval(timer);
  let categories=[...new Set(Q.map(x=>x.cat))].sort();
  let categoryOptions=categories.map(c=>`<option value="${escAttr(c)}">${escapeHtml(c)}</option>`).join('');
  app.innerHTML=`<section class="panel"><div class="bank-head"><div><h2>Banque de questions</h2><p class="bank-sub">Consultez l'ensemble des questions sans lancer de partie.</p></div><button onclick="home()">Retour</button></div><div class="bank-controls"><input id="bank-search" class="bank-filter" type="text" autocomplete="off" placeholder="Rechercher une question" oninput="filterQuestionBank()"><select id="bank-cat" class="bank-filter" onchange="filterQuestionBank()"><option value="all">Toutes les catégories</option>${categoryOptions}</select></div><p id="bank-count" class="bank-count"></p><div id="bank-list" class="bank-list"></div></section>`;
  filterQuestionBank();
}

function setup(m){mode=m;let checks=cats.map(c=>`<label><input type=checkbox class=catpick value="${c}" autocomplete="off"> ${c}</label>`).join('<br>');app.innerHTML=`<section class=panel><h2>${m==='chrono'?'Mode chrono':m==='exam'?'Examen blanc':'Sélection des catégories'}</h2>${m==='chrono'?`<label>Secondes par question : <input id=time type=number min=5 value=45></label><hr>`:''}${m==='exam'?`<label>Nombre de questions : <input id=examCount type=number min=1 value=40></label><hr>`:''}<p><label><input id=allcats type=checkbox autocomplete="off" onchange="document.querySelectorAll('.catpick').forEach(x=>x.checked=this.checked)"> Toutes les catégories</label></p><div>${checks}</div><p><button class=primary onclick=startAll()>Commencer</button> <button onclick=home()>Retour</button></p></section>`;document.getElementById('allcats').checked=false;document.querySelectorAll('.catpick').forEach(x=>x.checked=false)}

// Prépare un lot : mélange les choix des QCM/scenario, laisse les autres types intacts
function buildPool(list){return shuffle(list.map(x=>{let t=x.type||'qcm';if(t==='qcm'||t==='scenario'){let o=shuffle(x.c.map((v,n)=>({v,ok:n===x.a})));return {...x,c:o.map(z=>z.v),a:o.findIndex(z=>z.ok)}}return {...x}}))}
function startAll(){let selected=[...document.querySelectorAll('.catpick:checked')].map(x=>x.value);if(!selected.length){alert('Sélectionne au moins une catégorie.');return}if(mode==='chrono'){chronoSeconds=Number(document.getElementById('time')?.value)||45}currentSessionId=null;pool=buildPool(Q.filter(x=>selected.includes(x.cat)));if(mode==='exam'){let n=Number(document.getElementById('examCount')?.value)||40;pool=pool.slice(0,n)}i=0;show()}
function startCat(c){clearInterval(timer);mode='cat';currentSessionId=null;pool=buildPool(Q.filter(x=>x.cat===c));i=0;show()}

function renderOrderItems(x){return orderState.map((idx,pos)=>`<li><span class=order-pos>${pos+1}</span><span class=order-txt>${x.items[idx]}</span><span class=order-btns><button type=button onclick="orderMove(${pos},-1)" ${pos===0?'disabled':''}>▲</button><button type=button onclick="orderMove(${pos},1)" ${pos===orderState.length-1?'disabled':''}>▼</button></span></li>`).join('')}
function orderMove(pos,dir){let np=pos+dir;if(np<0||np>=orderState.length)return;[orderState[pos],orderState[np]]=[orderState[np],orderState[pos]];document.getElementById('order-list').innerHTML=renderOrderItems(pool[i])}

function getCurrentProgressMeta(){
  if(!pool.length)return {current:0,total:0,score:0};
  let answered=pool.slice(0,i).filter(x=>x._ok!==undefined).length;
  let correct=pool.slice(0,i).filter(x=>x._ok===true).length;
  let total=pool.length;
  return {current:i+1,total,score:answered?Math.round(correct/answered*100):0,correct,answered};
}
function show(){
  clearInterval(timer);
  if(i>=pool.length){finishSeries();return}
  saveSession();
  pick=null;
  let x=pool[i],type=x.type||'qcm',chrono=mode==='chrono';
  let meta=getCurrentProgressMeta();
  let body='';
  if(type==='qcm'||type==='scenario'){
    body=`<h2>${x.q}</h2><div class=answers>${x.c.map((z,n)=>`<button class=ans onclick="sel(${n},this)">${'ABCD'[n]}. ${z}</button>`).join('')}</div>`;
  } else if(type==='text'){
    body=`<h2>${x.q}</h2><div class=answers><input id=txt type=text autocomplete=off placeholder="Ta réponse"></div>`;
  } else if(type==='match'){
    matchRight=shuffle(x.pairs.map((p,idx)=>({text:p.r,idx})));
    body=`<h2>${x.q}</h2><div class=match-grid>${x.pairs.map((p,li)=>`<div class=match-row><span class=match-left>${p.l}</span><select class=match-sel><option value="">— choisir —</option>${matchRight.map(r=>`<option value="${escAttr(r.text)}">${r.text}</option>`).join('')}</select></div>`).join('')}</div>`;
  } else if(type==='order'){
    let disp=shuffle(x.items.map((t,idx)=>({t,idx})));
    orderState=disp.map(d=>d.idx);
    body=`<h2>${x.q}</h2><ol id=order-list class=order-list>${renderOrderItems(x)}</ol>`;
  } else if(type==='calculation'){
    body=`<h2>${x.q}</h2><div class=calc-grid>${x.fields.map(f=>`<label>${f.label}<input class=calc-in type=text autocomplete=off></label>`).join('')}</div>`;
  } else if(type==='iprandom'){
    let {ip,prefix,info}=genIpExercise(x);
    let qText=x.q.replace('{ip}',ip).replace('{prefix}',prefix);
    body=`<h2>${qText}</h2><div class=calc-grid>${x.ask.map(k=>`<label>${IPRANDOM_LABELS[k]}<input class=calc-in data-k=${k} type=text autocomplete=off></label>`).join('')}</div>`;
  }
  app.innerHTML=`<section class=panel><div class="question-top"><div><p class="question-meta">${x.cat} · question ${i+1}/${pool.length}</p><div class="progress-pill">Score : ${meta.correct}/${meta.answered || 0}</div></div>${chrono?`<div class="timer-pill" id=timer>—</div>`:''}</div><div class="progress-strip"><span style="width:${Math.round((i+1)/pool.length*100)}%;--progress:${Math.round((i+1)/pool.length*100)}"></span></div>${body}<div class=actions>${i>0?'<button onclick="i--;show()">◀ Précédent</button>':''}<button class=primary id=btn-valider onclick=check()>Valider</button></div><div id=f></div></section>`;
  if(chrono){remaining=chronoSeconds;let el=document.getElementById('timer');el.textContent=remaining+' s';timer=setInterval(()=>{remaining--;el.textContent=remaining+' s';if(remaining<=0){clearInterval(timer);check(true)}},1000)}
}

function sel(n,e){pick=n;document.querySelectorAll('.ans').forEach(x=>x.classList.remove('chosen'));e.classList.add('chosen')}

function check(timeout=false){
  clearInterval(timer);
  let x=pool[i],type=x.type||'qcm',ok=false,attendu='';
  if(type==='qcm'||type==='scenario'){
    if(pick===null&&!timeout)return;
    ok=!timeout&&pick===x.a;
    attendu=x.c[x.a];
    document.querySelectorAll('.ans').forEach(b=>b.disabled=true);
  } else if(type==='text'){
    let el=document.getElementById('txt'),val=el.value;
    if(!val.trim()&&!timeout)return;
    let accepted=getAcceptedAnswerValues(x).map(norm);
    ok=!timeout&&accepted.includes(norm(val));
    attendu=getDisplayAnswerValues(x).join(' · ');
    el.disabled=true;
  } else if(type==='match'){
    let sels=[...document.querySelectorAll('.match-sel')];
    if(sels.some(s=>s.value==='')&&!timeout)return;
    ok=!timeout&&sels.every((s,li)=>norm(s.value)===norm(x.pairs[li].r));
    attendu=x.pairs.map(p=>`${p.l} → ${p.r}`).join(' · ');
    sels.forEach(s=>s.disabled=true);
  } else if(type==='order'){
    ok=!timeout&&orderState.every((idx,pos)=>idx===pos);
    attendu=x.items.join(' → ');
    document.querySelectorAll('#order-list button').forEach(b=>b.disabled=true);
  } else if(type==='calculation'){
    let ins=[...document.querySelectorAll('.calc-in')];
    if(ins.some(inp=>!inp.value.trim())&&!timeout)return;
    ok=!timeout&&x.fields.every((f,n)=>norm(ins[n].value)===norm(f.answer));
    attendu=x.fields.map(f=>`${f.label} : ${f.answer}`).join(' · ');
    ins.forEach(inp=>inp.disabled=true);
  } else if(type==='iprandom'){
    let ins=[...document.querySelectorAll('.calc-in')];
    if(ins.some(inp=>!inp.value.trim())&&!timeout)return;
    let info=x._gen.info;
    ok=!timeout&&x.ask.every((k,n)=>norm(ins[n].value)===norm(info[k]));
    attendu=x.ask.map(k=>`${IPRANDOM_LABELS[k]} : ${info[k]}`).join(' · ');
    ins.forEach(inp=>inp.disabled=true);
  }
  x._ok=ok;
  let feedbackClass=ok?'good':'bad';
  if(!progress[x.cat])progress[x.cat]=[];
  if(!progress[x.cat].includes(x.q)){progress[x.cat].push(x.q);localStorage.setItem('tssr-progress',JSON.stringify(progress));}
  if(!mistakes[x.cat])mistakes[x.cat]=[];
  if(ok){
    let mi=mistakes[x.cat].indexOf(x.q);
    if(mi>-1){mistakes[x.cat].splice(mi,1);localStorage.setItem('tssr-mistakes',JSON.stringify(mistakes));}
  } else if(!mistakes[x.cat].includes(x.q)){
    mistakes[x.cat].push(x.q);
    localStorage.setItem('tssr-mistakes',JSON.stringify(mistakes));
  }
  if(mode==='exam'){
    f.innerHTML=`<div class="feedback exam-pending"><b>Réponse enregistrée.</b><p>Correction et score complets à la fin de l'examen.</p></div>`;
  } else {
    let expText=type==='iprandom'?explainIpExercise(x):x.exp;
    let answerBlock='';
    if(type==='text'){
      let answers=getDisplayAnswerValues(x);
      if(answers.length){
        let label=answers.length>1?'Réponses acceptées':'Réponse attendue';
        let list=answers.map(v=>`<li>${escapeHtml(v)}</li>`).join('');
        answerBlock=`<div class="answer-feedback-block"><p><strong>${label} :</strong></p><ul class="answer-feedback-list">${list}</ul></div>`;
      }
    } else {
      answerBlock=`<p><strong>Réponse attendue : ${attendu}</strong></p>`;
    }
    f.innerHTML=`<div class="feedback ${feedbackClass}"><b>${ok?'✅ Bonne réponse':timeout?'Temps écoulé':'❌ Réponse incorrecte'}</b>${answerBlock}<p>${expText}</p></div>`;
  }
  let btnV=document.getElementById('btn-valider');
  btnV.disabled=true;
  btnV.insertAdjacentHTML('afterend','<button class=primary onclick="i++;show()">Suivante</button>');
}

const MEMO_GUIDE=[
  {id:'linux',title:'Linux',intro:'Linux est le socle de nombreux environnements serveur, réseau et automatisation. Il faut savoir le manipuler, l’auditer et le sécuriser.',badge:'Système',blocks:[{title:'Définition et rôle',items:['Linux est un système d’exploitation basé sur un noyau libre, utilisé pour les serveurs, postes, conteneurs et outils d’automatisation.','Le rôle principal est d’abstraire le matériel et de fournir un environnement stable pour exécuter des services et des scripts.']},{title:'Fonctionnement',items:['Le shell interprète les commandes; le noyau gère processus, mémoire, fichiers et périphériques.','Les permissions reposent sur l’utilisateur, le groupe et les droits r, w, x.']},{title:'Cas d’usage',items:['Administration de serveurs, déploiement automatisé, journaux, sécurité et maintenance.','Très utilisé pour les services web, bases de données, conteneurs et environnements cloud.']},{title:'Avantages, limites et erreurs fréquentes',items:['Avantages : stabilité, polyvalence, forte automatisation, grande communauté.','Limites : apprentissage plus long et parfois moins intuitif pour les débutants.','Erreurs fréquentes : lancer une commande sans vérifier sa portée, oublier sudo, mal gérer les permissions.']},{title:'Exemples concrets',items:['ls -l pour voir les permissions, chmod 700 script.sh pour restreindre un script, systemctl status ssh pour vérifier un service, tail -f /var/log/syslog pour consulter un journal.']}]},
  {id:'binaire',title:'Binaire & logique',intro:'La logique binaire permet de comprendre comment un ordinateur traite les informations, les comparaisons et les décisions.',badge:'Fondamentaux',blocks:[{title:'Définition et rôle',items:['Le binaire représente toutes les informations sous forme de 0 et de 1.','La logique booleenne permet de combiner des conditions et de construire des règles de calcul et de décision.']},{title:'Fonctionnement',items:['Une valeur binaire est un bit; 8 bits forment un octet.','Les portes logiques ET, OU, NON et XOR servent à créer des circuits et à résoudre des conditions.']},{title:'Cas d’usage',items:['Adressage réseau, masquage de bits, contrôle d’accès, tests de configuration, opérations arithmétiques et booléennes.','Très utile pour comprendre les bases des systèmes et des protocoles.']},{title:'Avantages, limites et erreurs fréquentes',items:['Avantages : simplicité, précision, compréhension des mécanismes internes.','Limites : peu intuitif si on ne travaille pas régulièrement avec les bases.','Erreurs fréquentes : confondre OR et XOR, oublier les valeurs de vérité, mal lire les bits.']},{title:'Exemples concrets',items:['10 en binaire vaut 1010, 1 AND 0 = 0, 1 OR 0 = 1, NOT 1 = 0.']}]},
  {id:'reseaux',title:'Réseaux & IPv4',intro:'Le réseau permet de relier des machines et de transmettre des données selon des règles précises.',badge:'Réseau',blocks:[{title:'Définition et rôle',items:['Un réseau relie des équipements pour partager des ressources, des données et des services.','IPv4 identifie chaque hôte par une adresse codée sur 32 bits.']},{title:'Fonctionnement',items:['Le masque de sous-réseau sépare la partie réseau et la partie hôte.','Les routeurs et commutateurs orientent les trames et les paquets selon les tables et les règles.']},{title:'Cas d’usage',items:['Adressage des postes, segmentation des sous-réseaux, accès à Internet, communication entre services.','Indispensable pour comprendre les notions de routage, DNS et sous-réseau.']},{title:'Avantages, limites et erreurs fréquentes',items:['Avantages : standardisation, flexibilité, possibilité de segmentation.','Limites : gestion plus complexe à grande échelle et besoin de planification.','Erreurs fréquentes : confondre adresse réseau et adresse hôte, oublier le masque, négliger la passerelle.']},{title:'Exemples concrets',items:['Un réseau /24 offre 256 adresses, dont 254 utilisables en pratique.','ip addr permet d’inspecter une adresse IP, ping teste la connectivité, route -n affiche le routage.']}]},
  {id:'ports',title:'Ports & protocoles',intro:'Les ports et les protocoles structurent la communication réseau entre services.',badge:'Communication',blocks:[{title:'Définition et rôle',items:['Un port identifie un service logique sur une machine donnée.','Un protocole définit les règles de syntaxe et d’échange entre deux entités.']},{title:'Fonctionnement',items:['TCP garantit la fiabilité de l’échange, UDP privilégie la rapidité.','HTTP, HTTPS, DNS, FTP, SSH, SMTP et SMB sont des protocoles courants selon le service.']},{title:'Cas d’usage',items:['Vérifier un service ouvert, diagnostiquer un accès, sécuriser un flux, savoir quel port est attendu.','Essentiel pour les audits, la supervision et le dépannage réseau.']},{title:'Avantages, limites et erreurs fréquentes',items:['Avantages : séparation claire des services et standardisation des échanges.','Limites : certains protocoles sont plus sensibles aux erreurs ou aux failles.','Erreurs fréquentes : croire qu’un port fermé signifie forcément un problème, ou confondre un service et son protocole.']},{title:'Exemples concrets',items:['80 = HTTP, 443 = HTTPS, 22 = SSH, 53 = DNS, 3389 = RDP.']}]},
  {id:'windows',title:'Windows Server & Active Directory',intro:'Windows Server et Active Directory centralisent la gestion des utilisateurs, des postes et des politiques de sécurité.',badge:'Windows',blocks:[{title:'Définition et rôle',items:['Windows Server fournit une plateforme d’administration de services, de postes et d’infrastructures.','Active Directory stocke les objets de domaine et les relations d’identité.']},{title:'Fonctionnement',items:['Les utilisateurs, groupes et ordinateurs sont des objets gérés par le domaine.','Les GPO appliquent des règles de sécurité et de configuration aux postes.']},{title:'Cas d’usage',items:['Gestion centralisée des comptes, déploiement de politiques, authentification et autorisation.','Très utile dans les environnements d’entreprise.']},{title:'Avantages, limites et erreurs fréquentes',items:['Avantages : gestion centralisée, intégration forte avec les environnements Microsoft.','Limites : coût, dépendance à l’écosystème Microsoft et besoin de compétences spécifiques.','Erreurs fréquentes : oublier la planification du nom de domaine, négliger les droits de groupe ou les GPO.']},{title:'Exemples concrets',items:['Get-ADUser permet d’inspecter un compte, gpupdate /force applique une GPO, dsquery retrouve un objet AD.']}]},
  {id:'wifi',title:'Wi-Fi',intro:'Le Wi-Fi permet d’accéder à un réseau local sans fil, mais il exige une bonne conception et une bonne sécurité.',badge:'Sans fil',blocks:[{title:'Définition et rôle',items:['Le Wi-Fi transmet des données par radio selon des normes comme 802.11.','Il sert à connecter des postes, téléphones et équipements mobiles à une infrastructure réseau.']},{title:'Fonctionnement',items:['Le SSID identifie le réseau; l’authentification et le chiffrement protègent les échanges.','La qualité du signal dépend de l’environnement, de la fréquence et de l’interférence.']},{title:'Cas d’usage',items:['Réseaux de bureau, points d’accès d’entreprise, zones de travail, sites temporaires.']},{title:'Avantages, limites et erreurs fréquentes',items:['Avantages : simplicité de déploiement et mobilité.','Limites : sensibilité aux interférences et à la sécurité si la configuration est faible.','Erreurs fréquentes : utiliser un mot de passe faible, laisser un SSID trop permissif, oublier la segmentation.']},{title:'Exemples concrets',items:['WPA2/WPA3 sont à privilégier, un point d’accès mal configuré peut exposer toute la zone.']}]},
  {id:'virtualisation',title:'Virtualisation & Cloud',intro:'La virtualisation découpe un matériel physique en environnements isolés, puis le cloud exploite cette capacité de façon flexible.',badge:'Infrastructure',blocks:[{title:'Définition et rôle',items:['La virtualisation crée des machines virtuelles ou des conteneurs au-dessus d’un hyperviseur ou d’un moteur de runtime.','Le cloud fournit des ressources à la demande, souvent via des services gérés.']},{title:'Fonctionnement',items:['Un hyperviseur de type 1 tourne directement sur le matériel, un type 2 au-dessus d’un système existant.','Les snapshots et images facilitent la sauvegarde, la reprise et la duplication.']},{title:'Cas d’usage',items:['Serveurs de production, labo, environnement de test, montée en charge et déploiement rapide.']},{title:'Avantages, limites et erreurs fréquentes',items:['Avantages : isolation, rapidité de déploiement, meilleure gestion des ressources.','Limites : consommation de ressources et besoin de supervision.','Erreurs fréquentes : oublier la sécurité, utiliser des snapshots comme unique sauvegarde, sous-dimensionner les ressources.']},{title:'Exemples concrets',items:['VMware, Hyper-V, Proxmox, Docker et Azure sont des exemples courants.']}]},
  {id:'bash',title:'Bash & PowerShell',intro:'Bash et PowerShell sont des langages de script essentiels pour automatiser des tâches et des opérations de maintenance.',badge:'Automatisation',blocks:[{title:'Définition et rôle',items:['Bash est utilisé principalement sur Linux et Unix; PowerShell sur Windows et les environnements Microsoft.','Ils servent à automatiser, contrôler et vérifier des configurations.']},{title:'Fonctionnement',items:['Un script exécute une suite de commandes, conditionnelles et boucles.','La robustesse d’un script dépend de la gestion des erreurs et des variables.']},{title:'Cas d’usage',items:['Déploiement, maintenance, création de rapports, vérification de services et traitement de fichiers.']},{title:'Avantages, limites et erreurs fréquentes',items:['Avantages : gain de temps, reproductibilité, réduction des erreurs manuelles.','Limites : scripts parfois peu lisibles si la logique est mal structurée.','Erreurs fréquentes : oublier les quotes, mal gérer les chemins, ne pas tester en environnement limité.']},{title:'Exemples concrets',items:['for i in $(seq 1 5); do echo $i; done en bash, Get-Service | Where-Object {$_.Status -eq "Running"} en PowerShell.']}]},
  {id:'securite',title:'Firewall, VPN & sécurité',intro:'La sécurité réseau protège les accès, limite les risques et garantit la confidentialité des échanges.',badge:'Sécurité',blocks:[{title:'Définition et rôle',items:['Un pare-feu filtre les flux entrants et sortants selon des règles de sécurité.','Un VPN crée un tunnel chiffré pour relier des sites ou des utilisateurs à distance.']},{title:'Fonctionnement',items:['Les règles de filtrage autorisent ou bloquent des ports, des IP ou des protocoles.','Le chiffrement et l’authentification sécurisent les communications et réduisent les risques d’écoute.']},{title:'Cas d’usage',items:['Sécuriser un accès distant, protéger un réseau d’entreprise, limiter les services exposés à Internet.']},{title:'Avantages, limites et erreurs fréquentes',items:['Avantages : meilleure protection, confinement des accès, contrôle centralisé.','Limites : configuration complexe et risque d’ouvrir trop de services.','Erreurs fréquentes : conserver des règles obsolètes, oublier la surveillance ou utiliser des protocoles faibles.']},{title:'Exemples concrets',items:['Un pare-feu bloque les ports inutiles, un VPN permet de joindre un réseau distant sans exposer les services directement.']}]},
  {id:'sauvegardes',title:'Sauvegardes & restauration',intro:'Une bonne stratégie de sauvegarde protège les données, la continuité du service et la capacité à récupérer rapidement.',badge:'Continuité',blocks:[{title:'Définition et rôle',items:['La sauvegarde copie des données pour les protéger contre la perte, la corruption ou la suppression.','La restauration permet de remettre un système ou des fichiers dans un état exploitable.']},{title:'Fonctionnement',items:['La règle 3-2-1 préconise 3 copies, 2 supports différents, 1 copie hors site.','Le RPO et le RTO définissent la fréquence de sauvegarde et le temps de reprise.']},{title:'Cas d’usage',items:['Sauvegarder des données sensibles, restaurer un poste ou un serveur, préparer un plan de continuité.']},{title:'Avantages, limites et erreurs fréquentes',items:['Avantages : protection contre les pannes, les erreurs humaines et les incidents.','Limites : stockage coûteux et besoin de tests réguliers.','Erreurs fréquentes : ne jamais tester une restauration, sauvegarder trop peu souvent, ne pas protéger les copies hors site.']},{title:'Exemples concrets',items:['Une sauvegarde quotidienne de fichiers critiques et une restauration testée toutes les semaines.']}]},
  {id:'deploiement',title:'Déploiement de postes',intro:'Le déploiement de postes consiste à installer, configurer et maintenir rapidement plusieurs machines de façon homogène.',badge:'Administration',blocks:[{title:'Définition et rôle',items:['Le déploiement de postes prépare et fournit un poste prêt à l’emploi selon une image ou un script standard.','Il réduit les interventions manuelles et standardise la configuration.']},{title:'Fonctionnement',items:['Une image système, un script d’installation ou un outil de gestion centralisé permet de créer un poste reflétant les standards de l’entreprise.','L’automatisation évite les écarts entre machines.']},{title:'Cas d’usage',items:['Mise en place d’un parc informatique, remplacement d’un poste, création d’environnements de test.']},{title:'Avantages, limites et erreurs fréquentes',items:['Avantages : rapidité, homogénéité, meilleure traçabilité.','Limites : besoin de préparation et de maintenance des images.','Erreurs fréquentes : oublier les pilotes, les logiciels spécifiques ou la phase de validation.']},{title:'Exemples concrets',items:['Créer une image Windows avec les pilotes et les logiciels métier, puis la déployer à plusieurs postes.']}]},
  {id:'support',title:'Support & méthodologie',intro:'Le support technique repose sur une méthode claire pour comprendre un problème, collecter des informations et résoudre efficacement.',badge:'Méthode',blocks:[{title:'Définition et rôle',items:['Le support aide les utilisateurs à résoudre des incidents ou à répondre à des demandes de service.','Une bonne méthode évite les erreurs, accélère le diagnostic et améliore la qualité du service.']},{title:'Fonctionnement',items:['Le cycle de vie d’un ticket comprend qualification, priorisation, diagnostic, résolution et clôture.','Le SLA fixe les délais de réponse et les niveaux de service attendus.']},{title:'Cas d’usage',items:['Incident réseau, problème logiciel, demande d’accès, panne matérielle ou question d’utilisateur.']},{title:'Avantages, limites et erreurs fréquentes',items:['Avantages : traçabilité, meilleure communication, résolution plus rapide.','Limites : les processus peuvent sembler lourds si l’on ne les applique pas avec discernement.','Erreurs fréquentes : oublier la reproduction du problème, ne pas tracer la résolution ou mal hiérarchiser l’urgence.']},{title:'Exemples concrets',items:['Un ticket de panne d’impression passe par collecte du symptôme, vérification du poste, test réseau puis résolution et clôture.']}]}
];
function filterMemoSections(query){
  let normalized=norm(query||'');
  let cards=[...document.querySelectorAll('.memo-card')];
  let visibleCards=0;
  cards.forEach(card=>{
    let text=String(card.dataset.search||'');
    let visible=!normalized||text.includes(normalized);
    card.style.display=visible?'block':'none';
    if(visible)visibleCards++;
  });
  let count=document.getElementById('memo-count');
  if(count)count.textContent=`${visibleCards} / ${cards.length} section${cards.length>1?'s':''} affichée${visibleCards>1?'s':''}`;
}
function memo(){clearInterval(timer);let sections=MEMO_GUIDE.map(section=>{
  let blocks=(section.blocks||[]).map(block=>`<div class="memo-block"><h4>${escapeHtml(block.title)}</h4><ul class="memo-list">${(block.items||[]).map(item=>`<li>${escapeHtml(item)}</li>`).join('')}</ul></div>`).join('');
  let searchText=[section.title,section.intro,...(section.blocks||[]).flatMap(block=>block.items||[])].join(' ');
  return `<article id="${section.id}" class="bank-card memo-card" data-search="${escapeAttr(searchText.toLowerCase())}"><div class="bank-meta"><span class="bank-cat">Mémo</span><span class="bank-type">${escapeHtml(section.badge||'À retenir')}</span></div><h3>${escapeHtml(section.title)}</h3><p class="memo-intro">${escapeHtml(section.intro)}</p><div class="memo-details">${blocks}</div></article>`;
}).join('');
  app.innerHTML=`<section class="panel"><div class="bank-head"><div><h2>Mémo / Annexes</h2><p class="bank-sub">Un support de révision intégré au quiz, rapide à consulter et pensé pour l’apprentissage.</p></div><button onclick=home()>Retour</button></div><div class="bank-controls"><input id="memo-search" class="bank-filter" type="text" autocomplete="off" placeholder="Rechercher dans le mémo" oninput="filterMemoSections(this.value)"></div><p id="memo-count" class="bank-count"></p><div id="memo-list" class="bank-list">${sections}</div></section>`;
  filterMemoSections(document.getElementById('memo-search')?.value||'');
}
home();
