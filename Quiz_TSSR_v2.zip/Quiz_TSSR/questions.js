const Q=[
  {
    "cat": "Linux",
    "type": "match",
    "q": "Relie chaque commande à son rôle.",
    "pairs": [
      {
        "l": "pwd",
        "r": "affiche le répertoire de travail courant"
      },
      {
        "l": "ls",
        "r": "liste le contenu d'un répertoire"
      },
      {
        "l": "cd",
        "r": "change de répertoire courant"
      },
      {
        "l": "mkdir",
        "r": "crée un nouveau répertoire"
      }
    ],
    "exp": "pwd (print working directory) situe l'utilisateur dans l'arborescence, ls liste les fichiers d'un dossier, cd change le dossier courant, et mkdir en crée un nouveau. Ce sont les commandes de base de navigation dans un système Linux."
  },
  {
    "cat": "Linux",
    "type": "match",
    "q": "Relie chaque commande de gestion de fichiers à son rôle.",
    "pairs": [
      {
        "l": "cp",
        "r": "copie un fichier ou un répertoire"
      },
      {
        "l": "mv",
        "r": "déplace ou renomme un fichier"
      },
      {
        "l": "rm",
        "r": "supprime un fichier"
      },
      {
        "l": "touch",
        "r": "crée un fichier vide ou met à jour sa date"
      }
    ],
    "exp": "cp duplique un fichier à un autre emplacement, mv le déplace (et sert aussi à renommer, car renommer revient à déplacer dans le même dossier sous un autre nom), rm le supprime définitivement, et touch crée un fichier vide ou rafraîchit son horodatage sans modifier son contenu."
  },
  {
    "cat": "Linux",
    "type": "match",
    "q": "Relie chaque commande de lecture de fichier à son rôle.",
    "pairs": [
      {
        "l": "cat",
        "r": "affiche tout le contenu d'un fichier d'un coup"
      },
      {
        "l": "less",
        "r": "affiche un fichier page par page"
      },
      {
        "l": "head",
        "r": "affiche les premières lignes d'un fichier"
      },
      {
        "l": "tail",
        "r": "affiche les dernières lignes d'un fichier"
      }
    ],
    "exp": "cat convient aux petits fichiers car il affiche tout sans pagination ; less pagine un gros fichier pour le parcourir confortablement ; head et tail permettent de voir uniquement le début ou la fin, très utile pour les fichiers de log qui grossissent en continu."
  },
  {
    "cat": "Linux",
    "type": "match",
    "q": "Relie chaque commande de gestion des droits à son rôle.",
    "pairs": [
      {
        "l": "chmod",
        "r": "modifie les permissions (lecture/écriture/exécution)"
      },
      {
        "l": "chown",
        "r": "change le propriétaire d'un fichier"
      },
      {
        "l": "chgrp",
        "r": "change le groupe propriétaire d'un fichier"
      },
      {
        "l": "umask",
        "r": "définit les permissions par défaut à la création"
      }
    ],
    "exp": "chmod agit sur les droits rwx, chown et chgrp changent respectivement le propriétaire et le groupe d'un fichier, et umask fixe un masque soustrait aux permissions par défaut lors de la création d'un nouveau fichier ou dossier."
  },
  {
    "cat": "Linux",
    "type": "match",
    "q": "Relie chaque commande de processus à son rôle.",
    "pairs": [
      {
        "l": "ps",
        "r": "affiche les processus en cours d'exécution"
      },
      {
        "l": "kill",
        "r": "envoie un signal (souvent d'arrêt) à un processus"
      },
      {
        "l": "top",
        "r": "affiche en temps réel la consommation CPU/RAM"
      },
      {
        "l": "&",
        "r": "lance une commande en arrière-plan"
      }
    ],
    "exp": "ps donne un instantané des processus actifs, kill envoie un signal (par défaut SIGTERM) à un PID pour l'arrêter, top affiche un tableau de bord dynamique des ressources, et le & placé après une commande la détache du terminal pour continuer à l'utiliser."
  },
  {
    "cat": "Linux",
    "type": "match",
    "q": "Relie chaque commande de gestion de paquets Debian/Ubuntu à son rôle.",
    "pairs": [
      {
        "l": "apt update",
        "r": "met à jour la liste des paquets disponibles"
      },
      {
        "l": "apt upgrade",
        "r": "installe les nouvelles versions des paquets déjà installés"
      },
      {
        "l": "apt install",
        "r": "installe un nouveau paquet"
      },
      {
        "l": "apt remove",
        "r": "désinstalle un paquet sans supprimer sa configuration"
      }
    ],
    "exp": "apt update rafraîchit le cache des dépôts sans rien installer, apt upgrade applique les mises à jour disponibles, apt install ajoute un logiciel, et apt remove le retire tout en conservant ses fichiers de configuration (contrairement à apt purge qui les supprime aussi)."
  },
  {
    "cat": "Linux",
    "type": "qcm",
    "q": "Un administrateur tape « chmod 750 script.sh ». Quels droits obtient le propriétaire du fichier ?",
    "c": [
      "lecture, écriture et exécution",
      "lecture et écriture seulement",
      "exécution seulement",
      "aucun droit"
    ],
    "a": 0,
    "exp": "En notation octale, chaque chiffre représente un triplet rwx : 7 = 4+2+1 = lecture+écriture+exécution pour le propriétaire, 5 = lecture+exécution pour le groupe, 0 = aucun droit pour les autres."
  },
  {
    "cat": "Linux",
    "type": "qcm",
    "q": "Un administrateur tape « chmod 750 script.sh ». Quels droits obtient le groupe ?",
    "c": [
      "lecture et exécution, pas d'écriture",
      "lecture, écriture et exécution",
      "aucun droit",
      "écriture seulement"
    ],
    "a": 0,
    "exp": "Le deuxième chiffre octal (5 = 4+1) s'applique au groupe : lecture et exécution sont autorisées, mais pas l'écriture (qui vaudrait 2)."
  },
  {
    "cat": "Linux",
    "type": "qcm",
    "q": "Quelle commande affiche l'identité (nom d'utilisateur) actuellement connectée ?",
    "c": [
      "whoami",
      "who",
      "id -G",
      "groups"
    ],
    "a": 0,
    "exp": "whoami affiche uniquement le nom de l'utilisateur courant. « who » liste les utilisateurs connectés au système, « id -G » affiche les identifiants de groupes, et « groups » liste les noms des groupes d'appartenance."
  },
  {
    "cat": "Linux",
    "type": "qcm",
    "q": "Quelle commande permet d'ouvrir une session distante chiffrée sur un serveur Linux ?",
    "c": [
      "ssh",
      "telnet",
      "ftp",
      "rsh"
    ],
    "a": 0,
    "exp": "ssh (Secure Shell) chiffre l'intégralité de la session sur le port TCP 22. telnet et rsh transmettent en clair, et ftp sert au transfert de fichiers, pas à l'ouverture d'un shell distant."
  },
  {
    "cat": "Linux",
    "type": "qcm",
    "q": "Que fait la redirection « commande > fichier » ?",
    "c": [
      "écrase le fichier avec la sortie de la commande",
      "ajoute la sortie à la fin du fichier",
      "envoie le fichier en entrée de la commande",
      "compare la commande et le fichier"
    ],
    "a": 0,
    "exp": "Le simple chevron > redirige la sortie standard vers un fichier en l'écrasant s'il existe déjà. Pour ajouter à la suite sans écraser, on utilise >> ; pour rediriger un fichier en entrée, on utilise <."
  },
  {
    "cat": "Linux",
    "type": "qcm",
    "q": "Que fait le pipe « | » entre deux commandes, par exemple « ps aux | grep ssh » ?",
    "c": [
      "envoie la sortie de la première commande en entrée de la seconde",
      "exécute les deux commandes en parallèle sans lien entre elles",
      "compare les sorties des deux commandes",
      "enregistre la sortie dans un fichier temporaire"
    ],
    "a": 0,
    "exp": "Le pipe relie la sortie standard de la commande de gauche à l'entrée standard de la commande de droite. Ici, la liste des processus produite par ps aux est filtrée par grep pour ne garder que les lignes contenant « ssh »."
  },
  {
    "cat": "Linux",
    "type": "text",
    "q": "Quelle commande affiche le contenu d'un fichier texte en une seule fois, sans pagination ?",
    "reponse": "cat",
    "exp": "cat (concatenate) affiche tout le contenu d'un fichier d'un seul bloc. Pour un gros fichier qu'on veut parcourir page par page, on utilise plutôt less.",
    "acceptedAnswers": [
      "cat"
    ],
    "displayAnswers": [
      "cat"
    ]
  },
  {
    "cat": "Linux",
    "type": "text",
    "q": "Quelle commande recherche un motif (chaîne de caractères) dans un texte ou un fichier ?",
    "reponse": "grep",
    "exp": "grep (Global Regular Expression Print) recherche les lignes correspondant à un motif, souvent une expression régulière, et affiche celles qui correspondent.",
    "acceptedAnswers": [
      "grep"
    ],
    "displayAnswers": [
      "grep"
    ]
  },
  {
    "cat": "Linux",
    "type": "text",
    "q": "Quelle commande affiche l'espace disque utilisé par des fichiers ou répertoires ?",
    "reponse": "du",
    "exp": "du (disk usage) indique l'espace occupé par des fichiers ou dossiers. Pour connaître l'espace libre/total d'un système de fichiers monté, on utilise plutôt df.",
    "accept": [
      "du -h"
    ],
    "acceptedAnswers": [
      "du",
      "du -h"
    ],
    "displayAnswers": [
      "du",
      "du -h"
    ]
  },
  {
    "cat": "Linux",
    "type": "text",
    "q": "Quelle commande affiche l'espace disque libre et utilisé de chaque système de fichiers monté ?",
    "reponse": "df",
    "exp": "df (disk free) donne une vue globale par partition/point de montage, à ne pas confondre avec du qui détaille l'espace pris par des fichiers ou dossiers précis.",
    "accept": [
      "df -h"
    ],
    "acceptedAnswers": [
      "df",
      "df -h"
    ],
    "displayAnswers": [
      "df",
      "df -h"
    ]
  },
  {
    "cat": "Linux",
    "type": "qcm",
    "q": "Un fichier appartient à l'utilisateur « alice » et au groupe « devs ». Bob, qui n'est ni alice ni membre du groupe devs, essaie de le lire. Quelle permission s'applique à Bob ?",
    "c": [
      "les droits « autres » du fichier",
      "les droits du propriétaire",
      "les droits du groupe devs",
      "aucune règle ne s'applique, l'accès est toujours refusé"
    ],
    "a": 0,
    "exp": "Sous Linux, les permissions d'un fichier sont réparties en trois catégories : propriétaire, groupe, et autres. Bob n'étant ni l'un ni l'autre, ce sont les droits « autres » qui déterminent s'il peut lire le fichier."
  },
  {
    "cat": "Linux",
    "type": "scenario",
    "q": "Un script .sh refuse de s'exécuter avec le message « Permission denied » alors que son contenu est correct. Quelle est la cause la plus probable ?",
    "c": [
      "le fichier n'a pas le droit d'exécution",
      "le disque est plein",
      "le réseau est down",
      "le fichier a été supprimé"
    ],
    "a": 0,
    "exp": "Sous Linux, avoir le droit de lire un script ne suffit pas pour le lancer : il faut aussi le bit d'exécution (x). La solution habituelle est d'ajouter ce droit avec chmod +x nom_du_script.sh."
  },
  {
    "cat": "Linux",
    "type": "qcm",
    "q": "Quel fichier système Linux liste les utilisateurs et leurs informations de base (UID, shell, dossier personnel) ?",
    "c": [
      "/etc/passwd",
      "/etc/hosts",
      "/etc/fstab",
      "/etc/shadow"
    ],
    "a": 0,
    "exp": "/etc/passwd contient une ligne par utilisateur avec son UID, GID, shell par défaut et répertoire personnel. Les mots de passe chiffrés, eux, sont stockés séparément dans /etc/shadow pour des raisons de sécurité."
  },
  {
    "cat": "Linux",
    "type": "qcm",
    "q": "Quel fichier système Linux stocke les mots de passe chiffrés des utilisateurs ?",
    "c": [
      "/etc/shadow",
      "/etc/passwd",
      "/etc/group",
      "/etc/sudoers"
    ],
    "a": 0,
    "exp": "/etc/shadow contient les hachages des mots de passe et n'est lisible que par root, contrairement à /etc/passwd qui est lisible par tous mais ne contient plus les mots de passe depuis longtemps."
  },
  {
    "cat": "Binaire & logique",
    "type": "text",
    "q": "Convertis le nombre décimal 200 en binaire sur 8 bits.",
    "reponse": "11001000",
    "exp": "200 = 128 + 64 + 8, soit les bits de poids 128, 64 et 8 à 1 : 1 1 0 0 1 0 0 0."
  },
  {
    "cat": "Binaire & logique",
    "type": "text",
    "q": "Convertis le nombre décimal 42 en binaire sur 8 bits.",
    "reponse": "00101010",
    "exp": "42 = 32 + 8 + 2, soit les bits de poids 32, 8 et 2 à 1 : 0 0 1 0 1 0 1 0.",
    "accept": [
      "101010"
    ]
  },
  {
    "cat": "Binaire & logique",
    "type": "text",
    "q": "Convertis le nombre décimal 17 en binaire sur 8 bits.",
    "reponse": "00010001",
    "exp": "17 = 16 + 1, soit les bits de poids 16 et 1 à 1 : 0 0 0 1 0 0 0 1.",
    "accept": [
      "10001"
    ]
  },
  {
    "cat": "Binaire & logique",
    "type": "calculation",
    "q": "Convertis l'octet binaire 10110101 en décimal.",
    "fields": [
      {
        "label": "Valeur décimale",
        "answer": "181"
      }
    ],
    "exp": "En partant du bit de poids fort (128), les bits à 1 sont 128, 32, 16, 4 et 1 : 128+32+16+4+1 = 181."
  },
  {
    "cat": "Binaire & logique",
    "type": "calculation",
    "q": "Convertis l'octet binaire 11100011 en décimal.",
    "fields": [
      {
        "label": "Valeur décimale",
        "answer": "227"
      }
    ],
    "exp": "Les bits à 1 sont 128, 64, 32, 2 et 1 : 128+64+32+2+1 = 227."
  },
  {
    "cat": "Binaire & logique",
    "type": "calculation",
    "q": "Convertis l'octet binaire 01111111 en décimal.",
    "fields": [
      {
        "label": "Valeur décimale",
        "answer": "127"
      }
    ],
    "exp": "Tous les bits sauf celui de poids 128 sont à 1 : 64+32+16+8+4+2+1 = 127. C'est la valeur maximale que l'on peut représenter sur 7 bits."
  },
  {
    "cat": "Binaire & logique",
    "type": "qcm",
    "q": "Quelle est la règle de la porte logique ET (AND) ?",
    "c": [
      "elle renvoie 1 uniquement si SES DEUX entrées valent 1, sinon elle renvoie 0",
      "elle renvoie 1 dès qu'AU MOINS UNE de ses entrées vaut 1",
      "elle inverse systématiquement la valeur de son entrée",
      "elle renvoie 1 uniquement si ses deux entrées sont différentes"
    ],
    "a": 0,
    "exp": "La porte AND est la plus « exigeante » : le résultat n'est à 1 que si les deux entrées sont à 1 en même temps (1 ET 1 = 1). Dans tous les autres cas (0 ET 0, 0 ET 1, 1 ET 0), le résultat est 0. C'est ce principe qui est utilisé pour appliquer un masque réseau à une adresse IP : seuls les bits à 1 des deux côtés restent à 1."
  },
  {
    "cat": "Binaire & logique",
    "type": "match",
    "q": "Relie chaque combinaison de la porte ET (AND) à son résultat.",
    "pairs": [
      {
        "l": "0 AND 0",
        "r": "0"
      },
      {
        "l": "0 AND 1",
        "r": "0"
      },
      {
        "l": "1 AND 0",
        "r": "0"
      },
      {
        "l": "1 AND 1",
        "r": "1"
      }
    ],
    "exp": "La table de vérité du AND ne donne 1 que sur la dernière ligne, quand les deux entrées valent 1. Dans les trois autres cas, dès qu'une seule entrée est à 0, le résultat tombe à 0 : c'est pour cela qu'on dit que AND est la porte la plus « restrictive »."
  },
  {
    "cat": "Binaire & logique",
    "type": "qcm",
    "q": "Quelle est la règle de la porte logique OU (OR) ?",
    "c": [
      "elle renvoie 1 dès qu'AU MOINS UNE de ses deux entrées vaut 1",
      "elle renvoie 1 uniquement si SES DEUX entrées valent 1",
      "elle renvoie toujours 0 quelles que soient ses entrées",
      "elle renvoie 1 uniquement si ses deux entrées sont différentes"
    ],
    "a": 0,
    "exp": "La porte OR est plus « permissive » que AND : il suffit qu'une seule des deux entrées soit à 1 pour que le résultat soit 1. Le résultat n'est à 0 que dans le seul cas où les deux entrées valent 0 en même temps (0 OU 0 = 0)."
  },
  {
    "cat": "Binaire & logique",
    "type": "match",
    "q": "Relie chaque combinaison de la porte OU (OR) à son résultat.",
    "pairs": [
      {
        "l": "0 OR 0",
        "r": "0"
      },
      {
        "l": "0 OR 1",
        "r": "1"
      },
      {
        "l": "1 OR 0",
        "r": "1"
      },
      {
        "l": "1 OR 1",
        "r": "1"
      }
    ],
    "exp": "La table de vérité du OR ne donne 0 que sur la première ligne, quand les deux entrées valent 0. Dès qu'une seule entrée passe à 1, le résultat devient 1 : c'est pour cela qu'on dit que OR est la porte la plus « permissive »."
  },
  {
    "cat": "Binaire & logique",
    "type": "qcm",
    "q": "Quelle est la règle de la porte logique NON (NOT) ?",
    "c": [
      "elle inverse la valeur de son unique entrée : 0 devient 1, et 1 devient 0",
      "elle compare deux entrées et renvoie 1 si elles sont égales",
      "elle renvoie 1 uniquement si ses deux entrées valent 1",
      "elle ne peut s'appliquer qu'à des nombres et jamais à un seul bit"
    ],
    "a": 0,
    "exp": "Contrairement à AND et OR qui prennent deux entrées, NOT n'en prend qu'une seule et se contente de l'inverser (on parle aussi de complément). NOT 0 = 1 et NOT 1 = 0 : c'est la porte la plus simple."
  },
  {
    "cat": "Binaire & logique",
    "type": "qcm",
    "q": "Quelle est la règle de la porte logique OU EXCLUSIF (XOR) ?",
    "c": [
      "elle renvoie 1 uniquement si ses deux entrées sont DIFFÉRENTES l'une de l'autre",
      "elle renvoie 1 uniquement si ses deux entrées sont IDENTIQUES",
      "elle renvoie 1 dès qu'au moins une entrée vaut 1, comme OR",
      "elle inverse systématiquement la valeur de son unique entrée"
    ],
    "a": 0,
    "exp": "XOR (« ou exclusif ») ne renvoie 1 que lorsque les deux entrées sont différentes (0-1 ou 1-0) ; si elles sont identiques (0-0 ou 1-1), le résultat est 0. C'est la porte utilisée par exemple dans certains calculs de parité ou de chiffrement simple."
  },
  {
    "cat": "Binaire & logique",
    "type": "match",
    "q": "Relie chaque combinaison de la porte OU EXCLUSIF (XOR) à son résultat.",
    "pairs": [
      {
        "l": "0 XOR 0",
        "r": "0"
      },
      {
        "l": "0 XOR 1",
        "r": "1"
      },
      {
        "l": "1 XOR 0",
        "r": "1"
      },
      {
        "l": "1 XOR 1",
        "r": "0"
      }
    ],
    "exp": "XOR ne renvoie 1 que lorsque les deux entrées sont différentes l'une de l'autre. Dès qu'elles sont identiques (toutes les deux à 0 ou toutes les deux à 1), le résultat retombe à 0 : c'est ce qui le distingue du OR classique, qui lui renvoie 1 quand les deux entrées valent 1."
  },
  {
    "cat": "Binaire & logique",
    "type": "calculation",
    "q": "Applique un ET (AND) logique bit à bit entre l'octet 11001010 et le masque 11110000.",
    "fields": [
      {
        "label": "Résultat (en binaire)",
        "answer": "11000000"
      }
    ],
    "exp": "Le AND bit à bit compare position par position : seuls les bits qui sont à 1 dans les DEUX octets restent à 1 dans le résultat. Ici, seuls les 2 premiers bits sont à 1 des deux côtés (1 AND 1 = 1), tous les autres tombent à 0 dès que l'un des deux bits vaut 0. C'est exactement ce mécanisme qui, appliqué à une adresse IP et à son masque, permet de calculer l'adresse réseau."
  },
  {
    "cat": "Binaire & logique",
    "type": "qcm",
    "q": "Quelle est la valeur maximale que l'on peut représenter avec un octet (8 bits) non signé ?",
    "c": [
      "255",
      "256",
      "128",
      "127"
    ],
    "a": 0,
    "exp": "Un octet non signé va de 00000000 (0) à 11111111 (255), soit 2^8 = 256 valeurs possibles, de 0 à 255 inclus."
  },
  {
    "cat": "Binaire & logique",
    "type": "qcm",
    "q": "Quel est le bit de poids fort (MSB) dans un octet écrit 10000000 ?",
    "c": [
      "le bit le plus à gauche, ici à 1",
      "le bit le plus à droite, ici à 0",
      "le bit du milieu de l'octet",
      "il n'existe pas de bit de poids fort en binaire"
    ],
    "a": 0,
    "exp": "Le MSB (Most Significant Bit) est le bit de plus grande valeur, situé à l'extrême gauche de l'octet ; il vaut ici 128. Le bit de poids faible (LSB), à droite, vaut 1."
  },
  {
    "cat": "Binaire & logique",
    "type": "qcm",
    "q": "En hexadécimal (base 16), à quelle valeur décimale correspond la lettre F ?",
    "c": [
      "15",
      "16",
      "6",
      "10"
    ],
    "a": 0,
    "exp": "L'hexadécimal utilise 16 symboles pour représenter un seul chiffre : 0 à 9 comme en décimal, puis les lettres A, B, C, D, E, F pour représenter les valeurs 10, 11, 12, 13, 14 et 15. F est donc le dernier symbole de la liste et vaut 15."
  },
  {
    "cat": "Binaire & logique",
    "type": "qcm",
    "q": "En hexadécimal, à quelle valeur décimale correspond « FF » ?",
    "c": [
      "255",
      "256",
      "16",
      "15"
    ],
    "a": 0,
    "exp": "Comme en décimal, chaque position d'un nombre hexadécimal vaut une puissance de 16, en partant de la droite : la 1ère position (unités) vaut 16^0 = 1, la 2ème (« seizaines ») vaut 16^1 = 16. Dans « FF », chaque F vaut 15. On calcule donc : (F × 16^1) + (F × 16^0) = (15 × 16) + (15 × 1) = 240 + 15 = 255. C'est la même valeur que l'octet binaire 11111111, ce qui explique pourquoi les adresses MAC et certaines couleurs web s'écrivent souvent en hexadécimal : deux chiffres hexa codent exactement un octet."
  },
  {
    "cat": "Binaire & logique",
    "type": "text",
    "q": "Convertis le nombre décimal 10 en hexadécimal.",
    "reponse": "A",
    "exp": "L'hexadécimal ne va pas au-delà du chiffre 9 pour un seul symbole : à partir de 10, on utilise les lettres A (10), B (11), C (12), D (13), E (14) et F (15). Comme 10 est un des symboles de base de l'hexadécimal, il s'écrit avec un seul caractère : A.",
    "accept": [
      "0A",
      "a"
    ]
  },
  {
    "cat": "Binaire & logique",
    "type": "text",
    "q": "Convertis le nombre décimal 100 en binaire sur 8 bits.",
    "reponse": "01100100",
    "exp": "100 = 64 + 32 + 4, soit les bits de poids 64, 32 et 4 à 1 : 0 1 1 0 0 1 0 0.",
    "accept": [
      "1100100"
    ]
  },
  {
    "cat": "Binaire & logique",
    "type": "calculation",
    "q": "Convertis l'octet binaire 01010101 en décimal.",
    "fields": [
      {
        "label": "Valeur décimale",
        "answer": "85"
      }
    ],
    "exp": "Les bits à 1 sont ceux de poids 64, 16, 4 et 1 : 64+16+4+1 = 85."
  },
  {
    "cat": "Binaire & logique",
    "type": "text",
    "q": "Convertis le nombre hexadécimal 1E en décimal.",
    "reponse": "30",
    "exp": "Il faut décomposer chaque chiffre selon sa position, en partant de la droite (16^0, puis 16^1...). Dans « 1E », le chiffre de droite est E : c'est un symbole hexadécimal qui vaut 14 en décimal, et il est en position des unités (16^0), donc il compte pour 14 × 1 = 14. Le chiffre de gauche est 1, en position des « seizaines » (16^1), donc il compte pour 1 × 16 = 16. On additionne les deux : 16 + 14 = 30.",
    "accept": [
      "30 (decimal)"
    ]
  },
  {
    "cat": "Réseaux & IPv4",
    "type": "text",
    "q": "Quel masque de sous-réseau correspond à la notation /24 ?",
    "reponse": "255.255.255.0",
    "exp": "/24 signifie que les 24 premiers bits (les 3 premiers octets) servent à identifier le réseau : cela donne le masque 255.255.255.0, avec 8 bits pour la partie hôte, soit 256 adresses possibles dont 254 utilisables."
  },
  {
    "cat": "Réseaux & IPv4",
    "type": "text",
    "q": "Quel masque de sous-réseau correspond à la notation /26 ?",
    "reponse": "255.255.255.192",
    "exp": "/26 laisse 6 bits pour la partie hôte (32-26=6). Le dernier octet du masque vaut alors 11000000 en binaire, soit 192 : le masque complet est 255.255.255.192."
  },
  {
    "cat": "Réseaux & IPv4",
    "type": "text",
    "q": "Quel masque de sous-réseau correspond à la notation /28 ?",
    "reponse": "255.255.255.240",
    "exp": "/28 laisse 4 bits pour la partie hôte (32-28=4). Le dernier octet du masque vaut 11110000 en binaire, soit 240 : le masque complet est 255.255.255.240."
  },
  {
    "cat": "Réseaux & IPv4",
    "type": "text",
    "q": "Combien de bits de préfixe correspondent au masque 255.255.255.128 ?",
    "reponse": "/25",
    "exp": "255.255.255.128 signifie que le dernier octet vaut 10000000 en binaire, soit 1 bit à 1 sur les 8 : cela fait 24+1 = 25 bits de préfixe réseau, noté /25.",
    "accept": [
      "25"
    ]
  },
  {
    "cat": "Réseaux & IPv4",
    "type": "calculation",
    "q": "Pour l'adresse 192.168.10.130 avec un masque /26, détermine :",
    "fields": [
      {
        "label": "Masque en notation décimale",
        "answer": "255.255.255.192"
      },
      {
        "label": "Adresse réseau",
        "answer": "192.168.10.128"
      },
      {
        "label": "Adresse de broadcast",
        "answer": "192.168.10.191"
      },
      {
        "label": "Nombre d'hôtes utilisables",
        "answer": "62"
      }
    ],
    "exp": "/26 laisse 6 bits hôtes, donc des blocs de 2^6 = 64 adresses : 0-63, 64-127, 128-191, 192-255. 130 tombe dans le bloc 128-191 : l'adresse réseau est .128 et le broadcast .191. Sur 64 adresses, on retire le réseau et le broadcast : 64-2 = 62 hôtes utilisables."
  },
  {
    "cat": "Réseaux & IPv4",
    "type": "calculation",
    "q": "Pour l'adresse 10.0.5.77 avec un masque /27, détermine :",
    "fields": [
      {
        "label": "Masque en notation décimale",
        "answer": "255.255.255.224"
      },
      {
        "label": "Adresse réseau",
        "answer": "10.0.5.64"
      },
      {
        "label": "Adresse de broadcast",
        "answer": "10.0.5.95"
      },
      {
        "label": "Nombre d'hôtes utilisables",
        "answer": "30"
      }
    ],
    "exp": "/27 laisse 5 bits hôtes, donc des blocs de 2^5 = 32 adresses : 0-31, 32-63, 64-95, 96-127... 77 tombe dans le bloc 64-95 : réseau .64, broadcast .95. Sur 32 adresses, on retire réseau et broadcast : 32-2 = 30 hôtes utilisables."
  },
  {
    "cat": "Réseaux & IPv4",
    "type": "calculation",
    "q": "Pour l'adresse 172.16.34.200 avec un masque /23, détermine :",
    "fields": [
      {
        "label": "Masque en notation décimale",
        "answer": "255.255.254.0"
      },
      {
        "label": "Adresse réseau",
        "answer": "172.16.34.0"
      },
      {
        "label": "Adresse de broadcast",
        "answer": "172.16.35.255"
      },
      {
        "label": "Nombre d'hôtes utilisables",
        "answer": "510"
      }
    ],
    "exp": "/23 étend le réseau sur le 3e octet : il reste 9 bits hôtes, soit des blocs de 512 adresses couvrant deux valeurs du 3e octet à la fois (34-35). Le réseau commence donc à .34.0 et le broadcast est à .35.255. 512-2 = 510 hôtes utilisables."
  },
  {
    "cat": "Réseaux & IPv4",
    "type": "calculation",
    "q": "Pour l'adresse 192.168.1.10 avec un masque /30, détermine :",
    "fields": [
      {
        "label": "Adresse réseau",
        "answer": "192.168.1.8"
      },
      {
        "label": "Adresse de broadcast",
        "answer": "192.168.1.11"
      },
      {
        "label": "Première IP utilisable",
        "answer": "192.168.1.9"
      },
      {
        "label": "Nombre d'hôtes utilisables",
        "answer": "2"
      }
    ],
    "exp": "/30 ne laisse que 2 bits hôtes, soit des blocs de 4 adresses (8-11 ici). Réseau=.8, broadcast=.11, et il ne reste que 2 IP utilisables entre les deux (.9 et .10) : c'est le format typique d'une liaison point-à-point entre deux routeurs."
  },
  {
    "cat": "Réseaux & IPv4",
    "type": "qcm",
    "q": "Une machine a l'adresse 169.254.x.x sans configuration manuelle. Que peut-on en déduire ?",
    "c": [
      "elle n'a pas reçu de réponse d'un serveur DHCP",
      "elle est correctement configurée en IP statique",
      "elle appartient à une classe A publique",
      "elle utilise IPv6"
    ],
    "a": 0,
    "exp": "169.254.0.0/16 est la plage APIPA (Automatic Private IP Addressing) attribuée automatiquement par Windows quand aucun serveur DHCP ne répond. C'est un signe classique de panne réseau ou DHCP à diagnostiquer."
  },
  {
    "cat": "Réseaux & IPv4",
    "type": "qcm",
    "q": "Parmi ces adresses, laquelle appartient à une plage privée (RFC 1918) ?",
    "c": [
      "192.168.1.50",
      "8.8.8.8",
      "172.32.0.1",
      "1.1.1.1"
    ],
    "a": 0,
    "exp": "Les plages privées sont 10.0.0.0/8, 172.16.0.0/12 et 192.168.0.0/16. 192.168.1.50 en fait partie. 172.32.0.1 n'est pas privée car la plage 172.16-172.31 s'arrête à 172.31, et 8.8.8.8 / 1.1.1.1 sont des résolveurs DNS publics."
  },
  {
    "cat": "Réseaux & IPv4",
    "type": "qcm",
    "q": "À quoi sert la commande « ping » ?",
    "c": [
      "tester la joignabilité d'un hôte via des requêtes ICMP",
      "afficher la table de routage",
      "attribuer une adresse IP dynamiquement",
      "chiffrer une connexion réseau"
    ],
    "a": 0,
    "exp": "ping envoie des paquets ICMP Echo Request et attend un Echo Reply pour vérifier qu'un hôte distant répond et mesurer le temps de trajet aller-retour (latence)."
  },
  {
    "cat": "Réseaux & IPv4",
    "type": "qcm",
    "q": "Qu'est-ce qu'un réseau de niveau 2 (couche 2 du modèle OSI) ?",
    "c": [
      "un réseau où les échanges se font via les adresses MAC, au niveau de la couche Liaison de données",
      "un réseau où les échanges reposent uniquement sur les adresses IP attribuées",
      "un réseau qui ne peut techniquement relier que deux machines entre elles",
      "un réseau qui ne peut fonctionner qu'au travers d'une connexion sans fil"
    ],
    "a": 0,
    "exp": "La couche 2 (Liaison de données) du modèle OSI gère la communication au sein d'un même segment local via les adresses MAC (commutation par les switchs), avant même qu'une adresse IP (couche 3) n'entre en jeu."
  },
  {
    "cat": "Réseaux & IPv4",
    "type": "qcm",
    "q": "Un VLAN permet de diviser un même switch physique en plusieurs réseaux séparés. Comment fait-il concrètement, au niveau de la couche 2 ?",
    "c": [
      "il regroupe les ports du switch en groupes étanches : les trames d'un groupe ne sont jamais transmises aux autres groupes",
      "il chiffre les échanges entre deux machines pour que les autres VLAN ne puissent pas les lire",
      "il attribue automatiquement une adresse IP différente à chaque VLAN",
      "il remplace le protocole IP par un protocole propre à chaque VLAN"
    ],
    "a": 0,
    "exp": "Sans VLAN, tous les ports d'un switch appartiennent au même réseau de niveau 2 : une trame envoyée en broadcast (par exemple une requête ARP) est reçue par toutes les machines branchées dessus. Un VLAN (Virtual LAN) crée des groupes de ports cloisonnés à l'intérieur d'un même switch physique : chaque groupe forme son propre « domaine de diffusion » (broadcast domain), c'est-à-dire que les trames d'un VLAN ne sont jamais vues par les machines d'un autre VLAN, même si elles sont branchées sur le même appareil. C'est une segmentation logique, pas une segmentation par le chiffrement ni par l'adressage IP."
  },
  {
    "cat": "Réseaux & IPv4",
    "type": "scenario",
    "q": "Deux machines sont sur le même switch mais dans deux VLAN différents et ne peuvent pas communiquer. Que faut-il pour qu'elles échangent des données ?",
    "c": [
      "un routeur pour router entre les VLAN",
      "un simple câble croisé entre les deux machines",
      "changer leur adresse MAC",
      "activer le Wi-Fi sur les deux machines"
    ],
    "a": 0,
    "exp": "Les VLAN isolent les domaines de diffusion au niveau 2 : deux machines dans des VLAN différents sont donc dans des réseaux logiquement séparés. Pour communiquer, il faut un équipement de niveau 3 (routeur ou switch L3 avec routage inter-VLAN) qui relie les deux réseaux IP correspondants."
  },
  {
    "cat": "Ports & protocoles",
    "type": "text",
    "q": "Quel numéro de port utilise le protocole HTTP par défaut ?",
    "reponse": "80",
    "exp": "HTTP (HyperText Transfer Protocol) utilise par défaut le port TCP 80 pour le trafic web non chiffré."
  },
  {
    "cat": "Ports & protocoles",
    "type": "text",
    "q": "Quel numéro de port utilise le protocole HTTPS par défaut ?",
    "reponse": "443",
    "exp": "HTTPS est HTTP encapsulé dans une session chiffrée TLS, et utilise par défaut le port TCP 443."
  },
  {
    "cat": "Ports & protocoles",
    "type": "text",
    "q": "Quel numéro de port utilise le protocole SSH par défaut ?",
    "reponse": "22",
    "exp": "SSH (Secure Shell) utilise par défaut le port TCP 22 pour ouvrir des sessions distantes chiffrées."
  },
  {
    "cat": "Ports & protocoles",
    "type": "text",
    "q": "Quel numéro de port utilise le service DNS par défaut ?",
    "reponse": "53",
    "exp": "DNS utilise le port 53, en UDP pour la majorité des requêtes de résolution de noms (plus rapide), et en TCP pour les transferts de zone ou les réponses volumineuses."
  },
  {
    "cat": "Ports & protocoles",
    "type": "text",
    "q": "Quel numéro de port utilise le protocole RDP (bureau à distance Windows) par défaut ?",
    "reponse": "3389",
    "exp": "RDP (Remote Desktop Protocol) utilise par défaut le port TCP 3389 pour la prise de contrôle graphique à distance d'un poste ou serveur Windows."
  },
  {
    "cat": "Ports & protocoles",
    "type": "text",
    "q": "Quel numéro de port utilise LDAP (non chiffré) par défaut ?",
    "reponse": "389",
    "exp": "LDAP (Lightweight Directory Access Protocol), utilisé notamment par Active Directory, écoute par défaut sur le port TCP 389 en clair. Sa version chiffrée LDAPS utilise le port 636."
  },
  {
    "cat": "Ports & protocoles",
    "type": "text",
    "q": "Quel service utilise le port TCP 443 ?",
    "reponse": "HTTPS",
    "exp": "Le port 443 est associé à HTTPS, la version chiffrée (via TLS) du protocole HTTP utilisé pour la navigation web sécurisée.",
    "accept": [
      "https"
    ],
    "acceptedAnswers": [
      "https",
      "https (port 443)"
    ],
    "displayAnswers": [
      "HTTPS",
      "https"
    ]
  },
  {
    "cat": "Ports & protocoles",
    "type": "text",
    "q": "Quel service utilise le port TCP 22 ?",
    "reponse": "SSH",
    "exp": "Le port 22 est associé à SSH, qui permet d'ouvrir une session distante chiffrée sur un serveur ou équipement réseau.",
    "accept": [
      "ssh"
    ],
    "acceptedAnswers": [
      "ssh",
      "secure shell"
    ],
    "displayAnswers": [
      "SSH",
      "Secure Shell"
    ]
  },
  {
    "cat": "Ports & protocoles",
    "type": "text",
    "q": "Quel service utilise le port TCP 3389 ?",
    "reponse": "RDP",
    "exp": "Le port 3389 est associé à RDP, le protocole de bureau à distance de Windows.",
    "accept": [
      "rdp",
      "remote desktop protocol"
    ],
    "acceptedAnswers": [
      "rdp",
      "remote desktop protocol",
      "remote desktop"
    ],
    "displayAnswers": [
      "RDP",
      "Remote Desktop Protocol"
    ]
  },
  {
    "cat": "Ports & protocoles",
    "type": "text",
    "q": "Quel service utilise le port TCP/UDP 445 ?",
    "reponse": "SMB",
    "exp": "Le port 445 est associé à SMB (Server Message Block), utilisé pour le partage de fichiers et d'imprimantes, notamment sous Windows.",
    "accept": [
      "smb"
    ],
    "acceptedAnswers": [
      "smb",
      "server message block"
    ],
    "displayAnswers": [
      "SMB",
      "Server Message Block"
    ]
  },
  {
    "cat": "Ports & protocoles",
    "type": "text",
    "q": "Quels numéros de port utilise le service DHCP (client et serveur) ?",
    "reponse": "67 et 68",
    "exp": "Le serveur DHCP écoute sur le port UDP 67, tandis que le client DHCP utilise le port UDP 68 pour recevoir les réponses (offres et accusés de bail).",
    "accept": [
      "67/68",
      "67-68",
      "68 et 67"
    ],
    "acceptedAnswers": [
      "67 et 68",
      "67/68",
      "67-68",
      "68 et 67"
    ],
    "displayAnswers": [
      "67 et 68",
      "67/68"
    ]
  },
  {
    "cat": "Ports & protocoles",
    "type": "match",
    "q": "Relie chaque protocole à son port par défaut.",
    "pairs": [
      {
        "l": "FTP (données/contrôle)",
        "r": "20 et 21"
      },
      {
        "l": "Telnet",
        "r": "23"
      },
      {
        "l": "SMTP",
        "r": "25"
      },
      {
        "l": "POP3",
        "r": "110"
      }
    ],
    "exp": "FTP utilise deux ports : 21 pour les commandes et 20 pour le transfert de données en mode actif. Telnet (session distante non chiffrée) utilise le port 23, SMTP (envoi de mail) le port 25, et POP3 (relève de boîte mail) le port 110."
  },
  {
    "cat": "Ports & protocoles",
    "type": "match",
    "q": "Relie chaque protocole (IMAP, LDAPS, HTTPS, DNS) à son port par défaut.",
    "pairs": [
      {
        "l": "LDAPS",
        "r": "636"
      },
      {
        "l": "HTTPS",
        "r": "443"
      },
      {
        "l": "DNS",
        "r": "53"
      }
    ],
    "exp": "IMAP (consultation de mail en laissant les messages sur le serveur) utilise le port 143, LDAPS (LDAP chiffré via TLS) le port 636, HTTPS le port 443, et DNS le port 53."
  },
  {
    "cat": "Ports & protocoles",
    "type": "qcm",
    "q": "Quelle est la principale différence entre TCP et UDP ?",
    "c": [
      "TCP est fiable et orienté connexion, UDP est plus rapide mais sans garantie de livraison",
      "TCP fonctionne uniquement en local, UDP sur Internet",
      "UDP chiffre les données, pas TCP",
      "TCP est un protocole de couche 2, UDP de couche 3"
    ],
    "a": 0,
    "exp": "TCP établit une connexion (three-way handshake), accuse réception des paquets et les retransmet si besoin : c'est fiable mais plus lent. UDP envoie les datagrammes sans connexion ni accusé de réception : c'est plus rapide, utilisé par exemple pour la voix ou la vidéo en direct, au prix de pertes possibles."
  },
  {
    "cat": "Ports & protocoles",
    "type": "qcm",
    "q": "SSH utilise-t-il TCP ou UDP ?",
    "c": [
      "TCP",
      "UDP",
      "les deux indifféremment",
      "aucun des deux, un protocole propriétaire"
    ],
    "a": 0,
    "exp": "SSH a besoin d'une connexion fiable et ordonnée pour transmettre les commandes d'une session distante sans perte ni désordre : il repose donc sur TCP, sur le port 22."
  },
  {
    "cat": "Ports & protocoles",
    "type": "qcm",
    "q": "Pourquoi la résolution DNS utilise-t-elle généralement UDP plutôt que TCP ?",
    "c": [
      "les requêtes sont courtes et UDP est plus rapide, sans établissement de connexion",
      "UDP est plus sécurisé que TCP",
      "TCP ne peut pas transporter de noms de domaine",
      "DNS n'utilise jamais TCP"
    ],
    "a": 0,
    "exp": "La plupart des requêtes DNS tiennent dans un seul petit paquet ; UDP évite l'overhead d'une connexion TCP pour gagner en rapidité. DNS bascule toutefois sur TCP pour les réponses trop volumineuses (plus de 512 octets) ou les transferts de zone."
  },
  {
    "cat": "Windows Server & AD",
    "type": "match",
    "q": "Relie chaque option DHCP à ce qu'elle transmet.",
    "pairs": [
      {
        "l": "Option 003",
        "r": "passerelle par défaut (routeur)"
      },
      {
        "l": "Option 006",
        "r": "serveurs DNS"
      },
      {
        "l": "Option 015",
        "r": "suffixe DNS du domaine"
      },
      {
        "l": "Option 051",
        "r": "durée du bail (lease time)"
      }
    ],
    "exp": "Chaque option DHCP transporte une information de configuration réseau : la passerelle (003), les serveurs DNS (006), le suffixe DNS (015) et la durée pendant laquelle l'adresse IP attribuée reste valide (051)."
  },
  {
    "cat": "Windows Server & AD",
    "type": "match",
    "q": "Relie chaque terme Active Directory à sa définition.",
    "pairs": [
      {
        "l": "Forêt",
        "r": "ensemble d'un ou plusieurs domaines partageant un schéma commun"
      },
      {
        "l": "Domaine",
        "r": "unité d'administration avec sa propre base d'annuaire"
      },
      {
        "l": "OU (Unité d'organisation)",
        "r": "conteneur pour organiser objets et appliquer des GPO"
      },
      {
        "l": "GPO",
        "r": "ensemble de règles appliquées aux utilisateurs ou ordinateurs"
      }
    ],
    "exp": "La forêt est le plus haut niveau logique d'AD, un domaine regroupe des objets sous une même autorité d'administration, les OU permettent d'organiser ces objets (souvent par service ou site) pour cibler des stratégies, et les GPO appliquent des configurations (mots de passe, restrictions, scripts...) aux objets d'une OU."
  },
  {
    "cat": "Windows Server & AD",
    "type": "qcm",
    "q": "À quoi sert principalement un contrôleur de domaine (DC) sous Windows Server ?",
    "c": [
      "héberger l'annuaire Active Directory et authentifier les utilisateurs du domaine",
      "distribuer exclusivement des adresses IP aux machines du réseau",
      "assurer le rôle de pare-feu en bordure du réseau de l'entreprise",
      "stocker une copie de sauvegarde de l'ensemble des postes du parc"
    ],
    "a": 0,
    "exp": "Le contrôleur de domaine héberge la base Active Directory (comptes, groupes, GPO...) et traite les demandes d'authentification (Kerberos/NTLM) des machines et utilisateurs du domaine."
  },
  {
    "cat": "Windows Server & AD",
    "type": "qcm",
    "q": "Un utilisateur est membre de deux groupes ayant des GPO contradictoires sur le fond d'écran. Quel principe détermine le paramètre final appliqué ?",
    "c": [
      "l'ordre de traitement et de priorité des GPO",
      "le groupe créé en premier l'emporte toujours",
      "les deux GPO s'appliquent simultanément sans conflit possible",
      "Windows applique celle qui a le nom le plus court"
    ],
    "a": 0,
    "exp": "Les GPO sont traitées dans un ordre précis (Site, Domaine, OU, du plus général au plus spécifique), et au sein d'un même niveau selon un ordre de liens configurable. En cas de conflit, c'est la dernière appliquée (sauf option « Enforced » ou blocage d'héritage) qui définit la valeur finale."
  },
  {
    "cat": "Windows Server & AD",
    "type": "qcm",
    "q": "Quel est le protocole d'authentification utilisé par défaut dans un domaine Active Directory moderne ?",
    "c": [
      "Kerberos, basé sur des tickets délivrés par un service de confiance",
      "NTLM, qui transmet un hachage du mot de passe à chaque authentification",
      "RADIUS, qui centralise l'authentification des connexions Wi-Fi et VPN",
      "LDAP, qui interroge directement l'annuaire à chaque tentative de connexion"
    ],
    "a": 0,
    "exp": "Kerberos est le protocole d'authentification par défaut dans un domaine Active Directory moderne : il repose sur la délivrance de tickets par un service de confiance (le KDC) plutôt que sur l'envoi direct du mot de passe. NTLM reste disponible pour compatibilité mais est moins sécurisé et progressivement abandonné."
  },
  {
    "cat": "Windows Server & AD",
    "type": "text",
    "q": "Quel est le nom du service Windows qui distribue automatiquement les adresses IP aux postes du réseau ?",
    "reponse": "DHCP",
    "exp": "DHCP (Dynamic Host Configuration Protocol) attribue automatiquement une adresse IP, un masque, une passerelle et d'autres paramètres réseau aux postes qui en font la demande.",
    "accept": [
      "dhcp"
    ]
  },
  {
    "cat": "Windows Server & AD",
    "type": "scenario",
    "q": "Un poste ne parvient plus à joindre le contrôleur de domaine et affiche des noms non résolus, alors que l'IP est correcte. Quel service faut-il vérifier en priorité ?",
    "c": [
      "le service DNS",
      "le service d'impression",
      "le pare-feu du poste client uniquement",
      "le service de mise à jour Windows"
    ],
    "a": 0,
    "exp": "Dans un environnement Active Directory, la découverte du contrôleur de domaine et de nombreux services repose sur la résolution DNS (notamment via des enregistrements SRV). Une IP correcte mais des noms non résolus pointent d'abord vers un problème de configuration ou de disponibilité du DNS."
  },
  {
    "cat": "Windows Server & AD",
    "type": "qcm",
    "q": "Que permet le service WSUS ?",
    "c": [
      "centraliser la distribution des mises à jour Windows sur le réseau local",
      "attribuer automatiquement une adresse IP à chaque poste du réseau",
      "centraliser la définition et l'application des stratégies de groupe",
      "chiffrer l'ensemble des communications qui transitent sur le réseau local"
    ],
    "a": 0,
    "exp": "WSUS (Windows Server Update Services) télécharge une fois les mises à jour depuis Microsoft puis les redistribue en interne, ce qui économise la bande passante Internet et permet de valider les correctifs avant déploiement."
  },
  {
    "cat": "Wi-Fi",
    "type": "qcm",
    "q": "Quelle norme de sécurité Wi-Fi est aujourd'hui recommandée plutôt que WPA2 ?",
    "c": [
      "WPA3",
      "WPA3",
      "WEP",
      "WPA"
    ],
    "a": 0,
    "exp": "WPA3 corrige plusieurs faiblesses de WPA2 (notamment via un échange de clé plus robuste, SAE) et est aujourd'hui la norme recommandée quand le matériel la supporte. WEP est obsolète et cassable en quelques minutes."
  },
  {
    "cat": "Wi-Fi",
    "type": "qcm",
    "q": "Pourquoi WEP n'est-il plus recommandé pour sécuriser un réseau Wi-Fi ?",
    "c": [
      "son chiffrement est cassable rapidement à cause de failles connues",
      "son chiffrement est cassable rapidement à cause de failles connues",
      "il ne fonctionne qu'en 5 GHz",
      "il ne supporte pas le DHCP"
    ],
    "a": 0,
    "exp": "WEP utilise un algorithme de chiffrement (RC4) avec une gestion de vecteur d'initialisation défaillante, permettant de retrouver la clé en quelques minutes avec des outils courants. Il a été remplacé par WPA puis WPA2/WPA3."
  },
  {
    "cat": "Wi-Fi",
    "type": "qcm",
    "q": "Que désigne le SSID d'un réseau Wi-Fi ?",
    "c": [
      "le nom du réseau affiché lors de la recherche de connexion",
      "le nom du réseau affiché lors de la recherche de connexion",
      "l'adresse matérielle propre au point d'accès",
      "la clé de chiffrement du réseau"
    ],
    "a": 0,
    "exp": "Le SSID (Service Set Identifier) est simplement le nom sous lequel un réseau Wi-Fi est diffusé et identifié par les appareils qui cherchent à s'y connecter."
  },
  {
    "cat": "Wi-Fi",
    "type": "qcm",
    "q": "Deux points d'accès Wi-Fi voisins utilisent le même canal en bande 2,4 GHz. Quel problème cela provoque-t-il le plus souvent ?",
    "c": [
      "des interférences qui dégradent le débit et la stabilité",
      "une incompatibilité totale empêchant toute connexion",
      "un chiffrement automatiquement désactivé",
      "aucun problème, les canaux ne se recouvrent jamais"
    ],
    "a": 0,
    "exp": "En 2,4 GHz, les canaux se chevauchent largement (seuls 1, 6 et 11 sont réellement non-recouvrants aux USA/Europe) : deux points d'accès proches sur le même canal ou des canaux trop proches se parasitent mutuellement, provoquant pertes de paquets et ralentissements."
  },
  {
    "cat": "Wi-Fi",
    "type": "qcm",
    "q": "Quel avantage principal offre la bande 5 GHz par rapport à la bande 2,4 GHz ?",
    "c": [
      "des débits plus élevés et moins d'interférences, au prix d'une portée plus réduite",
      "une portée toujours supérieure",
      "une compatibilité avec plus d'appareils anciens",
      "un chiffrement automatiquement plus fort"
    ],
    "a": 0,
    "exp": "La bande 5 GHz offre davantage de canaux non-recouvrants et moins d'appareils concurrents (fours à micro-ondes, Bluetooth...), ce qui permet de meilleurs débits, mais les fréquences plus hautes pénètrent moins bien les murs, réduisant la portée."
  },
  {
    "cat": "Wi-Fi",
    "type": "qcm",
    "q": "Qu'est-ce que le roaming Wi-Fi ?",
    "c": [
      "le passage automatique d'un appareil d'un point d'accès à un autre du même réseau sans coupure",
      "le partage de la connexion Internet d'un smartphone avec d'autres appareils",
      "le blocage automatique d'un appareil non reconnu tentant de se connecter",
      "l'attribution automatique d'une adresse IP à un nouvel appareil du réseau"
    ],
    "a": 0,
    "exp": "Le roaming permet à un appareil mobile de se rattacher automatiquement au point d'accès le plus proche/le plus puissant parmi plusieurs bornes partageant le même SSID, sans interrompre la connexion de l'utilisateur."
  },
  {
    "cat": "Wi-Fi",
    "type": "qcm",
    "q": "Que signifie qu'un réseau Wi-Fi subit des interférences ?",
    "c": [
      "d'autres signaux radio perturbent la réception ou l'émission du signal Wi-Fi",
      "le mot de passe du réseau a été deviné",
      "le câble Ethernet du point d'accès est débranché",
      "le point d'accès est éteint"
    ],
    "a": 0,
    "exp": "Les interférences viennent d'autres équipements émettant sur la même fréquence (autres Wi-Fi, micro-ondes, téléphones sans fil...) et se traduisent par des pertes de paquets, une latence accrue ou un débit réduit, sans que la connexion soit forcément coupée."
  },
  {
    "cat": "Wi-Fi",
    "type": "text",
    "q": "Quel est le nom du protocole d'authentification Wi-Fi d'entreprise qui s'appuie sur un serveur RADIUS (souvent noté 802.1X) ?",
    "reponse": "WPA2-Enterprise",
    "exp": "En mode Enterprise, chaque utilisateur s'authentifie avec ses propres identifiants auprès d'un serveur RADIUS via le protocole 802.1X, contrairement au mode Personal (WPA2-PSK) qui utilise une clé partagée unique pour tout le monde.",
    "accept": [
      "wpa2 enterprise",
      "802.1x",
      "radius"
    ],
    "acceptedAnswers": [
      "wpa2-enterprise",
      "wpa2 enterprise",
      "802.1x",
      "radius"
    ],
    "displayAnswers": [
      "WPA2-Enterprise",
      "802.1X"
    ]
  },
  {
    "cat": "Virtualisation & Cloud",
    "type": "match",
    "q": "Relie chaque modèle de service cloud à sa définition.",
    "pairs": [
      {
        "l": "IaaS",
        "r": "l'infrastructure (serveurs, stockage, réseau virtualisés) est louée"
      },
      {
        "l": "PaaS",
        "r": "une plateforme d'exécution est fournie, sans gérer l'OS sous-jacent"
      },
      {
        "l": "SaaS",
        "r": "un logiciel complet est utilisé directement via Internet"
      }
    ],
    "exp": "Ces trois modèles se distinguent par le niveau de responsabilité laissé au client : en IaaS le client gère l'OS et les applications sur une infrastructure louée, en PaaS il ne gère que son code/application sur une plateforme déjà prête, et en SaaS il utilise directement un logiciel fini (ex: messagerie en ligne) sans rien administrer techniquement."
  },
  {
    "cat": "Virtualisation & Cloud",
    "type": "qcm",
    "q": "Quelle est la différence principale entre un hyperviseur de type 1 et de type 2 ?",
    "c": [
      "le type 1 s'installe directement sur le matériel, le type 2 s'exécute au-dessus d'un OS hôte",
      "le type 1 est gratuit, le type 2 est payant",
      "le type 2 ne supporte pas les machines virtuelles Windows",
      "il n'y a aucune différence technique"
    ],
    "a": 0,
    "exp": "Un hyperviseur de type 1 (bare-metal, ex: VMware ESXi, Hyper-V) s'exécute directement sur le matériel pour de meilleures performances, typiquement en environnement serveur. Un hyperviseur de type 2 (ex: VirtualBox, VMware Workstation) tourne comme une application au-dessus d'un système d'exploitation existant, plus adapté à un usage bureautique/test."
  },
  {
    "cat": "Virtualisation & Cloud",
    "type": "qcm",
    "q": "Qu'est-ce qu'un snapshot dans un environnement de virtualisation ?",
    "c": [
      "une image de l'état d'une machine virtuelle à un instant donné, pour pouvoir y revenir",
      "une sauvegarde complète du système, généralement stockée sur bande magnétique",
      "un clone permanent et totalement indépendant de la machine virtuelle d'origine",
      "une mise à jour automatique appliquée au système d'exploitation de la VM"
    ],
    "a": 0,
    "exp": "Un snapshot capture l'état (disque, mémoire, configuration) d'une VM à un instant T, permettant de revenir rapidement en arrière en cas de problème, par exemple avant une mise à jour risquée. Ce n'est pas une sauvegarde à long terme : les snapshots s'accumulent et dégradent les performances s'ils sont conservés trop longtemps."
  },
  {
    "cat": "Virtualisation & Cloud",
    "type": "qcm",
    "q": "Quel est l'intérêt principal des conteneurs (ex: Docker) par rapport aux machines virtuelles classiques ?",
    "c": [
      "ils partagent le noyau de l'OS hôte et démarrent plus vite en consommant moins de ressources",
      "ils offrent une isolation plus forte que les VM",
      "ils ne peuvent exécuter qu'un seul type de langage de programmation",
      "ils remplacent obligatoirement l'hyperviseur"
    ],
    "a": 0,
    "exp": "Contrairement à une VM qui embarque son propre noyau complet, un conteneur partage le noyau du système hôte et n'embarque que l'application et ses dépendances : il est donc beaucoup plus léger et rapide à démarrer, au prix d'une isolation un peu moins forte qu'une VM."
  },
  {
    "cat": "Virtualisation & Cloud",
    "type": "qcm",
    "q": "Qu'est-ce que la haute disponibilité (HA) dans un cluster de virtualisation ?",
    "c": [
      "le redémarrage automatique des VM sur un autre hôte en cas de panne matérielle",
      "la sauvegarde automatique quotidienne des VM",
      "le chiffrement automatique du disque des VM",
      "la mise à jour automatique de l'hyperviseur"
    ],
    "a": 0,
    "exp": "La haute disponibilité surveille l'état des hôtes physiques d'un cluster : si l'un tombe en panne, les VM qu'il hébergeait sont automatiquement redémarrées sur un autre hôte du cluster pour limiter l'interruption de service."
  },
  {
    "cat": "Virtualisation & Cloud",
    "type": "qcm",
    "q": "Que permet la migration à chaud (vMotion / Live Migration) d'une machine virtuelle ?",
    "c": [
      "déplacer une VM en cours d'exécution d'un hôte physique à un autre sans coupure de service",
      "créer une copie totalement identique et indépendante d'une VM existante",
      "convertir une machine virtuelle classique en conteneur applicatif léger",
      "sauvegarder une machine virtuelle vers un support de stockage externe"
    ],
    "a": 0,
    "exp": "La migration à chaud transfère la mémoire et l'état d'exécution d'une VM active vers un autre serveur physique, ce qui permet par exemple de libérer un hôte pour maintenance sans interrompre le service rendu par la VM."
  },
  {
    "cat": "Bash & PowerShell",
    "type": "order",
    "q": "Remets dans l'ordre logique les étapes d'un script qui vérifie si un fichier existe avant de le lire.",
    "items": [
      "Déclarer la variable contenant le chemin du fichier",
      "Tester l'existence du fichier avec une condition (if [ -f ... ])",
      "Si le test réussit, lire ou afficher le contenu du fichier",
      "Sinon, afficher un message d'erreur"
    ],
    "exp": "Un script robuste vérifie toujours les préconditions avant d'agir : on définit d'abord ce sur quoi on travaille, on teste sa validité, puis on agit différemment selon que le test réussit ou échoue, plutôt que de supposer que le fichier existe."
  },
  {
    "cat": "Bash & PowerShell",
    "type": "qcm",
    "q": "En Bash, quelle structure permet de répéter une commande tant qu'une condition est vraie ?",
    "c": [
      "while",
      "if",
      "case",
      "function"
    ],
    "a": 0,
    "exp": "La boucle while répète un bloc d'instructions tant que sa condition reste vraie. if exécute un bloc une seule fois selon une condition, case compare une valeur à plusieurs motifs, et function définit un bloc réutilisable."
  },
  {
    "cat": "Bash & PowerShell",
    "type": "qcm",
    "q": "Que signifie le shebang « #!/bin/bash » en première ligne d'un script ?",
    "c": [
      "il indique quel interpréteur doit exécuter le script",
      "c'est un simple commentaire ignoré",
      "il chiffre le contenu du script",
      "il rend le script exécutable automatiquement"
    ],
    "a": 0,
    "exp": "Le shebang indique au système quel programme utiliser pour interpréter le fichier lorsqu'il est exécuté directement (./script.sh). Il ne rend pas le script exécutable pour autant : il faut aussi lui donner le droit +x avec chmod."
  },
  {
    "cat": "Bash & PowerShell",
    "type": "text",
    "q": "Quelle commande PowerShell permet de lister les processus en cours d'exécution ?",
    "reponse": "Get-Process",
    "exp": "Get-Process affiche la liste des processus actifs avec leur utilisation CPU et mémoire, l'équivalent PowerShell de la commande ps sous Linux.",
    "accept": [
      "get-process"
    ]
  },
  {
    "cat": "Bash & PowerShell",
    "type": "text",
    "q": "Quelle commande PowerShell permet d'arrêter un processus en cours d'exécution ?",
    "reponse": "Stop-Process",
    "exp": "Stop-Process termine un processus, généralement identifié par son nom ou son PID, l'équivalent PowerShell de kill sous Linux.",
    "accept": [
      "stop-process"
    ]
  },
  {
    "cat": "Bash & PowerShell",
    "type": "qcm",
    "q": "En Bash, à quoi sert la variable spéciale « $? » juste après l'exécution d'une commande ?",
    "c": [
      "elle contient le code de retour de la dernière commande",
      "elle contient le nom de l'utilisateur courant",
      "elle contient le répertoire courant",
      "elle contient la liste des variables d'environnement"
    ],
    "a": 0,
    "exp": "$? renvoie le code de sortie de la commande précédente. Par convention, 0 signifie que la commande s'est bien terminée, et toute autre valeur indique un type d'erreur particulier, ce qui permet d'enchaîner des actions conditionnelles dans un script."
  },
  {
    "cat": "Bash & PowerShell",
    "type": "qcm",
    "q": "Quelle est la philosophie de la syntaxe des cmdlets PowerShell (ex: Get-Service, Set-Item) ?",
    "c": [
      "Verbe-Nom, pour rendre les commandes prévisibles et lisibles",
      "Nom-Verbe, pour prioriser l'objet concerné",
      "des noms totalement libres sans convention",
      "des abréviations aléatoires héritées d'Unix"
    ],
    "a": 0,
    "exp": "PowerShell impose une convention Verbe-Nom (Get-, Set-, Stop-, New-, Remove-...) qui rend les commandes prévisibles : une fois qu'on connaît les verbes standards, on peut deviner beaucoup de cmdlets sans les avoir apprises par cœur."
  },
  {
    "cat": "Bash & PowerShell",
    "type": "qcm",
    "q": "En Bash, quelle est la différence entre une variable définie simplement (VAR=valeur) et une variable exportée (export VAR=valeur) ?",
    "c": [
      "la variable exportée est transmise aux sous-processus lancés depuis le script",
      "il n'y a aucune différence pratique",
      "une variable exportée devient constante et non modifiable",
      "seule la variable exportée peut contenir du texte"
    ],
    "a": 0,
    "exp": "Une variable simple n'existe que dans le shell ou le script courant. Avec export, elle est ajoutée à l'environnement et devient donc accessible aux commandes et sous-scripts lancés depuis ce shell."
  },
  {
    "cat": "Firewall, VPN & sécurité",
    "type": "qcm",
    "q": "Quel est le rôle principal d'un pare-feu ?",
    "c": [
      "filtrer le trafic réseau selon des règles définies",
      "filtrer les échanges selon des règles définies",
      "chiffrer les connexions vers Internet",
      "assigner des adresses IP aux machines"
    ],
    "a": 0,
    "exp": "Un pare-feu examine les paquets qui le traversent et applique des règles d'autorisation ou de blocage basées sur des critères comme l'adresse IP source/destination, le port ou le protocole, afin de limiter le trafic aux échanges légitimes."
  },
  {
    "cat": "Firewall, VPN & sécurité",
    "type": "scenario",
    "q": "Un serveur web doit rester joignable en HTTPS depuis Internet, mais toutes les autres connexions entrantes doivent être bloquées. Quelle règle de pare-feu appliquer ?",
    "c": [
      "autoriser uniquement le port 443 en entrée, bloquer tout le reste par défaut",
      "autoriser tous les ports en entrée puis bloquer un par un ceux non désirés",
      "bloquer uniquement le port 443",
      "désactiver complètement le pare-feu"
    ],
    "a": 0,
    "exp": "La bonne pratique est le principe de moindre privilège : tout bloquer par défaut, puis n'ouvrir explicitement que ce qui est nécessaire au service (ici le port 443/TCP pour HTTPS). Partir d'une politique « tout autoriser » augmente le risque d'oublier de fermer un port sensible."
  },
  {
    "cat": "Firewall, VPN & sécurité",
    "type": "qcm",
    "q": "Quel est l'objectif principal d'un VPN (réseau privé virtuel) ?",
    "c": [
      "créer un tunnel chiffré entre deux points à travers un réseau public comme Internet",
      "augmenter significativement la vitesse de la connexion Internet de l'utilisateur",
      "remplacer entièrement le pare-feu déjà déployé au sein de l'entreprise",
      "attribuer des adresses IP publiques fixes à chacun des postes du réseau"
    ],
    "a": 0,
    "exp": "Un VPN encapsule et chiffre le trafic entre deux extrémités (un utilisateur nomade et son entreprise, ou deux sites distants) pour que les données circulent de façon confidentielle et intègre même en traversant un réseau public non maîtrisé."
  },
  {
    "cat": "Firewall, VPN & sécurité",
    "type": "qcm",
    "q": "Qu'est-ce que le principe du moindre privilège en sécurité informatique ?",
    "c": [
      "ne donner à chaque utilisateur ou service que les droits strictement nécessaires à son besoin",
      "donner tous les droits par défaut puis les restreindre au cas par cas",
      "réserver les droits d'administration au seul service informatique, sans exception",
      "supprimer tous les comptes utilisateurs inactifs"
    ],
    "a": 0,
    "exp": "Le moindre privilège limite l'impact d'une erreur ou d'une compromission : si un compte n'a que les droits dont il a besoin, un attaquant qui le compromet ne peut pas aller au-delà de ce périmètre restreint."
  },
  {
    "cat": "Firewall, VPN & sécurité",
    "type": "qcm",
    "q": "Que permet l'authentification multifacteur (MFA) ?",
    "c": [
      "exiger au moins deux preuves d'identité différentes pour se connecter",
      "remplacer totalement le mot de passe par une empreinte digitale",
      "chiffrer les fichiers stockés sur le poste",
      "bloquer automatiquement les tentatives de connexion la nuit"
    ],
    "a": 0,
    "exp": "Le MFA combine plusieurs catégories de preuves (ce que l'on sait comme un mot de passe, ce que l'on possède comme un téléphone, ce que l'on est comme une empreinte) : même si un facteur est compromis (mot de passe volé), l'accès reste bloqué sans le second facteur."
  },
  {
    "cat": "Firewall, VPN & sécurité",
    "type": "qcm",
    "q": "Qu'est-ce qu'une attaque par déni de service (DoS) ?",
    "c": [
      "submerger un service de requêtes pour le rendre indisponible aux utilisateurs légitimes",
      "dérober des identifiants de connexion en se faisant passer pour un site légitime",
      "intercepter discrètement le trafic réseau échangé entre deux machines",
      "installer discrètement un logiciel espion sur le poste d'un utilisateur"
    ],
    "a": 0,
    "exp": "Une attaque DoS vise à épuiser les ressources d'un service (bande passante, connexions, CPU) en le saturant de requêtes, jusqu'à ce qu'il ne puisse plus répondre aux utilisateurs légitimes. Lorsqu'elle est menée depuis de nombreuses machines à la fois, on parle de DDoS (distribué)."
  },
  {
    "cat": "Firewall, VPN & sécurité",
    "type": "text",
    "q": "Quel est le nom du protocole qui sécurise les échanges HTTPS en assurant chiffrement et authentification du serveur ?",
    "reponse": "TLS",
    "exp": "TLS (Transport Layer Security), successeur de SSL, chiffre les échanges et permet au client de vérifier l'identité du serveur via un certificat, ce qui transforme HTTP en HTTPS.",
    "accept": [
      "ssl",
      "ssl/tls",
      "tls/ssl"
    ]
  },
  {
    "cat": "Firewall, VPN & sécurité",
    "type": "qcm",
    "q": "Qu'est-ce qu'une DMZ (zone démilitarisée) dans une architecture réseau ?",
    "c": [
      "un sous-réseau isolé qui héberge les services exposés à Internet, séparé du réseau interne",
      "un réseau exclusivement réservé aux comptes disposant de droits d'administration",
      "une zone du réseau où toute connexion Wi-Fi est volontairement désactivée",
      "un serveur dédié qui conserve une copie de sauvegarde hors ligne"
    ],
    "a": 0,
    "exp": "La DMZ isole les serveurs qui doivent être accessibles depuis Internet (site web, messagerie...) du réseau interne de l'entreprise : si un serveur de la DMZ est compromis, l'attaquant ne se retrouve pas directement sur le réseau interne sensible."
  },
  {
    "cat": "Sauvegardes & restauration",
    "type": "match",
    "q": "Relie chaque type de sauvegarde à sa définition.",
    "pairs": [
      {
        "l": "Complète",
        "r": "copie l'intégralité des données à chaque exécution"
      },
      {
        "l": "Incrémentale",
        "r": "copie uniquement ce qui a changé depuis la dernière sauvegarde (complète ou incrémentale)"
      },
      {
        "l": "Différentielle",
        "r": "copie tout ce qui a changé depuis la dernière sauvegarde complète"
      }
    ],
    "exp": "La complète est la plus longue à réaliser mais la plus simple à restaurer (un seul jeu de données). L'incrémentale est la plus rapide à effectuer mais nécessite de restaurer la complète puis chaque incrément dans l'ordre. La différentielle est un compromis : plus longue que l'incrémentale au fil du temps, mais elle ne nécessite que la complète + la dernière différentielle pour restaurer."
  },
  {
    "cat": "Sauvegardes & restauration",
    "type": "calculation",
    "q": "Une entreprise accepte de perdre au maximum 4 heures de données, et doit pouvoir relancer son service en moins de 2 heures après un incident. Indique :",
    "fields": [
      {
        "label": "RPO (perte de données maximale acceptable)",
        "answer": "4 heures"
      },
      {
        "label": "RTO (délai maximal acceptable de reprise)",
        "answer": "2 heures"
      }
    ],
    "exp": "Le RPO (Recovery Point Objective) définit la fréquence minimale des sauvegardes : avec un RPO de 4h, il faut sauvegarder au moins toutes les 4 heures. Le RTO (Recovery Time Objective) définit la rapidité de reprise attendue après un incident, ici 2 heures, ce qui oriente le choix des solutions de restauration (snapshots, réplication, etc.)."
  },
  {
    "cat": "Sauvegardes & restauration",
    "type": "text",
    "q": "Quelle règle de sauvegarde recommande 3 copies, 2 supports différents et 1 copie hors site ?",
    "reponse": "3-2-1",
    "exp": "La règle 3-2-1 est un principe de sauvegarde qui recommande trois copies de données, sur deux supports différents, dont une hors site.",
    "acceptedAnswers": [
      "3-2-1",
      "3 2 1",
      "3-2-1 rule"
    ],
    "displayAnswers": [
      "3-2-1"
    ]
  },
  {
    "cat": "Sauvegardes & restauration",
    "type": "qcm",
    "q": "Pourquoi la règle 3-2-1 recommande-t-elle de conserver une copie de sauvegarde hors site ?",
    "c": [
      "pour se prémunir d'un sinistre physique touchant le site principal",
      "principalement pour réduire la durée nécessaire à une restauration complète",
      "parce que la réglementation l'impose dans absolument toutes les situations",
      "avant tout pour économiser de l'espace de stockage sur le site principal"
    ],
    "a": 0,
    "exp": "La règle 3-2-1 (3 copies, 2 supports différents, 1 copie hors site) vise à éviter qu'un même sinistre physique détruise à la fois les données de production et toutes leurs sauvegardes. Une copie hors site (ou dans le cloud) survit à un incendie ou un vol sur le site principal."
  },
  {
    "cat": "Sauvegardes & restauration",
    "type": "qcm",
    "q": "Qu'apporte une sauvegarde immuable par rapport à une sauvegarde classique ?",
    "c": [
      "elle ne peut être ni modifiée ni supprimée pendant une durée définie, même par un administrateur ou un rançongiciel",
      "elle occupe systématiquement moins d'espace disque qu'une sauvegarde classique",
      "elle se restaure automatiquement chaque nuit sans aucune intervention",
      "elle ne nécessite plus aucune vérification d'intégrité une fois créée"
    ],
    "a": 0,
    "exp": "L'immutabilité verrouille la sauvegarde contre toute altération ou suppression pendant une période fixée à l'avance. C'est une protection efficace contre les rançongiciels qui cherchent justement à chiffrer ou supprimer les sauvegardes pour empêcher toute restauration sans payer la rançon."
  },
  {
    "cat": "Sauvegardes & restauration",
    "type": "scenario",
    "q": "Après une sauvegarde complète le dimanche, l'entreprise effectue des sauvegardes incrémentales chaque soir. Le serveur tombe en panne le jeudi matin. Que faut-il restaurer, et dans quel ordre ?",
    "c": [
      "la complète du dimanche, puis les incrémentales de lundi, mardi et mercredi, dans l'ordre chronologique",
      "uniquement l'incrémentale de mercredi soir",
      "la complète du dimanche uniquement",
      "toutes les sauvegardes en même temps, l'ordre n'a pas d'importance"
    ],
    "a": 0,
    "exp": "Une sauvegarde incrémentale ne contient que les changements depuis la dernière sauvegarde (complète ou incrémentale). Pour reconstituer l'état du serveur juste avant la panne, il faut donc restaurer la base complète puis rejouer chaque incrément dans l'ordre chronologique exact, sans en sauter aucun."
  },
  {
    "cat": "Sauvegardes & restauration",
    "type": "qcm",
    "q": "Pourquoi tester régulièrement la restauration d'une sauvegarde est-il essentiel ?",
    "c": [
      "une sauvegarde non testée peut s'avérer corrompue ou incomplète au moment où on en a réellement besoin",
      "cela permet avant tout de libérer de l'espace disque supplémentaire",
      "cela dispense l'entreprise de devoir appliquer la règle de sauvegarde 3-2-1",
      "cela accélère automatiquement l'exécution des sauvegardes suivantes"
    ],
    "a": 0,
    "exp": "Une sauvegarde qui semble s'être terminée sans erreur n'est pas une garantie de restaurabilité (fichier corrompu, support défaillant, procédure incomplète...). Seul un test de restauration réel confirme que les données sont exploitables le jour où un incident survient."
  },
  {
    "cat": "Déploiement de postes",
    "type": "match",
    "q": "Relie chaque terme de déploiement à sa définition.",
    "pairs": [
      {
        "l": "PXE",
        "r": "démarrage d'un poste directement depuis le réseau, sans support local"
      },
      {
        "l": "Sysprep",
        "r": "généralise une installation Windows avant d'en faire une image"
      },
      {
        "l": "WDS",
        "r": "service Windows qui déploie des images système via le réseau"
      },
      {
        "l": "Image système (WIM)",
        "r": "copie complète et préconfigurée d'un système prête à être déployée"
      }
    ],
    "exp": "PXE permet à un poste vierge de démarrer via le réseau pour recevoir une image ; Sysprep retire les informations propres à une machine (SID, nom...) pour rendre une image réutilisable sur d'autres postes ; WDS orchestre la distribution de ces images ; et le fichier WIM contient l'image du système à déployer."
  },
  {
    "cat": "Déploiement de postes",
    "type": "qcm",
    "q": "Pourquoi doit-on exécuter Sysprep avant de capturer l'image d'un poste de référence ?",
    "c": [
      "pour supprimer les identifiants uniques et éviter les conflits lors du déploiement",
      "pour accélérer artificiellement la durée nécessaire à la capture de l'image",
      "pour installer automatiquement les pilotes manquants sur le poste de référence",
      "pour chiffrer l'image obtenue avant de la stocker sur le serveur"
    ],
    "a": 0,
    "exp": "Sans Sysprep, chaque poste cloné à partir de la même image partagerait le même identifiant de sécurité (SID), ce qui peut provoquer des conflits dans un domaine Active Directory. Sysprep généralise l'image en effaçant ces éléments propres à la machine d'origine."
  },
  {
    "cat": "Déploiement de postes",
    "type": "scenario",
    "q": "Une entreprise doit déployer Windows sur 50 nouveaux postes identiques rapidement. Quelle méthode est la plus adaptée ?",
    "c": [
      "créer une image de référence avec Sysprep et la déployer via PXE/WDS",
      "installer manuellement Windows sur chaque poste un par un",
      "envoyer un lien de téléchargement à chaque utilisateur",
      "cloner le disque dur en le démontant physiquement de chaque poste"
    ],
    "a": 0,
    "exp": "Pour un déploiement en nombre, l'approche standard consiste à préparer une image de référence (installée, configurée puis généralisée avec Sysprep) et à la distribuer automatiquement aux postes via PXE et un service comme WDS, ce qui est bien plus rapide et homogène qu'une installation manuelle poste par poste."
  },
  {
    "cat": "Déploiement de postes",
    "type": "qcm",
    "q": "Qu'est-ce que le MDT apporte par rapport à WDS seul ?",
    "c": [
      "une automatisation plus poussée du déploiement",
      "il remplace intégralement Active Directory dans l'infrastructure de l'entreprise",
      "il ne peut fonctionner qu'avec des postes équipés d'une distribution Linux",
      "il ne sert en réalité qu'à assurer la sauvegarde régulière des données"
    ],
    "a": 0,
    "exp": "MDT s'appuie sur WDS pour le transport réseau mais ajoute des séquences de tâches automatisées : installation des pilotes adaptés au modèle, applications, paramètres régionaux... ce qui pousse l'automatisation plus loin qu'un simple déploiement d'image brute."
  },
  {
    "cat": "Support & méthodologie",
    "type": "qcm",
    "q": "Quelle est la différence entre une demande et un incident en centre de services ?",
    "c": [
      "une demande est une requête de service planifiée, un incident est une interruption ou une dégradation non planifiée",
      "ce sont deux termes strictement identiques",
      "une demande concerne le matériel, un incident uniquement le logiciel",
      "un incident est toujours moins prioritaire qu'une demande"
    ],
    "a": 0,
    "exp": "ITIL distingue clairement les deux : une demande de service (accès à une application, création de compte...) est planifiable et suit un processus standard, alors qu'un incident correspond à un dysfonctionnement non prévu qui dégrade ou interrompt un service déjà en place."
  },
  {
    "cat": "Support & méthodologie",
    "type": "text",
    "q": "Comment appelle-t-on le transfert d'un ticket vers un niveau de support plus qualifié ou un service compétent ?",
    "reponse": "escalade",
    "exp": "L'escalade intervient quand le technicien de premier niveau ne peut pas résoudre le ticket seul : il le transmet à un niveau 2/3 ou à un service spécialisé, avec l'historique déjà renseigné pour éviter de faire répéter le problème à l'utilisateur.",
    "acceptedAnswers": [
      "escalade",
      "escalation"
    ],
    "displayAnswers": [
      "escalade"
    ]
  },
  {
    "cat": "Support & méthodologie",
    "type": "qcm",
    "q": "Que définit un SLA ?",
    "c": [
      "un engagement contractuel sur le niveau de service attendu",
      "la liste complète des mots de passe attribués à chaque utilisateur",
      "le plan détaillant l'adressage IP retenu pour l'ensemble de l'entreprise",
      "la procédure décrivant comment sauvegarder les serveurs de production"
    ],
    "a": 0,
    "exp": "Un SLA formalise des engagements mesurables entre un prestataire et son client : par exemple un délai maximal de prise en charge selon la priorité du ticket, ou un taux de disponibilité minimal d'un service."
  },
  {
    "cat": "Support & méthodologie",
    "type": "qcm",
    "q": "Quel est l'intérêt principal d'une base de connaissances pour un technicien support ?",
    "c": [
      "capitaliser les solutions déjà trouvées pour résoudre plus vite des problèmes similaires",
      "remplacer complètement le besoin d'ouvrir des tickets",
      "stocker les sauvegardes des serveurs",
      "chiffrer les échanges avec les utilisateurs"
    ],
    "a": 0,
    "exp": "Une base de connaissances centralise les procédures et solutions déjà éprouvées : un technicien (ou même l'utilisateur en libre-service) peut ainsi résoudre un problème récurrent sans repartir de zéro, ce qui réduit le temps de traitement moyen."
  },
  {
    "cat": "Support & méthodologie",
    "type": "qcm",
    "q": "Face à un utilisateur stressé ou agressif au téléphone, quelle attitude est recommandée ?",
    "c": [
      "rester calme, reformuler sa demande et le rassurer sur la prise en charge",
      "raccrocher immédiatement",
      "hausser le ton pour reprendre le contrôle de l'échange",
      "transférer l'appel sans explication"
    ],
    "a": 0,
    "exp": "Garder son calme et reformuler montre à l'utilisateur qu'il est écouté, ce qui désamorce souvent la tension. Couper la communication ou hausser le ton ne fait qu'aggraver la situation et nuit à la relation de confiance."
  },
  {
    "cat": "Support & méthodologie",
    "type": "qcm",
    "q": "Qu'est-ce qu'un outil ITSM ?",
    "c": [
      "un logiciel de gestion des services informatiquesGLPI",
      "un logiciel de supervision réseau qui surveille en continu la disponibilité des serveurs",
      "un logiciel de gestion de projet dédié uniquement à la planification des sprints",
      "un logiciel de messagerie interne réservé aux échanges entre techniciens"
    ],
    "a": 0,
    "exp": "Un outil ITSM (IT Service Management) centralise la gestion du support : ouverture et suivi des tickets, inventaire du parc, base de connaissances... GLPI, ServiceNow ou Jira Service Management en sont des exemples courants."
  },
  {
    "cat": "Support & méthodologie",
    "type": "qcm",
    "q": "Pourquoi la traçabilité apportée par un ticket est-elle importante dans le support ?",
    "c": [
      "elle garde un historique exploitable des actions, utile pour le suivi, les statistiques et les audits",
      "elle sert uniquement à établir la facturation adressée ensuite au client",
      "elle remplace totalement le besoin de sauvegarder les données de l'entreprise",
      "elle perd toute utilité dès l'instant où l'incident a été résolu"
    ],
    "a": 0,
    "exp": "Le ticket conserve la trace de chaque étape (déclaration, diagnostic, actions menées, résolution) : cela permet de reprendre un dossier interrompu, de produire des statistiques (temps moyen de résolution, incidents récurrents) et de justifier le travail effectué lors d'un audit."
  },
  {
    "cat": "Support & méthodologie",
    "type": "qcm",
    "q": "Sur quels critères priorise-t-on généralement un ticket ?",
    "c": [
      "l'impact et l'urgence de la situation",
      "l'ordre alphabétique du nom de l'utilisateur",
      "la taille du message envoyé",
      "l'heure d'ouverture du ticket uniquement"
    ],
    "a": 0,
    "exp": "La priorité résulte généralement d'une matrice croisant l'impact (combien de personnes ou de services sont affectés) et l'urgence (à quelle vitesse la situation doit être traitée) : un serveur de production en panne pour tout le monde est plus prioritaire qu'un problème d'imprimante pour un seul utilisateur."
  },
  {
    "cat": "Support & méthodologie",
    "type": "order",
    "q": "Remets dans l'ordre le cycle de vie classique d'un ticket.",
    "items": [
      "Ouverture et qualification du ticket",
      "Priorisation",
      "Diagnostic et traitement (éventuellement escalade)",
      "Résolution",
      "Clôture avec validation de l'utilisateur"
    ],
    "exp": "Un ticket suit un cycle de vie structuré : il est d'abord qualifié (que se passe-t-il ?), priorisé, puis diagnostiqué et traité (avec escalade si besoin), avant d'être résolu et enfin clôturé, idéalement après confirmation de l'utilisateur que le problème est bien réglé."
  },
  {
    "cat": "Support & méthodologie",
    "type": "qcm",
    "q": "Quel est l'objectif de sensibiliser un utilisateur à la sécurité pendant une intervention support ?",
    "c": [
      "réduire les risques futurs en plus de résoudre le problème immédiat",
      "gagner du temps sur l'intervention en cours en évitant les explications superflues",
      "éviter à l'utilisateur d'avoir à ouvrir un ticket la prochaine fois",
      "remplacer les outils de sécurité techniques déjà déployés sur le poste"
    ],
    "a": 0,
    "exp": "Le technicien est souvent le point de contact le plus direct avec l'utilisateur : profiter d'une intervention pour rappeler quelques bons réflexes (ne pas cliquer sur un lien douteux, verrouiller sa session...) renforce la sécurité globale sans remplacer les protections techniques (antivirus, pare-feu...)."
  },
  {
    "cat": "Support & méthodologie",
    "type": "qcm",
    "q": "Quel est l'impact principal du RGPD sur le support utilisateur ?",
    "c": [
      "il impose de protéger les données personnelles manipulées",
      "il interdit purement et simplement toute prise de main à distance sur un poste",
      "il ne rend les sauvegardes obligatoires que pour les entreprises situées en Europe",
      "il ne s'applique en réalité qu'aux entreprises comptant plus de 500 salariés"
    ],
    "a": 0,
    "exp": "Le RGPD encadre le traitement des données personnelles : un technicien support qui accède à des données d'un utilisateur (mails, documents...) doit limiter cet accès au strict nécessaire, ne pas les conserver plus longtemps que nécessaire, et signaler toute fuite de données constatée."
  },
  {
    "cat": "Support & méthodologie",
    "type": "text",
    "q": "Quel référentiel de bonnes pratiques définit un cycle de vie du service en 5 phases (stratégie, conception, transition, exploitation, amélioration continue) ?",
    "reponse": "ITIL",
    "exp": "ITIL (Information Technology Infrastructure Library) est un ensemble de bonnes pratiques de gestion des services IT, largement utilisé pour structurer les processus de support (gestion des incidents, des problèmes, des changements...).",
    "acceptedAnswers": [
      "itil",
      "information technology infrastructure library"
    ],
    "displayAnswers": [
      "ITIL"
    ]
  },
  {
    "cat": "Support & méthodologie",
    "type": "order",
    "q": "Remets dans l'ordre les 5 phases du cycle de vie d'un service selon ITIL.",
    "items": [
      "Stratégie de services",
      "Conception de services",
      "Transition des services",
      "Exploitation des services",
      "Amélioration continue des services"
    ],
    "exp": "ITIL structure la vie d'un service informatique en 5 grandes phases, de sa définition stratégique jusqu'à son exploitation quotidienne, avec une boucle d'amélioration continue qui vient réinjecter du retour d'expérience dans les phases précédentes."
  },
  {
    "cat": "Support & méthodologie",
    "type": "qcm",
    "q": "Quel est le rôle de la CNIL en France ?",
    "c": [
      "veiller au respect de la loi Informatique et Libertés et du RGPD, protéger les données personnelles",
      "gérer l'attribution et le renouvellement des noms de domaine en .fr",
      "délivrer les certificats SSL reconnus au niveau national",
      "attribuer les plages d'adresses IP publiques aux fournisseurs d'accès"
    ],
    "a": 0,
    "exp": "La CNIL (Commission Nationale de l'Informatique et des Libertés) est l'autorité française chargée de veiller à la protection des données personnelles, de contrôler les organismes et de sanctionner les manquements au RGPD."
  },
  {
    "cat": "Support & méthodologie",
    "type": "qcm",
    "q": "Quel est le rôle de l'ANSSI ?",
    "c": [
      "l'autorité nationale française en matière de sécurité et de défense des systèmes d'information",
      "un fournisseur d'accès à Internet proposant des offres dédiées aux professionnels",
      "un organisme chargé de certifier la qualité des câbles et équipements réseau",
      "une association de défense des droits des consommateurs du numérique"
    ],
    "a": 0,
    "exp": "L'ANSSI (Agence Nationale de la Sécurité des Systèmes d'Information) accompagne les administrations et les entreprises françaises face aux risques cyber, émet des recommandations techniques et intervient en cas d'incident majeur de sécurité."
  },
  {
    "cat": "Support & méthodologie",
    "type": "qcm",
    "q": "En cas de découverte d'une faille de sécurité critique, quelle est la première action à privilégier ?",
    "c": [
      "la remonter immédiatement selon la procédure définie avant toute autre action",
      "la publier sur les réseaux sociaux pour prévenir les utilisateurs",
      "l'exploiter soi-même pour vérifier son impact réel",
      "ne rien faire tant qu'elle n'est pas confirmée par un tiers"
    ],
    "a": 0,
    "exp": "Une faille critique doit être remontée sans délai à la personne ou l'équipe responsable de la sécurité, en suivant la procédure interne : cela permet de qualifier le risque et de décider des mesures (correctif, isolement, communication) de façon maîtrisée, sans l'exposer publiquement ni l'exploiter soi-même."
  },
  {
    "cat": "Support & méthodologie",
    "type": "qcm",
    "q": "Face à un désaccord technique avec un collègue, quelle approche est la plus professionnelle ?",
    "c": [
      "argumenter avec des faits techniques et rechercher un consensus, en impliquant un tiers si besoin",
      "imposer son point de vue car on est plus expérimenté",
      "ignorer le collègue et faire à sa manière sans en discuter",
      "escalader immédiatement au manager sans en avoir discuté d'abord"
    ],
    "a": 0,
    "exp": "Un désaccord technique se résout d'abord par l'échange d'arguments factuels (documentation, tests, retours d'expérience) entre les personnes concernées ; l'arbitrage d'un tiers ou de la hiérarchie reste une option en dernier recours si aucun consensus n'émerge."
  },
  {
    "cat": "Support & méthodologie",
    "type": "qcm",
    "q": "Pourquoi est-il important de documenter son travail pour l'équipe ?",
    "c": [
      "cela permet la continuité de service même en son absence et facilite la transmission des connaissances",
      "cela sert uniquement à justifier son temps de travail",
      "ce n'est utile que pour les débutants",
      "cela remplace la nécessité de former les nouveaux arrivants"
    ],
    "a": 0,
    "exp": "Une documentation à jour permet à un collègue de reprendre une tâche ou un incident en cas d'absence, réduit la dépendance à une seule personne (bus factor) et accélère l'intégration des nouveaux arrivants, sans pour autant remplacer une vraie formation."
  },
  {
    "cat": "Support & méthodologie",
    "type": "qcm",
    "q": "Comment organiser efficacement sa veille technologique en tant que technicien ?",
    "c": [
      "suivre régulièrement des sources fiables et tester les nouveautés en environnement de test",
      "attendre qu'un incident de sécurité survienne avant de commencer à se former",
      "se limiter durablement à une seule et même source d'information technique",
      "confier entièrement cette veille à un prestataire externe sans jamais s'impliquer"
    ],
    "a": 0,
    "exp": "Une veille efficace repose sur des sources fiables et régulièrement consultées (bulletins de sécurité type CERT-FR, notes de version des éditeurs, communautés techniques), avec une mise en pratique en environnement de test avant tout déploiement en production."
  },
  {
    "cat": "Windows Server & AD",
    "type": "qcm",
    "q": "Qu'est-ce qu'un Active Directory (AD) ?",
    "c": [
      "un service d'annuaire centralisant utilisateurs, ordinateurs et ressources d'un domaine Windows",
      "un antivirus intégré nativement à toutes les versions de Windows Server",
      "un protocole de chiffrement dédié à la protection des disques durs",
      "un outil qui sauvegarde automatiquement l'ensemble des serveurs du domaine"
    ],
    "a": 0,
    "exp": "Active Directory est le service d'annuaire de Microsoft : il stocke de façon centralisée les comptes utilisateurs, ordinateurs, groupes et stratégies (GPO) d'un domaine, et gère l'authentification et les autorisations associées."
  },
  {
    "cat": "Windows Server & AD",
    "type": "qcm",
    "q": "Quelle est la différence entre un groupe de sécurité et un groupe de distribution dans Active Directory ?",
    "c": [
      "le groupe de sécurité sert à attribuer des permissions, le groupe de distribution sert uniquement à diffuser des emails",
      "ce sont deux noms différents pour le même objet",
      "le groupe de distribution donne des droits sur les fichiers, pas le groupe de sécurité",
      "seul le groupe de sécurité peut contenir des utilisateurs"
    ],
    "a": 0,
    "exp": "Un groupe de sécurité peut se voir attribuer des permissions sur des ressources (fichiers, imprimantes...) en plus de servir de liste de diffusion, alors qu'un groupe de distribution ne sert qu'à envoyer des emails à ses membres, sans notion de droits d'accès."
  },
  {
    "cat": "Windows Server & AD",
    "type": "qcm",
    "q": "Qu'est-ce qu'une GPO (Group Policy Object) ?",
    "c": [
      "un objet regroupant des paramètres de configuration appliqués aux utilisateurs ou ordinateurs d'un domaine",
      "un type particulier de compte utilisateur disposant de droits étendus",
      "un protocole utilisé pour répliquer les données entre contrôleurs de domaine",
      "un outil dédié à la supervision en temps réel du trafic réseau"
    ],
    "a": 0,
    "exp": "Une GPO regroupe des réglages (restrictions, scripts de démarrage, déploiement de logiciels, paramètres de sécurité...) qui s'appliquent automatiquement aux comptes ou postes rattachés à l'OU, au domaine ou au site où elle est liée."
  },
  {
    "cat": "Windows Server & AD",
    "type": "text",
    "q": "Comment appelle-t-on la règle qui définit l'ordre d'application des GPO : Local, Site, Domaine, OU ?",
    "reponse": "LSDOU",
    "exp": "LSDOU résume l'ordre de traitement des GPO, du plus général (stratégie Locale de la machine) au plus spécifique (Unité d'Organisation) : en cas de conflit, c'est en général le dernier niveau appliqué (l'OU) qui l'emporte, sauf blocage d'héritage ou option « Enforced ».",
    "accept": [
      "l.s.d.o.u",
      "local site domaine ou"
    ],
    "acceptedAnswers": [
      "lsdou",
      "l.s.d.o.u",
      "local site domaine ou"
    ],
    "displayAnswers": [
      "LSDOU"
    ]
  },
  {
    "cat": "Windows Server & AD",
    "type": "order",
    "q": "Remets dans l'ordre la hiérarchie Active Directory, du plus large au plus précis.",
    "items": [
      "Forêt",
      "Arbre",
      "Domaine",
      "Unité d'Organisation (OU)"
    ],
    "exp": "La forêt est le conteneur le plus large et regroupe un ou plusieurs arbres de domaines partageant un schéma commun ; un arbre regroupe des domaines liés par un espace de noms continu ; un domaine est l'unité d'administration de base ; et l'OU permet d'organiser finement les objets à l'intérieur d'un domaine."
  },
  {
    "cat": "Windows Server & AD",
    "type": "qcm",
    "q": "Qu'est-ce que le Catalogue Global dans Active Directory ?",
    "c": [
      "une base répliquée qui contient un sous-ensemble des attributs de tous les objets de la forêt, utile pour les recherches multi-domaines",
      "le journal centralisé qui conserve durablement tous les événements systèmes et applicatifs de chaque serveur",
      "la liste complète des GPO actuellement appliquées à l'ensemble des objets d'un domaine donné",
      "le service chargé d'attribuer automatiquement les adresses IP à tous les postes du domaine"
    ],
    "a": 0,
    "exp": "Le Catalogue Global est hébergé par certains contrôleurs de domaine et permet de retrouver rapidement un objet (utilisateur, groupe...) n'importe où dans la forêt, sans avoir à interroger chaque domaine séparément."
  },
  {
    "cat": "Windows Server & AD",
    "type": "qcm",
    "q": "Que désignent les rôles FSMO dans Active Directory ?",
    "c": [
      "des rôles uniques assurés par certains contrôleurs de domaine pour éviter les conflits de réplication",
      "les droits spécifiques accordés à un administrateur local sur sa propre machine",
      "les différents niveaux de licence disponibles pour Windows Server",
      "les types de comptes de service utilisés pour exécuter certaines applications"
    ],
    "a": 0,
    "exp": "Les 5 rôles FSMO (Flexible Single Master Operations) sont des opérations qui ne peuvent être assurées que par un seul contrôleur de domaine à la fois dans la forêt ou le domaine (ex: maître RID, maître d'infrastructure, émulateur PDC...), afin d'éviter les incohérences liées à une réplication multi-maîtres."
  },
  {
    "cat": "Windows Server & AD",
    "type": "qcm",
    "q": "Qu'est-ce que le système de fichiers NTFS ?",
    "c": [
      "le système de fichiers de Windows qui gère notamment les permissions fines et le chiffrement",
      "un protocole qui permet de partager des fichiers entre plusieurs machines du réseau",
      "un format de fichier utilisé pour stocker une image disque complète",
      "un service d'annuaire qui centralise les comptes utilisateurs du domaine"
    ],
    "a": 0,
    "exp": "NTFS (New Technology File System) est le système de fichiers standard de Windows depuis plusieurs générations : il gère les permissions par utilisateur/groupe, la compression, le chiffrement (EFS) et la journalisation pour limiter la corruption en cas de coupure."
  },
  {
    "cat": "Windows Server & AD",
    "type": "text",
    "q": "Quel service réseau traduit les noms de domaine en adresses IP ?",
    "reponse": "DNS",
    "exp": "Le service DNS (Domain Name System) convertit un nom lisible (ex: serveur1.entreprise.local) en adresse IP exploitable par les machines, et inversement pour la résolution inverse.",
    "accept": [
      "dns"
    ]
  },
  {
    "cat": "Windows Server & AD",
    "type": "qcm",
    "q": "Qu'est-ce qu'une zone DNS de recherche inversée ?",
    "c": [
      "une zone qui permet de retrouver un nom d'hôte à partir d'une adresse IP",
      "une zone qui accélère la résolution DNS en cache",
      "une zone réservée aux serveurs DHCP",
      "une sauvegarde de la zone DNS principale"
    ],
    "a": 0,
    "exp": "Alors qu'une zone directe traduit un nom en IP, une zone inversée fait l'opération contraire (IP vers nom), en s'appuyant sur des enregistrements PTR organisés dans un domaine spécial (in-addr.arpa pour IPv4)."
  },
  {
    "cat": "Windows Server & AD",
    "type": "qcm",
    "q": "Qu'est-ce qu'une exclusion DHCP ?",
    "c": [
      "une plage d'adresses IP volontairement écartée de la distribution automatique",
      "une adresse IP toujours attribuée à la même machine",
      "un délai avant renouvellement du bail",
      "une machine bloquée sur le réseau"
    ],
    "a": 0,
    "exp": "Une exclusion retire une plage d'adresses de l'étendue DHCP pour éviter qu'elle ne soit distribuée automatiquement, par exemple parce que ces adresses sont déjà réservées à des équipements configurés en IP fixe (serveurs, imprimantes...)."
  },
  {
    "cat": "Windows Server & AD",
    "type": "qcm",
    "q": "Qu'est-ce qu'une réservation DHCP ?",
    "c": [
      "une adresse IP fixe attribuée à une machine précise via son adresse MAC, tout en restant gérée par le DHCP",
      "une plage d'adresses IP qui n'est jamais distribuée automatiquement par le serveur",
      "le délai maximal pendant lequel une adresse IP attribuée reste valide",
      "un mécanisme qui bloque temporairement l'accès réseau d'une machine"
    ],
    "a": 0,
    "exp": "Une réservation garantit qu'une machine identifiée par son adresse MAC recevra toujours la même adresse IP du serveur DHCP, combinant ainsi la stabilité d'une IP fixe et la simplicité de gestion centralisée du DHCP."
  },
  {
    "cat": "Windows Server & AD",
    "type": "text",
    "q": "Quel acronyme désigne les 4 échanges du processus d'obtention d'une adresse IP par DHCP (Discover, Offer, Request, Acknowledge) ?",
    "reponse": "DORA",
    "exp": "Le processus DORA décrit le dialogue entre client et serveur DHCP : le client diffuse un Discover, le serveur répond par une Offer, le client confirme par un Request, et le serveur valide par un Acknowledge.",
    "accept": [
      "d.o.r.a"
    ],
    "acceptedAnswers": [
      "dora",
      "d.o.r.a"
    ],
    "displayAnswers": [
      "DORA"
    ]
  },
  {
    "cat": "Windows Server & AD",
    "type": "order",
    "q": "Remets dans l'ordre les 4 échanges du processus DHCP (DORA).",
    "items": [
      "Discover : le client diffuse une requête pour trouver un serveur DHCP",
      "Offer : un serveur DHCP propose une adresse IP disponible",
      "Request : le client demande formellement cette adresse",
      "Acknowledge : le serveur confirme l'attribution de l'adresse"
    ],
    "exp": "DORA résume les 4 étapes de l'obtention automatique d'une adresse IP : découverte du serveur, proposition d'une adresse, demande formelle par le client, puis confirmation définitive du serveur."
  },
  {
    "cat": "Windows Server & AD",
    "type": "qcm",
    "q": "Quel outil Windows permet de consulter les journaux système, applicatifs et de sécurité d'un serveur ?",
    "c": [
      "l'Observateur d'événements",
      "le Gestionnaire des tâches",
      "le Gestionnaire de serveur",
      "PowerShell ISE"
    ],
    "a": 0,
    "exp": "L'Observateur d'événements (Event Viewer) centralise les journaux Windows (Système, Application, Sécurité...) et permet de rechercher des erreurs, avertissements ou événements de sécurité pour diagnostiquer un dysfonctionnement."
  },
  {
    "cat": "Windows Server & AD",
    "type": "qcm",
    "q": "Quelle est la différence entre un rôle et une fonctionnalité sous Windows Server ?",
    "c": [
      "un rôle définit la fonction principale du serveur, une fonctionnalité est un complément optionnel utilisable par un ou plusieurs rôles",
      "ce sont deux termes strictement équivalents qui désignent la même chose sous Windows Server",
      "une fonctionnalité ne peut jamais être installée autrement qu'en ligne de commande",
      "un rôle ne peut être installé qu'une seule et unique fois sur un même serveur"
    ],
    "a": 0,
    "exp": "Un rôle correspond à une fonction serveur majeure (contrôleur de domaine, serveur DHCP, serveur de fichiers...), tandis qu'une fonctionnalité est un composant additionnel (ex: sauvegarde Windows Server, .NET Framework) qui vient souvent en support d'un ou plusieurs rôles."
  },
  {
    "cat": "Windows Server & AD",
    "type": "qcm",
    "q": "Quelles sont les deux actions à effectuer généralement juste après l'installation de Windows Server ?",
    "c": [
      "configurer une adresse IP statique et renommer le serveur",
      "installer un antivirus et désactiver le pare-feu",
      "créer un compte administrateur et désinstaller Windows Update",
      "activer le Wi-Fi et désactiver l'IPv6"
    ],
    "a": 0,
    "exp": "Un serveur a besoin d'une adresse IP fixe pour être joignable de façon stable, et d'un nom explicite pour être facilement identifié sur le réseau : ce sont typiquement les deux premières étapes avant l'installation des rôles souhaités."
  },
  {
    "cat": "Windows Server & AD",
    "type": "text",
    "q": "Quelle solution intégrée à Windows Server permet de sauvegarder le système sans outil tiers ?",
    "reponse": "Windows Server Backup",
    "exp": "Windows Server Backup est la fonctionnalité native de Windows Server qui permet de sauvegarder le système, les volumes ou des données spécifiques, sans nécessiter de logiciel tiers.",
    "accept": [
      "wbadmin",
      "windows server backup (wsb)"
    ]
  },
  {
    "cat": "Linux",
    "type": "qcm",
    "q": "Quelle commande permet de lister les droits d'un fichier en ligne de commande ?",
    "c": [
      "ls -l",
      "cat",
      "pwd",
      "top"
    ],
    "a": 0,
    "exp": "L'option -l de ls affiche un format détaillé incluant le type de fichier, les permissions (rwx), le propriétaire, le groupe, la taille et la date de modification."
  },
  {
    "cat": "Linux",
    "type": "qcm",
    "q": "Que signifie la chaîne de droits « drwxr-xr-- » affichée par ls -l ?",
    "c": [
      "un répertoire avec lecture/écriture/exécution pour le propriétaire, lecture/exécution pour le groupe, lecture seule pour les autres",
      "un fichier classique accessible en lecture et en écriture par absolument tout le monde",
      "un lien symbolique pointant vers un autre répertoire, accessible uniquement en lecture",
      "un fichier caché ne disposant d'aucun droit pour qui que ce soit"
    ],
    "a": 0,
    "exp": "Le premier caractère (d) indique un répertoire, puis chaque bloc de 3 caractères correspond respectivement au propriétaire (rwx), au groupe (r-x) et aux autres (r--) : ici le propriétaire a tous les droits, le groupe peut lire et parcourir, et les autres ne peuvent que lire."
  },
  {
    "cat": "Linux",
    "type": "qcm",
    "q": "Que signifie chmod 751 appliqué à un fichier ?",
    "c": [
      "propriétaire : rwx, groupe : r-x, autres : x seul",
      "propriétaire : rwx, groupe : rwx, autres : rwx",
      "propriétaire : r--, groupe : r--, autres : r--",
      "le fichier devient inexécutable pour tout le monde"
    ],
    "a": 0,
    "exp": "En notation octale, 7 = rwx (propriétaire), 5 = r-x (groupe) et 1 = --x (autres) : seuls les autres n'ont que le droit d'exécution, sans pouvoir lire ni modifier le fichier."
  },
  {
    "cat": "Linux",
    "type": "qcm",
    "q": "À quoi sert la commande sudo sous Linux ?",
    "c": [
      "exécuter une commande avec les droits d'un autre utilisateur de façon tracée",
      "afficher en temps réel la liste des processus actifs sur la machine",
      "chiffrer un fichier avant de l'envoyer sur le réseau",
      "planifier l'exécution récurrente d'une tâche à intervalle régulier"
    ],
    "a": 0,
    "exp": "sudo (substitute user do) permet à un utilisateur autorisé d'exécuter ponctuellement une commande avec des droits élevés, en laissant une trace dans les journaux, plutôt que de se connecter directement en root en permanence."
  },
  {
    "cat": "Linux",
    "type": "qcm",
    "q": "Qu'est-ce que le compte root sous Linux ?",
    "c": [
      "le super-utilisateur disposant de tous les droits sur le système",
      "un compte de service réseau",
      "un groupe d'utilisateurs standards",
      "un compte désactivé par défaut sur toutes les distributions"
    ],
    "a": 0,
    "exp": "root est le compte administrateur historique de Linux : il peut lire, modifier ou supprimer n'importe quel fichier et exécuter n'importe quelle commande, ce qui en fait un compte à manipuler avec précaution (d'où l'usage recommandé de sudo au quotidien)."
  },
  {
    "cat": "Linux",
    "type": "qcm",
    "q": "Quel est le rôle du fichier /etc/fstab ?",
    "c": [
      "définir les systèmes de fichiers à monter automatiquement au démarrage",
      "stocker les mots de passe des utilisateurs",
      "configurer l'adresse IP de la machine",
      "lister les paquets installés"
    ],
    "a": 0,
    "exp": "/etc/fstab (file systems table) décrit quels périphériques ou partitions doivent être montés, à quel point de montage, avec quel système de fichiers et quelles options, dès le démarrage du système."
  },
  {
    "cat": "Linux",
    "type": "text",
    "q": "Quelle commande permet de consulter en temps réel les nouvelles lignes ajoutées à un fichier de log ?",
    "reponse": "tail -f",
    "exp": "tail -f suit un fichier en continu et affiche chaque nouvelle ligne au fur et à mesure qu'elle est écrite, ce qui est très utile pour surveiller un log pendant qu'un service fonctionne.",
    "accept": [
      "tail -f nomfichier"
    ]
  },
  {
    "cat": "Linux",
    "type": "qcm",
    "q": "Quelle commande permet de redémarrer un service système sous une distribution utilisant systemd ?",
    "c": [
      "systemctl restart nom_du_service",
      "service stop nom_du_service",
      "kill -9 nom_du_service",
      "apt restart nom_du_service"
    ],
    "a": 0,
    "exp": "systemctl est l'outil de gestion des services sous systemd (init utilisé par la majorité des distributions modernes) : restart arrête puis relance immédiatement le service concerné."
  },
  {
    "cat": "Linux",
    "type": "qcm",
    "q": "Comment configure-t-on généralement une adresse IP statique sur une distribution Linux moderne (Debian/Ubuntu récents) ?",
    "c": [
      "via un fichier de configuration réseau ou l'outil nmcli/nmtui",
      "uniquement via une interface graphique Windows",
      "via le fichier /etc/passwd",
      "cela n'est pas possible sous Linux"
    ],
    "a": 0,
    "exp": "Les distributions récentes utilisent des outils comme netplan (Ubuntu Server) ou NetworkManager (nmcli/nmtui) pour définir une configuration réseau statique persistante, en remplacement des anciens fichiers /etc/network/interfaces."
  },
  {
    "cat": "Linux",
    "type": "qcm",
    "q": "Qu'est-ce qu'un inode sous Linux ?",
    "c": [
      "une structure qui stocke les métadonnées d'un fichier mais pas son nom",
      "le nom du fichier tel qu'il apparaît lorsqu'on utilise la commande ls",
      "un type particulier de partition réservé aux systèmes de fichiers journalisés",
      "un identifiant utilisé pour désigner une machine sur le réseau"
    ],
    "a": 0,
    "exp": "Chaque fichier est associé à un inode qui contient ses métadonnées (permissions, propriétaire, taille, dates, pointeurs vers les blocs de données), mais pas son nom : le nom n'est qu'une entrée dans le répertoire qui pointe vers cet inode, ce qui explique pourquoi plusieurs noms peuvent pointer vers le même inode (liens physiques)."
  },
  {
    "cat": "Linux",
    "type": "qcm",
    "q": "Quelle est la différence entre un lien symbolique et un lien physique (hard link) sous Linux ?",
    "c": [
      "le lien symbolique pointe vers un chemin et casse si la cible est déplacée, le lien physique pointe vers le même inode que le fichier original",
      "ce sont deux appellations différentes désignant en réalité un seul et même mécanisme de liaison",
      "seul le lien physique est capable de traverser plusieurs systèmes de fichiers différents sur le disque",
      "un lien symbolique ne peut jamais désigner un répertoire entier, seulement un fichier unique"
    ],
    "a": 0,
    "exp": "Un lien physique partage directement le même inode que le fichier d'origine : supprimer l'un des deux noms ne détruit pas les données tant qu'il en reste un. Un lien symbolique est un simple raccourci vers un chemin : si la cible est déplacée ou supprimée, le lien devient invalide. À l'inverse du 3e distracteur, c'est le lien symbolique qui peut traverser les systèmes de fichiers, pas le lien physique."
  },
  {
    "cat": "Linux",
    "type": "qcm",
    "q": "Qu'est-ce qu'un serveur LAMP ?",
    "c": [
      "une pile logicielle Linux, Apache, MySQL/MariaDB, PHP pour héberger des applications web",
      "un serveur dédié exclusivement à l'envoi et la réception d'emails",
      "un service qui sauvegarde automatiquement les données d'un serveur web",
      "un protocole utilisé pour chiffrer les échanges entre un client et un serveur"
    ],
    "a": 0,
    "exp": "LAMP est l'acronyme d'une combinaison classique pour héberger des sites et applications web dynamiques : Linux comme OS, Apache comme serveur web, MySQL (ou MariaDB) comme base de données, et PHP comme langage de traitement côté serveur."
  },
  {
    "cat": "Linux",
    "type": "qcm",
    "q": "Qu'est-ce que GLPI ?",
    "c": [
      "un logiciel open-source de gestion de parc informatique et de tickets",
      "un langage de script propre aux distributions Linux, utilisé pour automatiser des tâches",
      "un protocole réseau chargé de sécuriser les échanges entre plusieurs machines",
      "un système de fichiers spécifique utilisé par certaines distributions Linux"
    ],
    "a": 0,
    "exp": "GLPI (Gestionnaire Libre de Parc Informatique) est un outil ITSM open-source très utilisé qui combine gestion des tickets, inventaire du parc matériel/logiciel et base de connaissances."
  },
  {
    "cat": "Réseaux & IPv4",
    "type": "order",
    "q": "Remets dans l'ordre les 7 couches du modèle OSI comme sur un schéma classique : position 1 = la couche la plus haute (tout en haut), position 7 = la couche la plus basse (tout en bas).",
    "items": [
      "Application",
      "Présentation",
      "Session",
      "Transport",
      "Réseau",
      "Liaison de données",
      "Physique"
    ],
    "exp": "Sur un schéma classique du modèle OSI, on dessine la pile avec la couche Application en haut et la couche Physique tout en bas (les données descendent la pile pour être transmises, puis remontent côté récepteur). En partant du haut : Application (protocoles des logiciels : HTTP, DNS...), Présentation (format des données), Session (ouverture/fermeture des échanges), Transport (fiabilité, TCP/UDP), Réseau (adresses IP et routage), Liaison de données (trames et adresses MAC), Physique (signaux électriques/optiques) tout en bas."
  },
  {
    "cat": "Réseaux & IPv4",
    "type": "order",
    "q": "Remets dans l'ordre les 4 couches du modèle TCP/IP comme sur un schéma classique : position 1 = la couche la plus haute (tout en haut), position 4 = la couche la plus basse (tout en bas).",
    "items": [
      "Application",
      "Transport",
      "Internet",
      "Accès réseau (ou Liaison)"
    ],
    "exp": "Comme pour l'OSI, on dessine le modèle TCP/IP avec la couche Application en haut et la couche d'Accès réseau tout en bas. C'est une version simplifiée de l'OSI en 4 couches : Application regroupe les couches Session + Présentation + Application de l'OSI (HTTP, DNS, FTP...), Transport reste identique (TCP/UDP), Internet correspond à la couche Réseau (adressage IP, routage), et Accès réseau regroupe les couches Physique + Liaison de l'OSI tout en bas. C'est ce modèle, plus proche de l'implémentation réelle, qui est utilisé sur Internet."
  },
  {
    "cat": "Réseaux & IPv4",
    "type": "match",
    "q": "Relie chaque couche du modèle TCP/IP à la ou les couches OSI qu'elle regroupe.",
    "pairs": [
      {
        "l": "Accès réseau (TCP/IP)",
        "r": "Physique + Liaison de données (OSI)"
      },
      {
        "l": "Internet (TCP/IP)",
        "r": "Réseau (OSI)"
      },
      {
        "l": "Transport (TCP/IP)",
        "r": "Transport (OSI)"
      },
      {
        "l": "Application (TCP/IP)",
        "r": "Session + Présentation + Application (OSI)"
      }
    ],
    "exp": "Le modèle TCP/IP condense les 7 couches OSI en 4 blocs plus pratiques : Accès réseau fusionne Physique et Liaison, Internet correspond à la couche Réseau, Transport reste une couche à part entière identique dans les deux modèles, et Application regroupe les 3 couches hautes de l'OSI (Session, Présentation, Application) qui sont rarement distinguées dans les protocoles réels."
  },
  {
    "cat": "Réseaux & IPv4",
    "type": "text",
    "q": "Que signifie l'acronyme OSI ?",
    "reponse": "Open Systems Interconnection",
    "exp": "OSI (Open Systems Interconnection) est un modèle de référence normalisé décrivant en 7 couches comment des systèmes ouverts et hétérogènes peuvent communiquer entre eux.",
    "accept": [
      "interconnexion de systemes ouverts",
      "interconnexion de systèmes ouverts"
    ],
    "acceptedAnswers": [
      "open systems interconnection",
      "interconnexion de systemes ouverts",
      "interconnexion de systèmes ouverts"
    ],
    "displayAnswers": [
      "Open Systems Interconnection"
    ]
  },
  {
    "cat": "Réseaux & IPv4",
    "type": "match",
    "q": "Relie chaque équipement réseau à son comportement.",
    "pairs": [
      {
        "l": "Hub",
        "r": "diffuse toutes les trames reçues sur tous les ports, sans intelligence"
      },
      {
        "l": "Switch",
        "r": "commute les trames uniquement vers le port correspondant à l'adresse MAC"
      },
      {
        "l": "Routeur",
        "r": "achemine les paquets entre réseaux différents selon leur adresse IP"
      }
    ],
    "exp": "Le hub est un simple répéteur électrique de couche 1, sans aucune intelligence : il envoie tout à tout le monde. Le switch (couche 2) apprend les adresses MAC connectées à chaque port et n'envoie la trame qu'au bon destinataire. Le routeur (couche 3) relie des réseaux IP différents et choisit le meilleur chemin selon sa table de routage."
  },
  {
    "cat": "Réseaux & IPv4",
    "type": "qcm",
    "q": "Qu'est-ce qu'une adresse MAC ?",
    "c": [
      "un identifiant physique unique attribué à une carte réseau, utilisé au niveau de la couche 2",
      "une adresse logique attribuée temporairement par un serveur DHCP",
      "le nom d'hôte associé à une machine sur le réseau",
      "un numéro de port utilisé pour identifier une application réseau"
    ],
    "a": 0,
    "exp": "L'adresse MAC (Media Access Control) est gravée (en théorie) sur la carte réseau à sa fabrication et sert à identifier un équipement au sein d'un même segment local, indépendamment de toute adresse IP attribuée ensuite."
  },
  {
    "cat": "Réseaux & IPv4",
    "type": "qcm",
    "q": "Qu'est-ce qu'une table ARP ?",
    "c": [
      "une table de correspondance entre adresses IP et adresses MAC connues par une machine",
      "la liste complète des routes actuellement connues par un routeur",
      "la liste de tous les ports actuellement ouverts sur un pare-feu",
      "la liste des baux d'adresses IP actuellement actifs sur le serveur DHCP"
    ],
    "a": 0,
    "exp": "Le protocole ARP (Address Resolution Protocol) permet à une machine de retrouver l'adresse MAC correspondant à une adresse IP sur le même réseau local, et de la garder en cache dans sa table ARP pour éviter de la redemander à chaque paquet."
  },
  {
    "cat": "Réseaux & IPv4",
    "type": "qcm",
    "q": "Qu'est-ce qu'une table de commutation (table CAM) sur un switch ?",
    "c": [
      "une table associant les adresses MAC connues aux ports du switch, pour éviter la diffusion inutile des trames",
      "la liste de l'ensemble des VLAN actuellement configurés sur le switch",
      "la table de routage IP utilisée par le switch pour acheminer les paquets",
      "la liste des utilisateurs autorisés à administrer le switch à distance"
    ],
    "a": 0,
    "exp": "En observant les trames qui traversent chaque port, le switch construit dynamiquement une table associant chaque adresse MAC au port sur lequel elle a été vue, ce qui lui permet ensuite d'envoyer directement une trame au bon port plutôt que de la diffuser partout."
  },
  {
    "cat": "Réseaux & IPv4",
    "type": "qcm",
    "q": "Quelle est une différence majeure entre IPv4 et IPv6 ?",
    "c": [
      "IPv6 utilise des adresses sur 128 bits contre 32 bits pour IPv4, offrant un espace d'adressage bien plus vaste",
      "IPv6 est une version plus ancienne d'IPv4 qui n'est plus du tout utilisée aujourd'hui",
      "IPv4 permet le routage sur Internet alors qu'IPv6 reste limité aux réseaux locaux",
      "IPv6 ne permet pas de découper l'espace d'adressage en plusieurs sous-réseaux"
    ],
    "a": 0,
    "exp": "IPv4 code ses adresses sur 32 bits (environ 4,3 milliards d'adresses), un espace aujourd'hui saturé, alors qu'IPv6 utilise 128 bits, offrant un nombre d'adresses colossal et simplifiant certains mécanismes comme l'auto-configuration."
  },
  {
    "cat": "Réseaux & IPv4",
    "type": "qcm",
    "q": "À quoi sert le masque de sous-réseau ?",
    "c": [
      "à distinguer, dans une adresse IP, la partie réseau de la partie hôte",
      "à chiffrer les échanges réseau",
      "à attribuer dynamiquement des adresses IP",
      "à filtrer les ports ouverts sur une machine"
    ],
    "a": 0,
    "exp": "Le masque indique combien de bits de l'adresse IP identifient le réseau et combien identifient l'hôte au sein de ce réseau : c'est ce qui permet à une machine de savoir si une autre IP est sur son réseau local ou doit être jointe via la passerelle."
  },
  {
    "cat": "Réseaux & IPv4",
    "type": "qcm",
    "q": "Qu'est-ce qu'une passerelle par défaut (default gateway) ?",
    "c": [
      "l'adresse à laquelle une machine envoie le trafic destiné à un réseau différent du sien",
      "l'adresse utilisée pour diffuser un message à toutes les machines du réseau local",
      "l'adresse du serveur chargé de résoudre les noms de domaine sur le réseau",
      "l'adresse matérielle du tout premier commutateur rencontré sur le réseau"
    ],
    "a": 0,
    "exp": "Quand une machine doit joindre une IP qui n'est pas dans son propre réseau (selon le masque), elle envoie le paquet à sa passerelle par défaut, généralement un routeur, chargé de l'acheminer vers la bonne destination."
  },
  {
    "cat": "Réseaux & IPv4",
    "type": "qcm",
    "q": "Qu'est-ce que LDAP ?",
    "c": [
      "un protocole d'accès à un annuaire pour interroger ou modifier ses objets",
      "un protocole utilisé pour envoyer et recevoir des emails entre serveurs de messagerie",
      "un protocole permettant de transférer des fichiers volumineux entre deux machines",
      "un protocole dédié à la supervision et à la métrologie des équipements réseau"
    ],
    "a": 0,
    "exp": "LDAP (Lightweight Directory Access Protocol) permet à des applications ou services d'interroger ou de modifier les objets d'un annuaire hiérarchique, comme les utilisateurs et groupes stockés dans Active Directory."
  },
  {
    "cat": "Réseaux & IPv4",
    "type": "qcm",
    "q": "Quelle est la différence entre un port de switch en mode Access et un port en mode Trunk (802.1Q) ?",
    "c": [
      "un port Access appartient à un seul VLAN, un port Trunk transporte plusieurs VLAN en les identifiant par un tag",
      "un port Trunk ne peut relier que deux switches strictement identiques",
      "un port Access est toujours plus rapide qu'un port Trunk",
      "il n'existe aucune différence pratique entre les deux"
    ],
    "a": 0,
    "exp": "Un port Access relie typiquement un poste utilisateur et n'appartient qu'à un seul VLAN, sans tag. Un port Trunk relie des équipements réseau entre eux (switch à switch, switch à routeur) et transporte le trafic de plusieurs VLAN en ajoutant un tag 802.1Q à chaque trame pour indiquer son VLAN d'origine."
  },
  {
    "cat": "Réseaux & IPv4",
    "type": "qcm",
    "q": "Qu'est-ce que le NAT ?",
    "c": [
      "une technique qui traduit des adresses IP privées en une ou plusieurs adresses IP publiques",
      "un protocole dédié au chiffrement des échanges entre deux machines du réseau",
      "une méthode qui attribue dynamiquement une adresse IP à chaque nouvelle machine",
      "un mécanisme de détection des tentatives d'intrusion sur le réseau"
    ],
    "a": 0,
    "exp": "Le NAT permet à des machines utilisant des adresses privées (non routables sur Internet) de communiquer avec l'extérieur en faisant traduire leur adresse par un routeur/pare-feu disposant d'une ou plusieurs adresses publiques."
  },
  {
    "cat": "Réseaux & IPv4",
    "type": "qcm",
    "q": "Quelle est la différence entre le NAT statique et le PAT (Port Address Translation) ?",
    "c": [
      "le NAT statique associe une IP privée à une IP publique fixe, le PAT partage une seule IP publique entre plusieurs machines en distinguant les flux par les ports",
      "le PAT ne peut fonctionner que sur des réseaux utilisant exclusivement IPv6",
      "le NAT statique consomme moins d'adresses IP publiques que le PAT pour un même nombre de machines",
      "ce sont deux appellations différentes pour un seul et même mécanisme de traduction"
    ],
    "a": 0,
    "exp": "Le NAT statique consomme une adresse publique par machine traduite (relation 1 pour 1), tandis que le PAT (souvent appelé NAT overload) permet à de nombreuses machines internes de partager une seule adresse publique, en distinguant leurs flux grâce à des numéros de port différents."
  },
  {
    "cat": "Réseaux & IPv4",
    "type": "qcm",
    "q": "Quelle est la différence entre les cartes réseau virtuelles Bridged, NAT et Host-Only dans un hyperviseur de type 2 ?",
    "c": [
      "Bridged place la VM directement sur le réseau physique, NAT la fait passer par la traduction d'adresse de l'hôte, Host-Only l'isole dans un réseau privé avec l'hôte uniquement",
      "les trois modes offrent systématiquement exactement le même niveau d'accès au réseau physique et à Internet",
      "seul le mode Host-Only permet à la machine virtuelle d'accéder à Internet comme une machine physique",
      "le mode Bridged isole complètement la VM du réseau physique, exactement comme le fait le mode Host-Only"
    ],
    "a": 0,
    "exp": "En mode Bridged, la VM obtient une adresse sur le réseau physique comme une machine à part entière. En mode NAT, elle accède à Internet via la traduction d'adresse effectuée par l'hôte, sans être visible du réseau physique. En Host-Only, elle ne peut communiquer qu'avec l'hôte et les autres VM du même réseau virtuel, sans accès extérieur."
  },
  {
    "cat": "Réseaux & IPv4",
    "type": "qcm",
    "q": "Qu'est-ce qu'un routage statique ?",
    "c": [
      "des routes configurées manuellement par un administrateur, qui ne s'adaptent pas automatiquement aux changements du réseau",
      "un routage qui s'adapte automatiquement en fonction de la charge du réseau",
      "un mode de routage utilisé exclusivement dans les réseaux fonctionnant en IPv6",
      "un routage entièrement géré par le service DHCP du réseau"
    ],
    "a": 0,
    "exp": "Une route statique est saisie manuellement dans la table de routage et reste fixe tant qu'elle n'est pas modifiée : simple à mettre en place sur un petit réseau stable, elle devient vite difficile à maintenir si la topologie change souvent."
  },
  {
    "cat": "Réseaux & IPv4",
    "type": "qcm",
    "q": "Qu'est-ce qu'un routage dynamique, et quel protocole peut-on citer ?",
    "c": [
      "des routes apprises et mises à jour automatiquement entre routeurs, via un protocole comme OSPF ou RIP",
      "des routes figées qu'il faut reconfigurer manuellement à chaque panne",
      "un protocole de chiffrement des échanges entre routeurs",
      "un service qui attribue les adresses IP dynamiquement"
    ],
    "a": 0,
    "exp": "Les protocoles de routage dynamique (RIP, OSPF, EIGRP, BGP...) permettent aux routeurs de s'échanger automatiquement leurs tables de routage et de s'adapter aux changements de topologie (panne de lien, ajout d'un réseau) sans intervention manuelle."
  },
  {
    "cat": "Réseaux & IPv4",
    "type": "text",
    "q": "Que signifie l'acronyme CIDR ?",
    "reponse": "Classless Inter-Domain Routing",
    "exp": "Le CIDR (Classless Inter-Domain Routing) a remplacé le système de classes A/B/C rigides par une notation en /préfixe (ex: /24), permettant de découper les réseaux de façon beaucoup plus flexible.",
    "accept": [
      "routage inter-domaine sans classe"
    ],
    "acceptedAnswers": [
      "classless inter-domain routing",
      "routage inter-domaine sans classe"
    ],
    "displayAnswers": [
      "Classless Inter-Domain Routing"
    ]
  },
  {
    "cat": "Réseaux & IPv4",
    "type": "text",
    "q": "Combien de machines peut-on adresser au maximum dans un réseau /24 (adresses utilisables) ?",
    "reponse": "254",
    "exp": "/24 laisse 8 bits pour la partie hôte, soit 256 adresses possibles (2^8) ; on retire l'adresse réseau et l'adresse de broadcast, qui ne peuvent être attribuées à une machine, ce qui laisse 254 adresses utilisables."
  },
  {
    "cat": "Réseaux & IPv4",
    "type": "qcm",
    "q": "Qu'est-ce qu'une adresse de broadcast dans un réseau IPv4 ?",
    "c": [
      "l'adresse qui permet d'envoyer un même message à toutes les machines du réseau local",
      "l'adresse correspondant au tout premier hôte utilisable du réseau",
      "l'adresse attribuée à la passerelle par défaut du réseau local",
      "une adresse réservée en permanence au serveur DNS du réseau"
    ],
    "a": 0,
    "exp": "L'adresse de broadcast est la dernière adresse d'un sous-réseau (tous les bits hôtes à 1) : un paquet envoyé à cette adresse est reçu par toutes les machines du réseau local, ce qui la rend inutilisable pour identifier une machine en particulier."
  },
  {
    "cat": "Réseaux & IPv4",
    "type": "calculation",
    "q": "Quelle est l'adresse réseau correspondant à l'adresse 192.168.1.129/25 ?",
    "fields": [
      {
        "label": "Adresse réseau",
        "answer": "192.168.1.128"
      }
    ],
    "exp": "/25 laisse 7 bits hôtes, soit des blocs de 128 adresses : 0-127 et 128-255 dans le dernier octet. 129 se situe dans le bloc 128-255, donc l'adresse réseau est 192.168.1.128."
  },
  {
    "cat": "Réseaux & IPv4",
    "type": "calculation",
    "q": "Quelle est l'adresse de broadcast correspondant à l'adresse 172.16.0.48/27 ?",
    "fields": [
      {
        "label": "Adresse de broadcast",
        "answer": "172.16.0.63"
      }
    ],
    "exp": "/27 laisse 5 bits hôtes, soit des blocs de 32 adresses : 0-31, 32-63, 64-95... 48 se situe dans le bloc 32-63, donc l'adresse de broadcast (dernière adresse du bloc) est 172.16.0.63."
  },
  {
    "cat": "Réseaux & IPv4",
    "type": "iprandom",
    "q": "Pour l'adresse {ip}/{prefix}, détermine le masque, l'adresse réseau, l'adresse de broadcast et le nombre d'hôtes utilisables.",
    "ask": [
      "mask",
      "network",
      "broadcast",
      "hosts"
    ],
    "exp": "Repère d'abord la taille du bloc (2^(32-préfixe)), puis situe l'adresse donnée dans le bloc auquel elle appartient : le début du bloc est l'adresse réseau, la fin est le broadcast, et le nombre d'hôtes utilisables est la taille du bloc moins 2 (réseau et broadcast exclus)."
  },
  {
    "cat": "Réseaux & IPv4",
    "type": "iprandom",
    "q": "Pour l'adresse {ip}/{prefix}, détermine l'adresse réseau et l'adresse de broadcast.",
    "ask": [
      "network",
      "broadcast"
    ],
    "exp": "Le masque associé au préfixe détermine la taille des blocs d'adresses. L'adresse réseau est la première adresse du bloc contenant l'IP donnée, l'adresse de broadcast en est la dernière."
  },
  {
    "cat": "Réseaux & IPv4",
    "type": "iprandom",
    "q": "Pour l'adresse {ip}/{prefix}, détermine la première et la dernière adresse IP utilisable par une machine.",
    "ask": [
      "first",
      "last"
    ],
    "exp": "La première IP utilisable est toujours l'adresse réseau + 1, et la dernière est l'adresse de broadcast − 1 : ce sont les deux adresses qui encadrent la plage réellement attribuable à des machines."
  },
  {
    "cat": "Réseaux & IPv4",
    "type": "iprandom",
    "q": "Pour l'adresse {ip}/{prefix}, donne le masque en notation décimale et le nombre d'hôtes utilisables.",
    "ask": [
      "mask",
      "hosts"
    ],
    "exp": "Le masque en notation décimale se déduit directement du préfixe (nombre de bits à 1). Le nombre d'hôtes utilisables se calcule avec 2^(bits hôtes) − 2, les deux adresses retirées étant l'adresse réseau et le broadcast."
  },
  {
    "cat": "Réseaux & IPv4",
    "type": "qcm",
    "q": "Quelle est la différence entre le FLSM et le VLSM ?",
    "c": [
      "le FLSM utilise un masque identique pour tous les sous-réseaux, le VLSM permet des masques différents adaptés aux besoins de chaque sous-réseau",
      "le VLSM ne peut être mis en œuvre que sur des réseaux fonctionnant exclusivement en IPv6",
      "le FLSM est une évolution plus récente et plus performante que le VLSM",
      "ce sont deux noms différents désignant strictement le même mode de découpage réseau"
    ],
    "a": 0,
    "exp": "Le FLSM (Fixed Length Subnet Mask) découpe un réseau en sous-réseaux de taille identique, ce qui peut gaspiller des adresses si les besoins sont hétérogènes. Le VLSM (Variable Length Subnet Mask) autorise des masques différents selon les sous-réseaux, pour coller au plus près du nombre de machines réellement nécessaire dans chacun."
  },
  {
    "cat": "Réseaux & IPv4",
    "type": "text",
    "q": "Quel protocole utilise la commande ping pour tester la joignabilité d'un hôte ?",
    "reponse": "ICMP",
    "exp": "ping s'appuie sur des messages ICMP Echo Request / Echo Reply : l'hôte distant qui reçoit une requête Echo répond par un Echo Reply s'il est joignable, ce qui permet de mesurer le temps de trajet aller-retour.",
    "accept": [
      "icmp"
    ]
  },
  {
    "cat": "Virtualisation & Cloud",
    "type": "text",
    "q": "Cite un exemple d'hyperviseur professionnel de type 1 (bare-metal).",
    "reponse": "VMware ESXi",
    "exp": "VMware ESXi et Microsoft Hyper-V (en mode serveur) sont deux hyperviseurs de type 1 courants : ils s'installent directement sur le matériel serveur, sans système d'exploitation hôte intermédiaire.",
    "accept": [
      "esxi",
      "hyper-v",
      "microsoft hyper-v",
      "proxmox",
      "citrix xenserver",
      "kvm"
    ],
    "acceptedAnswers": [
      "vmware esxi",
      "esxi",
      "hyper-v",
      "microsoft hyper-v",
      "proxmox",
      "citrix xenserver",
      "kvm"
    ],
    "displayAnswers": [
      "VMware ESXi",
      "Hyper-V"
    ]
  },
  {
    "cat": "Virtualisation & Cloud",
    "type": "text",
    "q": "Cite un exemple d'hyperviseur de type 2 (installé au-dessus d'un système d'exploitation).",
    "reponse": "VirtualBox",
    "exp": "VirtualBox et VMware Workstation (ou Fusion sur Mac) sont des hyperviseurs de type 2 : ils s'installent comme une application classique sur un OS existant, pratiques pour un usage bureautique ou de test.",
    "accept": [
      "virtualbox",
      "vmware workstation",
      "vmware fusion",
      "parallels desktop"
    ],
    "acceptedAnswers": [
      "virtualbox",
      "vmware workstation",
      "vmware fusion",
      "parallels desktop"
    ],
    "displayAnswers": [
      "VirtualBox",
      "VMware Workstation"
    ]
  },
  {
    "cat": "Virtualisation & Cloud",
    "type": "qcm",
    "q": "Quel est un avantage majeur de la virtualisation pour une entreprise ?",
    "c": [
      "mutualiser le matériel physique pour héberger plusieurs serveurs, réduisant les coûts et la consommation électrique",
      "elle supprime totalement le besoin de mettre en place des sauvegardes",
      "elle rend inutile toute démarche de sécurisation des serveurs hébergés",
      "elle élimine complètement le besoin d'acheter des licences logicielles"
    ],
    "a": 0,
    "exp": "La virtualisation permet d'exécuter plusieurs serveurs (VM) sur un même serveur physique, ce qui réduit le nombre de machines à acheter, entretenir, alimenter et refroidir, tout en facilitant la sauvegarde et la migration des VM."
  },
  {
    "cat": "Virtualisation & Cloud",
    "type": "qcm",
    "q": "Quelle est une limite importante des snapshots en virtualisation ?",
    "c": [
      "ils dégradent les performances et l'espace disque s'ils sont conservés trop longtemps, et ne remplacent pas une vraie sauvegarde",
      "ils sont totalement incompatibles avec la quasi-totalité des hyperviseurs actuels",
      "ils suppriment automatiquement toutes les données présentes sur la VM",
      "ils ne peuvent être créés qu'une seule fois au cours de la vie d'une VM"
    ],
    "a": 0,
    "exp": "Un snapshot conserve les écritures disque depuis sa création dans un fichier différentiel qui grossit avec le temps, ce qui ralentit la VM et consomme de l'espace ; ce n'est qu'un retour arrière rapide, pas une sauvegarde durable et indépendante du disque de production."
  },
  {
    "cat": "Virtualisation & Cloud",
    "type": "qcm",
    "q": "Qu'est-ce que le provisionnement dynamique (thin provisioning) d'un disque virtuel ?",
    "c": [
      "l'espace disque alloué à la VM n'est réellement occupé sur le stockage qu'au fur et à mesure de son utilisation",
      "l'espace disque est immédiatement et intégralement réservé physiquement dès la création",
      "le disque virtuel ne peut jamais être agrandi par la suite",
      "le disque virtuel est automatiquement répliqué sur un autre site"
    ],
    "a": 0,
    "exp": "Contrairement au provisionnement statique (thick) qui réserve tout l'espace disque dès la création, le thin provisioning ne consomme de l'espace réel qu'au fur et à mesure que des données sont écrites, ce qui optimise l'utilisation du stockage mais nécessite de surveiller l'espace disponible pour éviter la saturation."
  },
  {
    "cat": "Virtualisation & Cloud",
    "type": "qcm",
    "q": "Comment gère-t-on généralement les ressources CPU/RAM d'une machine virtuelle ?",
    "c": [
      "via des réservations, limites et parts définies au niveau de l'hyperviseur",
      "uniquement en réinstallant le système d'exploitation de la VM",
      "en modifiant le BIOS physique du serveur hôte",
      "cela ne peut pas être configuré après la création de la VM"
    ],
    "a": 0,
    "exp": "Les hyperviseurs permettent de définir une réservation (minimum garanti), une limite (maximum autorisé) et des parts relatives (priorité en cas de contention) pour le CPU et la RAM de chaque VM, afin d'arbitrer le partage des ressources physiques entre plusieurs VM."
  },
  {
    "cat": "Virtualisation & Cloud",
    "type": "qcm",
    "q": "Qu'est-ce que le Cloud Computing ?",
    "c": [
      "la mise à disposition à la demande de ressources informatiques via Internet",
      "mettre à disposition des ressources informatiques à la demande",
      "partager un espace de stockage sur le réseau interne",
      "protéger les échanges entre plusieurs postes"
    ],
    "a": 0,
    "exp": "Le Cloud Computing consiste à consommer des ressources informatiques (calcul, stockage, logiciels) hébergées par un tiers et accessibles à la demande via Internet, généralement facturées à l'usage plutôt qu'achetées en matériel propre."
  },
  {
    "cat": "Virtualisation & Cloud",
    "type": "match",
    "q": "Relie chaque type de Cloud à sa définition.",
    "pairs": [
      {
        "l": "Cloud privé",
        "r": "infrastructure dédiée à une seule organisation, hébergée en interne ou chez un prestataire"
      },
      {
        "l": "Cloud public",
        "r": "ressources mutualisées entre plusieurs clients chez un fournisseur externe"
      },
      {
        "l": "Cloud hybride",
        "r": "combinaison de ressources privées et publiques interconnectées"
      }
    ],
    "exp": "Le Cloud privé offre plus de contrôle et de confidentialité car dédié à une seule organisation ; le Cloud public mutualise l'infrastructure entre de nombreux clients pour réduire les coûts ; le Cloud hybride combine les deux, par exemple en gardant les données sensibles en interne tout en externalisant certains services."
  },
  {
    "cat": "Virtualisation & Cloud",
    "type": "qcm",
    "q": "À quoi servent les outils invités (VMware Tools / Guest Additions) installés dans une VM ?",
    "c": [
      "améliorer les performances graphiques/réseau et faciliter les échanges entre l'hôte et la VM",
      "chiffrer automatiquement l'intégralité du disque virtuel de la machine",
      "remplacer purement et simplement le système d'exploitation installé dans la VM",
      "sauvegarder automatiquement la VM chaque jour à heure fixe"
    ],
    "a": 0,
    "exp": "Ces outils installent des pilotes optimisés pour l'environnement virtuel (affichage, réseau, stockage) et ajoutent des fonctionnalités de confort comme le partage du presse-papier ou de dossiers entre la machine hôte et la VM."
  },
  {
    "cat": "Bash & PowerShell",
    "type": "qcm",
    "q": "Pourquoi automatiser des tâches répétitives via des scripts ?",
    "c": [
      "gagner du temps, réduire les erreurs humaines et garantir un résultat reproductible",
      "cela remplace complètement le besoin de tester avant mise en production",
      "cela évite toute nécessité de documentation",
      "cela ne présente aucun avantage pour un administrateur système"
    ],
    "a": 0,
    "exp": "Un script exécute toujours la même suite d'instructions de la même façon, ce qui élimine les oublis ou variations propres à une exécution manuelle répétée, tout en libérant du temps pour des tâches à plus forte valeur ajoutée."
  },
  {
    "cat": "Bash & PowerShell",
    "type": "qcm",
    "q": "Qu'est-ce qu'une variable dans un script ?",
    "c": [
      "un espace nommé qui stocke une valeur pouvant être réutilisée ou modifiée pendant l'exécution",
      "une commande système qui s'exécute immédiatement dès qu'elle est déclarée",
      "un commentaire qui n'a strictement aucun effet sur l'exécution du script",
      "un fichier de configuration entièrement externe et indépendant du script"
    ],
    "a": 0,
    "exp": "Une variable associe un nom à une valeur (texte, nombre, résultat d'une commande...) que le script peut ensuite consulter ou modifier, évitant de répéter la même valeur en dur à plusieurs endroits."
  },
  {
    "cat": "Bash & PowerShell",
    "type": "order",
    "q": "Remets dans l'ordre la logique d'une structure IF...THEN...ELSE.",
    "items": [
      "Évaluer la condition",
      "Si elle est vraie, exécuter le bloc du THEN",
      "Sinon, exécuter le bloc de l'ELSE",
      "Poursuivre l'exécution du reste du script"
    ],
    "exp": "Une structure conditionnelle commence toujours par évaluer une expression logique ; selon que celle-ci est vraie ou fausse, un seul des deux blocs (THEN ou ELSE) est exécuté, avant que le script ne poursuive normalement son cours."
  },
  {
    "cat": "Bash & PowerShell",
    "type": "qcm",
    "q": "À quoi sert une boucle FOR ou WHILE dans un script ?",
    "c": [
      "répéter un bloc d'instructions un nombre de fois défini ou tant qu'une condition reste vraie",
      "répéter un bloc d'instructions un nombre de fois défini ou tant qu'une condition reste vraie",
      "exécuter une seule et unique fois une instruction selon une condition",
      "déclarer une variable accessible depuis l'ensemble du script"
    ],
    "a": 0,
    "exp": "FOR est adaptée quand on connaît à l'avance le nombre d'itérations (ex: parcourir une liste de fichiers), tandis que WHILE répète tant qu'une condition reste vraie, utile quand ce nombre n'est pas connu à l'avance (ex: attendre qu'un service démarre)."
  },
  {
    "cat": "Bash & PowerShell",
    "type": "qcm",
    "q": "Pourquoi est-il important de commenter un script ?",
    "c": [
      "pour expliquer l'intention du code et faciliter sa relecture ou sa maintenance par soi-même ou d'autres",
      "parce que le script ne s'exécute pas sans commentaires",
      "pour ralentir volontairement son exécution",
      "les commentaires sont obligatoires pour la syntaxe du langage"
    ],
    "a": 0,
    "exp": "Un commentaire n'a aucun effet sur l'exécution mais explique le pourquoi d'une instruction ou d'un choix : quelques mois plus tard, ou pour un collègue qui reprend le script, cela évite de devoir redéchiffrer la logique ligne par ligne."
  },
  {
    "cat": "Bash & PowerShell",
    "type": "qcm",
    "q": "Qu'est-ce qu'un argument (ou paramètre) passé à un script ?",
    "c": [
      "une valeur fournie au script au moment de son exécution pour en modifier le comportement",
      "une variable interne non modifiable définie dans le script",
      "le nom du fichier de script lui-même",
      "un commentaire placé en fin de script"
    ],
    "a": 0,
    "exp": "Un argument est transmis au moment du lancement du script (ex: ./script.sh fichier.txt) et permet de le rendre générique et réutilisable, plutôt que de coder en dur une valeur fixe à l'intérieur."
  },
  {
    "cat": "Bash & PowerShell",
    "type": "qcm",
    "q": "Comment planifie-t-on généralement l'exécution automatique d'un script à intervalle régulier ?",
    "c": [
      "via une tâche planifiée",
      "via une tâche planifiée comme cron ou le Planificateur de tâches",
      "en le laissant ouvert dans un terminal en permanence",
      "en le renommant avec l'extension .auto"
    ],
    "a": 0,
    "exp": "cron (Linux) et le Planificateur de tâches (Windows) permettent de déclencher automatiquement un script à des horaires ou intervalles définis, sans intervention manuelle ni terminal ouvert en continu."
  },
  {
    "cat": "Bash & PowerShell",
    "type": "qcm",
    "q": "Quelle est une différence entre un script Bash et un script PowerShell ?",
    "c": [
      "PowerShell manipule des objets structurés via des cmdlets Verbe-Nom, Bash manipule surtout du texte",
      "Bash ne peut pas utiliser de variables",
      "PowerShell ne fonctionne que sur Linux",
      "il n'existe aucune différence de fonctionnement entre les deux"
    ],
    "a": 0,
    "exp": "Bash enchaîne des commandes qui produisent et consomment du texte brut, alors que PowerShell fait circuler de véritables objets .NET entre les cmdlets, ce qui permet par exemple de trier ou filtrer directement sur une propriété sans analyser du texte."
  },
  {
    "cat": "Bash & PowerShell",
    "type": "qcm",
    "q": "Comment tester un script en toute sécurité sans risque pour la production ?",
    "c": [
      "l'exécuter d'abord dans un environnement de test ou une VM isolée, avec des données non sensibles",
      "le tester directement sur les serveurs de production",
      "le partager à l'équipe sans l'avoir lu ni exécuté au préalable",
      "ignorer les tests si le script semble court"
    ],
    "a": 0,
    "exp": "Un environnement de test (ou une VM jetable) permet de vérifier le comportement réel d'un script, y compris ses erreurs potentielles, sans risquer d'endommager des données ou services en production."
  },
  {
    "cat": "Firewall, VPN & sécurité",
    "type": "qcm",
    "q": "Quels sont les principaux types de pare-feu ?",
    "c": [
      "pare-feu sans état, à état et applicatif",
      "pare-feu logiciel uniquement, il n'existe pas de version matérielle",
      "pare-feu IPv4 et pare-feu IPv6 uniquement",
      "pare-feu filaire et pare-feu sans fil"
    ],
    "a": 0,
    "exp": "Un pare-feu stateless filtre chaque paquet isolément selon des règles fixes, un pare-feu stateful suit l'état des connexions en cours pour n'autoriser que le trafic cohérent avec une session légitime, et un pare-feu applicatif (proxy, UTM, WAF) analyse le contenu jusqu'à la couche application."
  },
  {
    "cat": "Firewall, VPN & sécurité",
    "type": "qcm",
    "q": "Sur quelle(s) couche(s) du modèle OSI travaille un pare-feu réseau classique (filtrage par IP/port) ?",
    "c": [
      "couches 3 et 4",
      "couche 7 uniquement",
      "couche 1 uniquement",
      "couche 2 uniquement"
    ],
    "a": 0,
    "exp": "Un pare-feu réseau classique filtre selon l'adresse IP source/destination (couche 3) et le port/protocole de transport (couche 4, TCP/UDP), sans nécessairement analyser le contenu applicatif du trafic."
  },
  {
    "cat": "Firewall, VPN & sécurité",
    "type": "qcm",
    "q": "Sur quelle couche du modèle OSI travaille un pare-feu applicatif (WAF) ?",
    "c": [
      "couche 7",
      "couche 1",
      "couche 2",
      "couche 3 uniquement"
    ],
    "a": 0,
    "exp": "Un pare-feu applicatif analyse le contenu même des requêtes (ex: requêtes HTTP) pour détecter des attaques spécifiques comme l'injection SQL ou le cross-site scripting, ce qui nécessite de comprendre le protocole applicatif utilisé, en couche 7."
  },
  {
    "cat": "Firewall, VPN & sécurité",
    "type": "qcm",
    "q": "Quelle est la différence entre un pare-feu et un proxy ?",
    "c": [
      "le pare-feu filtre le trafic selon des règles réseau, le proxy relaie les requêtes pour le compte des clients",
      "ce sont deux noms différents désignant en réalité le même type d'équipement réseau",
      "le proxy se contente de filtrer le trafic sans jamais relayer aucune requête",
      "le pare-feu ne peut filtrer que le trafic sortant du réseau, jamais le trafic entrant"
    ],
    "a": 0,
    "exp": "Le pare-feu autorise ou bloque du trafic selon des règles (IP, port, état de connexion...), alors qu'un proxy s'intercale activement entre le client et le serveur pour relayer la requête en son nom propre, ce qui permet en plus de mettre en cache du contenu ou de filtrer des URL."
  },
  {
    "cat": "Firewall, VPN & sécurité",
    "type": "qcm",
    "q": "Qu'est-ce qu'un VPN Site-to-Site ?",
    "c": [
      "un tunnel chiffré permanent entre deux réseaux permettant à leurs machines de communiquer comme si elles étaient sur le même réseau",
      "établir un tunnel chiffré entre deux réseaux",
      "connecter un utilisateur à distance à un réseau",
      "sauvegarder des données vers un endroit distant"
    ],
    "a": 0,
    "exp": "Un VPN Site-to-Site relie durablement deux réseaux distants (par exemple le siège et une agence) via un tunnel chiffré établi entre leurs équipements (routeurs/pare-feux), rendant les échanges transparents pour les utilisateurs des deux côtés."
  },
  {
    "cat": "Firewall, VPN & sécurité",
    "type": "qcm",
    "q": "Qu'est-ce qu'un VPN Client-to-Site ?",
    "c": [
      "un tunnel chiffré établi par un utilisateur nomade individuel pour accéder au réseau de l'entreprise",
      "une liaison permanente reliant en continu deux sites distincts de l'entreprise",
      "un protocole utilisé pour établir des routes dynamiques entre routeurs",
      "un mode de chiffrement appliqué directement au disque dur d'un poste"
    ],
    "a": 0,
    "exp": "Un VPN Client-to-Site (ou Remote Access VPN) est initié depuis le poste d'un utilisateur individuel, par exemple en télétravail, pour accéder de façon sécurisée aux ressources internes de l'entreprise via Internet."
  },
  {
    "cat": "Firewall, VPN & sécurité",
    "type": "qcm",
    "q": "Quelle est la différence entre le chiffrement symétrique et asymétrique ?",
    "c": [
      "le symétrique utilise une seule clé partagée pour chiffrer et déchiffrer, l'asymétrique utilise une paire clé publique/clé privée",
      "le chiffrement asymétrique est systématiquement plus rapide à exécuter que le symétrique",
      "le chiffrement symétrique ne peut s'appliquer qu'à du texte, jamais à des fichiers binaires",
      "ce sont deux appellations différentes désignant en réalité le même mécanisme de chiffrement"
    ],
    "a": 0,
    "exp": "Le chiffrement symétrique (ex: AES) est rapide mais nécessite que les deux parties partagent la même clé secrète au préalable. L'asymétrique (ex: RSA) utilise une paire de clés mathématiquement liées (publique/privée) qui évite ce partage préalable, mais est plus lent : les deux sont souvent combinés, par exemple dans TLS."
  },
  {
    "cat": "Firewall, VPN & sécurité",
    "type": "qcm",
    "q": "À quoi sert un certificat SSL/TLS ?",
    "c": [
      "prouver l'identité d'un serveur et permettre l'établissement d'un chiffrement pour sécuriser les échanges",
      "prouver l'identité d'un serveur et sécuriser les échanges",
      "stocker les mots de passe de tous les utilisateurs",
      "remplacer un pare-feu sur le réseau"
    ],
    "a": 0,
    "exp": "Un certificat, délivré par une autorité de certification reconnue, atteste que la clé publique présentée appartient bien au serveur attendu : le navigateur peut ainsi vérifier l'identité du site avant d'établir la connexion chiffrée."
  },
  {
    "cat": "Firewall, VPN & sécurité",
    "type": "qcm",
    "q": "Quelle est la différence entre un IDS et un IPS ?",
    "c": [
      "l'IDS détecte et alerte sur une activité suspecte, l'IPS détecte et bloque activement cette activité",
      "détecter une activité suspecte ou la bloquer activement",
      "assurer la même fonction de protection sur le réseau",
      "ne fonctionner que dans un environnement cloud"
    ],
    "a": 0,
    "exp": "Un IDS (Intrusion Detection System) est passif : il analyse le trafic et génère des alertes en cas de comportement suspect. Un IPS (Intrusion Prevention System) va plus loin en bloquant activement le trafic identifié comme malveillant, en coupure directe sur le flux réseau."
  },
  {
    "cat": "Firewall, VPN & sécurité",
    "type": "qcm",
    "q": "Qu'est-ce que le filtrage MAC sur un point d'accès ou un switch ?",
    "c": [
      "autoriser ou bloquer l'accès au réseau selon l'adresse MAC des appareils, une protection facilement contournable par usurpation",
      "autoriser ou bloquer l'accès selon l'adresse MAC",
      "chiffrer les échanges du réseau",
      "attribuer une adresse IP à chaque appareil"
    ],
    "a": 0,
    "exp": "Le filtrage MAC limite l'accès à une liste blanche (ou noire) d'adresses MAC, mais reste une protection faible car une adresse MAC peut être facilement usurpée (spoofing) par un appareil malveillant qui l'observe sur le réseau."
  },
  {
    "cat": "Firewall, VPN & sécurité",
    "type": "qcm",
    "q": "Qu'est-ce que le filtrage URL ?",
    "c": [
      "bloquer l'accès à certains sites ou catégories de sites web selon une liste ou une politique définie",
      "bloquer l'accès à certains sites selon une politique",
      "se baser uniquement sur l'adresse MAC d'un appareil",
      "chiffrer le trafic HTTPS"
    ],
    "a": 0,
    "exp": "Le filtrage URL (souvent assuré par un proxy ou un pare-feu applicatif) compare les adresses web demandées à des listes ou catégories (réseaux sociaux, sites à risque...) pour autoriser ou bloquer l'accès selon la politique de l'entreprise."
  },
  {
    "cat": "Sauvegardes & restauration",
    "type": "qcm",
    "q": "Que signifie la règle de sauvegarde 3-2-1 ?",
    "c": [
      "conserver 3 copies des données, sur 2 supports différents, dont 1 copie hors site",
      "sauvegarder 3 fois par jour sur 2 serveurs pendant 1 mois",
      "garder les sauvegardes pendant 3 ans sur 2 sites avec 1 seul support",
      "utiliser 3 logiciels de sauvegarde différents en simultané"
    ],
    "a": 0,
    "exp": "La règle 3-2-1 vise à limiter les points de défaillance uniques : 3 copies au total, réparties sur 2 types de support différents (ex: disque et bande ou cloud), dont au moins 1 copie conservée hors du site principal."
  },
  {
    "cat": "Sauvegardes & restauration",
    "type": "qcm",
    "q": "Quelle est la différence entre un PRA et un PCA ?",
    "c": [
      "le PRA organise le redémarrage après un sinistre, le PCA vise à maintenir l'activité pendant l'incident sans interruption majeure",
      "le PRA et le PCA désignent tous les deux exclusivement la sauvegarde régulière des données de l'entreprise",
      "le PCA ne concerne que les sauvegardes de données, sans jamais impliquer d'infrastructure redondante",
      "le PRA est un document obligatoire uniquement pour les établissements bancaires et financiers"
    ],
    "a": 0,
    "exp": "Le PCA cherche à éviter toute interruption de service grâce à des infrastructures redondantes (bascule quasi immédiate), tandis que le PRA accepte une interruption temporaire et décrit les procédures pour restaurer les services après un sinistre, généralement avec un délai plus long."
  },
  {
    "cat": "Sauvegardes & restauration",
    "type": "qcm",
    "q": "Qu'est-ce qu'une sauvegarde hors-ligne (offsite) ?",
    "c": [
      "une copie des données stockée dans un lieu physiquement distinct du site principal, à l'abri d'un sinistre local",
      "une sauvegarde stockée sur le même serveur que les données de production",
      "une sauvegarde qui n'est jamais testée",
      "une sauvegarde uniquement accessible sans connexion Internet"
    ],
    "a": 0,
    "exp": "Conserver une copie hors site (autre bâtiment, autre datacenter, ou cloud) protège contre les sinistres physiques (incendie, dégât des eaux, vol) qui pourraient détruire simultanément les données de production et leurs sauvegardes locales."
  },
  {
    "cat": "Sauvegardes & restauration",
    "type": "qcm",
    "q": "Quelle est la différence entre un NAS et un SAN ?",
    "c": [
      "le NAS partage des fichiers via le réseau, le SAN expose des blocs de stockage comme des disques locaux via un réseau dédié",
      "ce sont deux appellations commerciales différentes pour désigner exactement le même équipement de stockage",
      "un SAN ne peut en aucun cas être utilisé comme cible de sauvegarde pour des serveurs virtualisés",
      "un NAS offre toujours de meilleures performances qu'un SAN, quel que soit l'usage envisagé"
    ],
    "a": 0,
    "exp": "Un NAS (Network Attached Storage) partage des fichiers sur le réseau classique via des protocoles comme SMB ou NFS. Un SAN (Storage Area Network) présente du stockage en mode bloc, via un réseau dédié (souvent Fibre Channel ou iSCSI), comme s'il s'agissait de disques directement connectés au serveur, ce qui offre généralement de meilleures performances pour des usages exigeants comme les bases de données."
  },
  {
    "cat": "Sauvegardes & restauration",
    "type": "qcm",
    "q": "Comment sauvegarde-t-on généralement une machine virtuelle de façon cohérente ?",
    "c": [
      "via un snapshot cohérent puis export/copie de l'image, ou un outil de sauvegarde dédié aux VM",
      "en copiant uniquement le fichier de configuration de la VM, sans ses disques",
      "en éteignant définitivement la VM et en renonçant à la redémarrer ensuite",
      "cela reste impossible tant que la VM continue de fonctionner normalement"
    ],
    "a": 0,
    "exp": "Les solutions de sauvegarde de VM s'appuient généralement sur un snapshot instantané (garantissant la cohérence des données, notamment grâce aux outils invités) pour ensuite copier les fichiers de la VM sans avoir à l'arrêter, contrairement à une copie brute à chaud qui risquerait des données incohérentes."
  },
  {
    "cat": "Sauvegardes & restauration",
    "type": "qcm",
    "q": "Quelle est la différence entre le clonage de disque et une sauvegarde ?",
    "c": [
      "le clonage crée une copie exacte et autonome à un instant T, la sauvegarde permet de restaurer des données ou un état à différents points dans le temps, souvent de façon incrémentale",
      "créer une copie exacte à un instant donné",
      "ne concerner qu'un seul fichier à la fois",
      "ne jamais restaurer plusieurs fichiers ensemble"
    ],
    "a": 0,
    "exp": "Un clone est une image figée et généralement autonome (utilisable telle quelle sur un autre disque), alors qu'une politique de sauvegarde vise à conserver plusieurs points de restauration dans le temps, souvent optimisés en espace grâce à des sauvegardes incrémentales ou différentielles."
  },
  {
    "cat": "Déploiement de postes",
    "type": "qcm",
    "q": "Qu'est-ce que le mastering (ou création d'image) d'un poste ?",
    "c": [
      "préparer un poste de référence configuré puis capturer son état en image pour le dupliquer sur d'autres postes",
      "préparer un poste de référence configuré puis capturer son état en image",
      "installer individuellement chaque poste, un par un, sans utiliser d'image",
      "une technique de sauvegarde reposant uniquement sur des sauvegardes incrémentales"
    ],
    "a": 0,
    "exp": "Le mastering consiste à installer et configurer un poste « modèle » avec l'OS, les logiciels et les paramètres souhaités, puis à en capturer une image (après généralisation avec Sysprep) afin de la redéployer identique sur de nombreux autres postes."
  },
  {
    "cat": "Déploiement de postes",
    "type": "text",
    "q": "Cite une solution open-source de déploiement de postes (alternative à MDT/WDS).",
    "reponse": "Clonezilla",
    "exp": "Clonezilla est un outil open-source de clonage et déploiement d'images disque, souvent utilisé comme alternative légère à MDT/WDS pour des parcs plus modestes ou multi-OS. FOG Project est une autre solution open-source courante.",
    "accept": [
      "fog",
      "fog project"
    ]
  },
  {
    "cat": "Déploiement de postes",
    "type": "qcm",
    "q": "Qu'est-ce qu'un fichier de réponse (Unattend.xml) ?",
    "c": [
      "un fichier qui automatise les réponses aux questions posées pendant l'installation de Windows, pour une installation sans intervention",
      "un fichier qui automatise les réponses pendant l'installation de Windows",
      "un fichier qui conserve une copie de sauvegarde des GPO du domaine",
      "un journal qui recense automatiquement les erreurs d'installation"
    ],
    "a": 0,
    "exp": "Unattend.xml préremplit à l'avance toutes les réponses normalement demandées pendant l'installation de Windows (langue, partitionnement, compte utilisateur...), ce qui permet une installation entièrement automatisée, sans surveillance humaine."
  },
  {
    "cat": "Déploiement de postes",
    "type": "qcm",
    "q": "Comment gère-t-on généralement un parc de terminaux mobiles (smartphones, tablettes) en entreprise ?",
    "c": [
      "via une solution de gestion de flotte mobile permettant de configurer, sécuriser et suivre les appareils à distance",
      "laisser chaque appareil dans sa configuration d'usine, sans aucun suivi particulier",
      "se limiter à des mises à jour manuelles réalisées individuellement poste par poste",
      "s'appuyer uniquement sur le service DHCP déjà en place sur le réseau"
    ],
    "a": 0,
    "exp": "Un MDM (Mobile Device Management) permet d'administrer à distance une flotte d'appareils mobiles : déploiement d'applications, application de politiques de sécurité, effacement à distance en cas de perte ou de vol, etc."
  },
  {
    "cat": "Déploiement de postes",
    "type": "qcm",
    "q": "Qu'est-ce que la post-configuration d'un poste après son déploiement ?",
    "c": [
      "les étapes réalisées après l'image de base : installation d'applications spécifiques, jonction au domaine, paramètres utilisateur...",
      "les étapes réalisées après l'image de base avant la mise en service",
      "la phase de capture de l'image de référence",
      "la procédure qui consiste à retirer le poste du réseau"
    ],
    "a": 0,
    "exp": "Après le déploiement de l'image générique, la post-configuration adapte le poste à son usage réel : jonction au domaine Active Directory, installation de logiciels métiers spécifiques, application des derniers correctifs, personnalisation selon l'utilisateur ou le service concerné."
  },
  {
    "cat": "Wi-Fi",
    "type": "match",
    "q": "Relie chaque norme Wi-Fi à sa bande de fréquence principale.",
    "pairs": [
      {
        "l": "802.11a",
        "r": "5 GHz uniquement"
      },
      {
        "l": "802.11g",
        "r": "2,4 GHz uniquement"
      },
      {
        "l": "802.11n (Wi-Fi 4)",
        "r": "2,4 GHz et 5 GHz"
      },
      {
        "l": "802.11ax (Wi-Fi 6)",
        "r": "2,4 GHz, 5 GHz et 6 GHz selon les variantes"
      }
    ],
    "exp": "Les normes Wi-Fi ont évolué au fil du temps : 802.11a fut la première à utiliser le 5 GHz, 802.11g est restée sur 2,4 GHz avec un débit supérieur au 802.11b, 802.11n a introduit le double-bande, et 802.11ax (Wi-Fi 6/6E) étend la compatibilité jusqu'à la bande 6 GHz sur les variantes 6E, avec de meilleures performances en environnement dense."
  },
  {
    "cat": "Wi-Fi",
    "type": "qcm",
    "q": "Qu'est-ce que le MIMO (Multiple Input Multiple Output) sur un point d'accès Wi-Fi ?",
    "c": [
      "l'utilisation de plusieurs antennes simultanément pour transmettre et recevoir plusieurs flux de données, améliorant débit et portée",
      "l'utilisation de plusieurs antennes simultanément pour transmettre et recevoir plusieurs flux de données",
      "un mode qui limite volontairement la connexion à un seul appareil",
      "un protocole de chiffrement spécifique à la norme Wi-Fi 6"
    ],
    "a": 0,
    "exp": "Le MIMO exploite plusieurs antennes en émission et en réception pour transmettre plusieurs flux de données en parallèle sur le même canal, ce qui augmente le débit global et améliore la robustesse du signal, notamment dans des environnements avec réflexions (murs, obstacles)."
  },
  {
    "cat": "Wi-Fi",
    "type": "qcm",
    "q": "Pourquoi est-il recommandé de désactiver le WPS sur une box ou un point d'accès ?",
    "c": [
      "son code PIN par défaut est vulnérable à des attaques par force brute qui permettent de retrouver la clé Wi-Fi",
      "son code PIN par défaut est vulnérable à des attaques par force brute",
      "il ralentit systématiquement toutes les connexions Wi-Fi",
      "il empêche les mises à jour automatiques du micrologiciel"
    ],
    "a": 0,
    "exp": "Le WPS visait à simplifier la connexion (bouton ou code PIN à 8 chiffres), mais son implémentation PIN comporte une faiblesse structurelle qui permet de le retrouver par force brute en quelques heures, donnant ensuite accès à la clé Wi-Fi réelle : la plupart des guides de sécurisation recommandent de le désactiver."
  },
  {
    "cat": "Wi-Fi",
    "type": "qcm",
    "q": "Pourquoi est-il recommandé de changer le SSID et le mot de passe administrateur par défaut d'une box Internet ?",
    "c": [
      "les valeurs par défaut sont souvent connues ou prévisibles, ce qui facilite une intrusion",
      "les valeurs par défaut sont souvent connues ou prévisibles",
      "cela augmente automatiquement le débit de la connexion",
      "un SSID par défaut empêche toute connexion filaire"
    ],
    "a": 0,
    "exp": "Beaucoup de box utilisent un schéma de nom ou de mot de passe par défaut dérivé du modèle ou de l'adresse MAC, parfois devinable ou disponible dans des bases publiques : les conserver facilite une intrusion sur le réseau ou l'interface d'administration."
  },
  {
    "cat": "Wi-Fi",
    "type": "qcm",
    "q": "Quel est l'intérêt de mettre en place un réseau Wi-Fi « invité » isolé du réseau interne de l'entreprise ?",
    "c": [
      "permettre l'accès Internet aux visiteurs sans exposer les ressources et machines du réseau interne",
      "permettre l'accès Internet aux visiteurs sans exposer les ressources internes",
      "doubler automatiquement le débit disponible pour les employés",
      "remplacer le besoin d'un pare-feu sur le réseau principal"
    ],
    "a": 0,
    "exp": "Un réseau invité isolé (souvent via un VLAN dédié) permet aux visiteurs de naviguer sur Internet sans pouvoir atteindre les serveurs, imprimantes ou postes du réseau interne, limitant la surface d'attaque en cas d'appareil invité compromis."
  },
  {
    "cat": "Wi-Fi",
    "type": "qcm",
    "q": "Qu'apporte l'itinérance rapide 802.11r à un réseau Wi-Fi d'entreprise avec plusieurs bornes ?",
    "c": [
      "elle accélère le changement de borne pour un appareil mobile, utile pour la téléphonie ou les applications sensibles à la latence",
      "elle accélère le changement de borne pour un appareil mobile",
      "elle chiffre automatiquement les échanges avec un niveau supérieur",
      "elle connecte deux points d'accès par câble croisé"
    ],
    "a": 0,
    "exp": "Sans 802.11r, changer de borne (roaming) implique une nouvelle authentification complète, ce qui peut couper un appel en VoIP Wi-Fi. Le 802.11r pré-négocie les clés de sécurité avec les bornes voisines pour rendre la bascule quasi instantanée."
  },
  {
    "cat": "Wi-Fi",
    "type": "qcm",
    "q": "À quoi sert un site survey (étude de couverture) avant de déployer des points d'accès en entreprise ?",
    "c": [
      "cartographier la couverture, les zones d'ombre et les interférences pour positionner les bornes efficacement",
      "cartographier la couverture, les zones d'ombre et les interférences",
      "mesurer uniquement la vitesse de la connexion Internet fournie par l'opérateur",
      "vérifier la compatibilité des imprimantes réseau avec le Wi-Fi"
    ],
    "a": 0,
    "exp": "Un site survey (souvent réalisé avec un outil de heatmap Wi-Fi) mesure la puissance du signal et les interférences dans les locaux réels, ce qui permet de déterminer le nombre de bornes nécessaires et leur emplacement optimal avant l'installation définitive."
  },
  {
    "cat": "Wi-Fi",
    "type": "qcm",
    "q": "Pourquoi peut-il être utile de limiter la puissance d'émission d'un point d'accès en entreprise ?",
    "c": [
      "pour réduire le débordement du signal en dehors des locaux et limiter les interférences avec les bornes voisines",
      "pour réduire le débordement du signal en dehors des locaux et limiter les interférences",
      "pour économiser la batterie du point d'accès",
      "parce qu'une puissance élevée désactive automatiquement le chiffrement"
    ],
    "a": 0,
    "exp": "Une puissance d'émission trop élevée fait porter le signal au-delà des murs de l'entreprise (risque de captation depuis l'extérieur) et peut créer des interférences avec les bornes voisines dans un déploiement dense : on l'ajuste souvent à la baisse pour ne couvrir que la zone réellement nécessaire."
  },
  {
    "cat": "Wi-Fi",
    "type": "qcm",
    "q": "Que permet la bande des 6 GHz apportée par le Wi-Fi 6E ?",
    "c": [
      "un grand nombre de canaux larges et peu encombrés, avec beaucoup moins d'interférences que le 2,4 et le 5 GHz",
      "un grand nombre de canaux larges et peu encombrés, avec beaucoup moins d'interférences",
      "une portée supérieure à toutes les autres bandes existantes",
      "la compatibilité automatique avec tous les anciens appareils Wi-Fi 4"
    ],
    "a": 0,
    "exp": "La bande 6 GHz ouvre un grand nombre de canaux larges non utilisés par les équipements plus anciens (peu d'interférences avec le Wi-Fi 4/5 ou d'autres appareils comme le Bluetooth), au prix d'une portée plus réduite du fait de la fréquence plus élevée, et nécessite des appareils compatibles Wi-Fi 6E."
  },
  {
    "cat": "Sauvegardes & restauration",
    "type": "match",
    "q": "Relie chaque support de sauvegarde à sa caractéristique principale.",
    "pairs": [
      {
        "l": "Bande magnétique (LTO)",
        "r": "faible coût au To, bien adaptée à l'archivage long terme et à la copie hors ligne"
      },
      {
        "l": "Disque dur / SSD",
        "r": "accès rapide, pratique pour des restaurations fréquentes ou urgentes"
      },
      {
        "l": "Cloud",
        "r": "hors site par nature, pratique pour la règle 3-2-1, dépend d'une connexion Internet"
      }
    ],
    "exp": "Chaque support a ses forces : la bande LTO reste économique pour de gros volumes archivés longtemps et peut être déconnectée physiquement (protection anti-rançongiciel), le disque offre une restauration rapide au prix d'un coût au To plus élevé, et le cloud apporte nativement l'éloignement géographique recherché par la règle 3-2-1, avec une dépendance à la bande passante disponible."
  },
  {
    "cat": "Sauvegardes & restauration",
    "type": "qcm",
    "q": "Pourquoi le RAID ne constitue-t-il pas à lui seul une sauvegarde ?",
    "c": [
      "il protège contre la panne d'un disque mais pas contre une suppression accidentelle, un rançongiciel ou un sinistre qui touche tous les disques à la fois",
      "il protège contre la panne d'un disque mais pas contre une suppression accidentelle ou un sinistre",
      "le RAID est plus fiable qu'une sauvegarde classique",
      "le RAID ralentit trop les serveurs en production"
    ],
    "a": 0,
    "exp": "Le RAID (hors RAID 0) tolère la panne d'un ou plusieurs disques physiques, mais une erreur humaine, un fichier supprimé, un chiffrement par rançongiciel ou un incendie touchant le serveur entier se répercutent identiquement sur tous les disques du RAID : il protège la disponibilité du matériel, pas l'intégrité des données dans le temps."
  },
  {
    "cat": "Sauvegardes & restauration",
    "type": "qcm",
    "q": "Qu'est-ce que la déduplication de données dans un système de sauvegarde ?",
    "c": [
      "une technique qui ne stocke qu'une seule fois les blocs de données identiques répétés, pour réduire l'espace utilisé",
      "une technique qui ne stocke qu'une seule fois les blocs de données identiques répétés",
      "une technique qui chiffre automatiquement chaque sauvegarde",
      "une technique qui supprime automatiquement les sauvegardes les plus anciennes"
    ],
    "a": 0,
    "exp": "La déduplication détecte les blocs de données identiques (souvent présents en de nombreux exemplaires sur un parc de machines similaires) et ne les stocke qu'une seule fois physiquement, ce qui peut réduire considérablement l'espace de stockage nécessaire pour les sauvegardes."
  },
  {
    "cat": "Sauvegardes & restauration",
    "type": "qcm",
    "q": "Qu'est-ce que la fenêtre de sauvegarde (backup window) ?",
    "c": [
      "la période disponible pour exécuter les sauvegardes sans trop impacter l'activité normale du système",
      "la période disponible pour exécuter les sauvegardes sans trop impacter l'activité",
      "le nombre maximal de sauvegardes que l'on peut conserver",
      "le délai entre deux mises à jour du logiciel de sauvegarde"
    ],
    "a": 0,
    "exp": "La fenêtre de sauvegarde est la plage horaire (souvent nocturne) durant laquelle la charge supplémentaire générée par la sauvegarde est acceptable pour les utilisateurs et les systèmes : au-delà de cette fenêtre, la sauvegarde risque de perturber l'activité normale."
  },
  {
    "cat": "Sauvegardes & restauration",
    "type": "qcm",
    "q": "Qu'est-ce que la rotation de sauvegardes « Grand-père - Père - Fils » (GFS) ?",
    "c": [
      "une politique qui conserve des sauvegardes quotidiennes, hebdomadaires et mensuelles avec des durées de rétention différentes",
      "une politique qui conserve des sauvegardes quotidiennes, hebdomadaires et mensuelles",
      "une méthode qui sauvegarde uniquement les trois derniers fichiers modifiés",
      "un protocole de réplication entre trois serveurs distants"
    ],
    "a": 0,
    "exp": "GFS organise la rétention sur plusieurs échelles de temps : les sauvegardes quotidiennes (« fils ») sont conservées peu de temps, les hebdomadaires (« père ») plus longtemps, et les mensuelles (« grand-père ») le plus longtemps, ce qui permet de remonter loin dans le temps sans garder toutes les sauvegardes quotidiennes indéfiniment."
  },
  {
    "cat": "Sauvegardes & restauration",
    "type": "qcm",
    "q": "Quelle est la différence entre une sauvegarde à chaud et une sauvegarde à froid ?",
    "c": [
      "la sauvegarde à chaud se fait pendant que le système ou la base de données continue de fonctionner, la sauvegarde à froid nécessite de l'arrêter au préalable",
      "la sauvegarde à chaud se fait pendant que le système continue de fonctionner",
      "la sauvegarde à froid est toujours plus rapide",
      "la sauvegarde à chaud ne concerne que les serveurs physiques"
    ],
    "a": 0,
    "exp": "Une sauvegarde à chaud (hot backup) s'exécute sans interrompre le service, ce qui nécessite des mécanismes garantissant la cohérence des données en cours d'écriture ; une sauvegarde à froid (cold backup) impose d'arrêter le système ou la base au préalable, plus simple à garantir cohérente mais avec une coupure de service."
  },
  {
    "cat": "Sauvegardes & restauration",
    "type": "text",
    "q": "Quelle commande Linux permet de regrouper un ensemble de fichiers et dossiers dans une seule archive (éventuellement compressée) ?",
    "reponse": "tar",
    "exp": "tar (tape archive) rassemble plusieurs fichiers en une seule archive, souvent combinée à une compression comme gzip (tar.gz), et reste l'outil de référence pour scripter des sauvegardes de fichiers sous Linux.",
    "accept": [
      "tar -czf",
      "gtar"
    ]
  },
  {
    "cat": "Sauvegardes & restauration",
    "type": "qcm",
    "q": "À quoi sert la commande/l'outil rsync couramment utilisé pour les sauvegardes sous Linux ?",
    "c": [
      "synchroniser efficacement des fichiers entre deux emplacements en ne transférant que les différences",
      "synchroniser efficacement des fichiers entre deux emplacements en ne transférant que les différences",
      "chiffrer un disque dur avant sa mise au rebut",
      "planifier automatiquement l'exécution d'un script chaque nuit"
    ],
    "a": 0,
    "exp": "rsync compare la source et la destination et ne transfère que les blocs modifiés, ce qui le rend rapide et économe en bande passante pour synchroniser régulièrement des données vers un serveur de sauvegarde ou un site distant, en local ou via SSH."
  },
  {
    "cat": "Sauvegardes & restauration",
    "type": "qcm",
    "q": "Qu'est-ce qu'un « dump » de base de données dans une stratégie de sauvegarde ?",
    "c": [
      "un export du contenu de la base à un instant donné dans un fichier, utilisable pour la restaurer intégralement",
      "un export du contenu de la base à un instant donné dans un fichier",
      "un fichier journal qui liste uniquement les erreurs du serveur de base",
      "une copie physique du disque dur hébergeant le serveur"
    ],
    "a": 0,
    "exp": "Un dump (souvent via des outils comme mysqldump ou pg_dump) exporte la structure et les données d'une base dans un fichier exploitable pour recréer la base à l'identique, ce qui est plus fiable qu'une simple copie de fichiers pour des bases actives."
  },
  {
    "cat": "Sauvegardes & restauration",
    "type": "qcm",
    "q": "Qu'est-ce qu'une politique de rétention dans une stratégie de sauvegarde ?",
    "c": [
      "la règle qui définit combien de temps chaque sauvegarde est conservée avant d'être supprimée",
      "la règle qui définit combien de temps chaque sauvegarde est conservée",
      "le délai maximal accepté pour restaurer un service après un incident",
      "la liste des personnes autorisées à lancer une sauvegarde manuelle"
    ],
    "a": 0,
    "exp": "La politique de rétention fixe la durée de conservation de chaque sauvegarde (ex : quotidiennes gardées 7 jours, mensuelles gardées 1 an) pour équilibrer la capacité de remonter loin dans le temps et l'espace de stockage disponible, souvent combinée à une rotation type GFS."
  },
  {
    "cat": "Déploiement de postes",
    "type": "qcm",
    "q": "Quelle est la différence entre une application déployée par GPO en mode « assignée » et en mode « publiée » ?",
    "c": [
      "l'application assignée s'installe automatiquement, la publiée apparaît en option dans le panneau d'installation de programmes pour une installation à la demande",
      "l'application assignée s'installe automatiquement, la publiée est proposée à l'utilisateur",
      "la publiée s'installe automatiquement sur l'ensemble des postes",
      "l'assignée ne peut s'installer que manuellement"
    ],
    "a": 0,
    "exp": "En mode assigné, le logiciel s'installe automatiquement (au démarrage pour un ordinateur, à la connexion pour un utilisateur) sans action requise. En mode publié (disponible uniquement pour les utilisateurs), le logiciel apparaît comme optionnel dans le Panneau de configuration, à installer à la demande."
  },
  {
    "cat": "Déploiement de postes",
    "type": "qcm",
    "q": "À quoi sert l'outil USMT (User State Migration Tool) lors d'un remplacement de poste Windows ?",
    "c": [
      "migrer les fichiers et paramètres personnels d'un utilisateur de l'ancien poste vers le nouveau",
      "créer l'image de référence utilisée pour le déploiement",
      "installer automatiquement les pilotes du nouveau matériel",
      "activer en masse les licences Windows sur plusieurs postes"
    ],
    "a": 0,
    "exp": "USMT capture les profils utilisateurs (documents, favoris, paramètres d'applications) sur l'ancien poste puis les restaure sur le nouveau, ce qui évite à l'utilisateur de perdre son environnement de travail lors d'un remplacement ou d'une migration de matériel."
  },
  {
    "cat": "Déploiement de postes",
    "type": "qcm",
    "q": "Qu'est-ce qu'un déploiement « zero-touch » ?",
    "c": [
      "un déploiement entièrement automatisé, du démarrage du poste jusqu'à sa mise à disposition, sans intervention manuelle sur la machine",
      "un déploiement entièrement automatisé, du démarrage du poste jusqu'à sa mise à disposition",
      "un déploiement qui ne nécessite aucune image système",
      "un déploiement réservé aux appareils mobiles uniquement"
    ],
    "a": 0,
    "exp": "Le zero-touch enchaîne automatiquement toutes les étapes (démarrage PXE, application de l'image, pilotes, applications, jonction au domaine) sans qu'un technicien ait à intervenir physiquement sur chaque poste, ce qui est précieux pour déployer un grand nombre de machines rapidement."
  },
  {
    "cat": "Déploiement de postes",
    "type": "qcm",
    "q": "À quoi sert un catalogue d'applications en libre-service (self-service) dans une entreprise ?",
    "c": [
      "permettre aux utilisateurs d'installer eux-mêmes les logiciels dont ils ont besoin, parmi une liste validée par l'IT",
      "permettre aux utilisateurs d'installer eux-mêmes les logiciels dont ils ont besoin",
      "remplacer complètement le service support pour tout type de demande",
      "supprimer le besoin de licences logicielles"
    ],
    "a": 0,
    "exp": "Un catalogue self-service liste des applications pré-approuvées et pré-packagées que l'utilisateur peut installer lui-même en quelques clics, ce qui réduit la charge du support tout en gardant le contrôle de l'IT sur ce qui peut être installé."
  },
  {
    "cat": "Déploiement de postes",
    "type": "qcm",
    "q": "Pourquoi réalise-t-on souvent un déploiement pilote sur un petit groupe avant un déploiement massif ?",
    "c": [
      "pour détecter d'éventuels problèmes de compatibilité ou de configuration sur un périmètre restreint avant de les propager à tout le parc",
      "pour détecter d'éventuels problèmes de compatibilité ou de configuration",
      "parce qu'une réglementation impose de tester tout déploiement sur 5 % du parc",
      "principalement car cela permet d'économiser des licences"
    ],
    "a": 0,
    "exp": "Un pilote sur un groupe représentatif (différents modèles de matériel, différents services) permet de repérer les incompatibilités de pilotes, de logiciels métiers ou de configuration avant qu'elles n'affectent l'ensemble du parc, limitant l'impact d'un problème imprévu."
  },
  {
    "cat": "Déploiement de postes",
    "type": "qcm",
    "q": "Qu'est-ce qu'un plan de rollback dans un projet de déploiement ?",
    "c": [
      "la procédure prévue pour revenir à la configuration précédente si le déploiement pose un problème critique",
      "la procédure prévue pour revenir à la configuration précédente en cas de problème",
      "la liste détaillée des postes encore à déployer",
      "le calendrier prévisionnel détaillant chaque étape du déploiement"
    ],
    "a": 0,
    "exp": "Le rollback est un filet de sécurité : si le nouveau déploiement (image, mise à jour, application) provoque un dysfonctionnement majeur, la procédure de rollback permet de revenir rapidement à l'état antérieur connu et stable plutôt que de rester bloqué en pleine crise."
  },
  {
    "cat": "Déploiement de postes",
    "type": "qcm",
    "q": "Quelle est la différence entre une activation Windows en volume KMS et MAK ?",
    "c": [
      "le KMS nécessite que les postes contactent régulièrement un serveur d'activation interne, le MAK active chaque poste individuellement avec un compteur d'utilisations limité",
      "le MAK ne peut fonctionner que sur des serveurs, jamais sur des postes clients classiques",
      "le KMS active définitivement chaque poste sans jamais avoir besoin d'un nouveau contact avec le serveur d'activation",
      "ce sont deux appellations différentes désignant exactement la même méthode d'activation en volume"
    ],
    "a": 0,
    "exp": "KMS (Key Management Service) active les postes via un serveur interne que chaque machine doit recontacter périodiquement pour rester activée, adapté aux grands parcs. MAK (Multiple Activation Key) active chaque poste individuellement auprès des serveurs Microsoft, avec un nombre d'activations limité, plus adapté à un nombre restreint de postes ou aux machines isolées du réseau interne."
  },
  {
    "cat": "Déploiement de postes",
    "type": "qcm",
    "q": "Pourquoi une image de référence destinée à plusieurs modèles de matériel différents pose-t-elle un défi particulier ?",
    "c": [
      "chaque modèle peut nécessiter des pilotes différents, qu'il faut intégrer ou injecter correctement pour que le poste fonctionne après déploiement",
      "chaque modèle peut nécessiter des pilotes différents",
      "l'image doit être intégralement recréée à chaque version du système",
      "seuls les postes de la même marque peuvent recevoir une image"
    ],
    "a": 0,
    "exp": "Les composants matériels (carte réseau, chipset, carte graphique...) diffèrent d'un modèle à l'autre et nécessitent des pilotes spécifiques : une image « universelle » doit soit embarquer les pilotes de tous les modèles ciblés, soit les injecter dynamiquement au moment du déploiement, sous peine de postes non fonctionnels après l'installation."
  },
  {
    "cat": "Déploiement de postes",
    "type": "text",
    "q": "Quel outil en ligne de commande intégré à Windows permet d'installer et de mettre à jour des logiciels rapidement, à la manière d'un gestionnaire de paquets Linux ?",
    "reponse": "winget",
    "exp": "winget (Windows Package Manager) permet d'installer, mettre à jour ou désinstaller des logiciels via une simple commande, ce qui facilite l'automatisation de la post-configuration d'un poste dans un script.",
    "accept": [
      "windows package manager"
    ]
  },
  {
    "cat": "Virtualisation & Cloud",
    "type": "qcm",
    "q": "Qu'est-ce qu'un cluster de virtualisation avec équilibrage de charge automatique (ex: DRS chez VMware) ?",
    "c": [
      "un groupe d'hôtes physiques qui répartit et déplace automatiquement les VM entre eux pour équilibrer la charge",
      "un groupe d'hôtes physiques qui répartit et déplace automatiquement les VM",
      "un seul serveur surdimensionné qui héberge toutes les VM",
      "un logiciel qui fusionne plusieurs VM en une seule machine"
    ],
    "a": 0,
    "exp": "Un cluster regroupe plusieurs hôtes physiques et permet, via une fonctionnalité comme DRS (Distributed Resource Scheduler), de déplacer automatiquement des VM d'un hôte surchargé vers un hôte moins sollicité, sans intervention manuelle, en s'appuyant souvent sur la migration à chaud."
  },
  {
    "cat": "Virtualisation & Cloud",
    "type": "qcm",
    "q": "Qu'est-ce qu'un datastore dans un environnement de virtualisation ?",
    "c": [
      "un espace de stockage partagé où sont hébergés les fichiers des machines virtuelles, accessible par plusieurs hôtes",
      "un espace de stockage partagé où sont hébergés les fichiers des machines virtuelles",
      "une base de données qui répertorie les utilisateurs autorisés à créer des VM",
      "un type particulier de machine virtuelle dédiée au stockage"
    ],
    "a": 0,
    "exp": "Le datastore est l'espace de stockage (souvent un LUN sur un SAN, un partage NAS ou un disque local) où sont stockés les fichiers des VM (disques virtuels, configuration). Un datastore partagé entre plusieurs hôtes est indispensable pour permettre la migration à chaud et la haute disponibilité."
  },
  {
    "cat": "Virtualisation & Cloud",
    "type": "qcm",
    "q": "Qu'est-ce qu'un switch virtuel (vSwitch) dans un hyperviseur ?",
    "c": [
      "un composant logiciel qui relie les machines virtuelles entre elles et aux cartes réseau physiques de l'hôte, comme le ferait un switch physique",
      "un outil qui bascule automatiquement le trafic réseau entre deux hyperviseurs différents installés côte à côte",
      "une machine virtuelle spécialement dédiée à la surveillance et à l'analyse du trafic réseau",
      "un protocole propriétaire qui remplace entièrement TCP/IP à l'intérieur des machines virtuelles"
    ],
    "a": 0,
    "exp": "Le vSwitch fonctionne comme un commutateur logiciel à l'intérieur de l'hyperviseur : il connecte les cartes réseau virtuelles des VM entre elles et aux cartes réseau physiques de la machine hôte, avec des fonctionnalités proches d'un switch physique (VLAN, agrégation de liens...)."
  },
  {
    "cat": "Virtualisation & Cloud",
    "type": "qcm",
    "q": "Qu'est-ce qu'un template de VM ?",
    "c": [
      "un modèle préconfiguré utilisé pour créer rapidement de nouvelles VM identiques",
      "un modèle préconfiguré utilisé pour créer rapidement de nouvelles VM identiques",
      "un rapport de performance généré automatiquement pour chaque machine virtuelle",
      "un type de licence logiciel réservé aux machines virtuelles"
    ],
    "a": 0,
    "exp": "Un template capture la configuration d'une VM de référence (système, ressources, logiciels de base) pour permettre de déployer rapidement de nouvelles VM cohérentes entre elles, un peu comme une image de référence pour des postes physiques."
  },
  {
    "cat": "Virtualisation & Cloud",
    "type": "qcm",
    "q": "Qu'est-ce qu'une conversion P2V (Physical to Virtual) ?",
    "c": [
      "la transformation d'un serveur physique existant en machine virtuelle équivalente, pour le migrer vers un environnement virtualisé",
      "le passage inverse d'une machine virtuelle existante vers un serveur physique dédié qui lui est propre",
      "la fusion de deux machines virtuelles distinctes en une seule VM regroupant leurs ressources",
      "le changement d'hyperviseur sur un cluster, sans toucher aux machines virtuelles déjà existantes"
    ],
    "a": 0,
    "exp": "La conversion P2V capture le disque et la configuration d'un serveur physique en fonctionnement pour créer une VM équivalente, ce qui permet de migrer d'anciens serveurs physiques vers une infrastructure virtualisée sans réinstaller le système à partir de zéro."
  },
  {
    "cat": "Virtualisation & Cloud",
    "type": "qcm",
    "q": "Qu'est-ce que Kubernetes, souvent cité aux côtés de Docker ?",
    "c": [
      "un outil d'orchestration qui déploie, met à l'échelle et gère automatiquement des conteneurs sur plusieurs machines",
      "un hyperviseur de type 1 concurrent direct de VMware ESXi pour héberger des machines virtuelles",
      "un langage de programmation spécifiquement dédié à l'écriture de scripts de sauvegarde automatisés",
      "un protocole de chiffrement utilisé pour sécuriser les échanges réseau entre conteneurs"
    ],
    "a": 0,
    "exp": "Alors que Docker crée et exécute des conteneurs, Kubernetes orchestre un grand nombre de conteneurs répartis sur plusieurs machines (un cluster) : il gère leur déploiement, leur mise à l'échelle automatique, leur redémarrage en cas de panne et la répartition de charge entre eux."
  },
  {
    "cat": "Virtualisation & Cloud",
    "type": "qcm",
    "q": "Quelle est la différence entre la scalabilité horizontale et verticale dans le cloud ?",
    "c": [
      "la scalabilité horizontale ajoute des instances/serveurs supplémentaires, la verticale augmente les ressources d'une instance existante",
      "la horizontale ajoute des instances supplémentaires, la verticale augmente les ressources d'une instance existante",
      "la verticale ajoute des instances supplémentaires, l'horizontale augmente les ressources d'une seule instance",
      "ce sont deux noms différents pour la même opération de mise à l'échelle"
    ],
    "a": 0,
    "exp": "Monter en charge horizontalement (scale out) consiste à ajouter davantage d'instances en parallèle (utile pour répartir la charge via un load balancer), tandis que monter en charge verticalement (scale up) consiste à augmenter la puissance (CPU, RAM) d'une même instance, ce qui a des limites physiques."
  },
  {
    "cat": "Virtualisation & Cloud",
    "type": "qcm",
    "q": "Qu'est-ce qu'un load balancer dans une architecture cloud ?",
    "c": [
      "un composant qui répartit automatiquement le trafic entrant entre plusieurs serveurs ou instances pour éviter qu'un seul soit surchargé",
      "un outil qui équilibre automatiquement le budget consommé entre plusieurs services cloud",
      "un service qui compresse les données avant de les stocker",
      "un protocole qui chiffre le trafic entre le client et le serveur"
    ],
    "a": 0,
    "exp": "Le répartiteur de charge (load balancer) distribue les requêtes entrantes entre plusieurs instances d'une application, ce qui améliore la disponibilité (bascule automatique si une instance tombe) et permet d'absorber davantage de trafic en ajoutant des instances derrière lui."
  },
  {
    "cat": "Virtualisation & Cloud",
    "type": "qcm",
    "q": "Qu'est-ce que le modèle de responsabilité partagée en sécurité du cloud ?",
    "c": [
      "le fournisseur cloud sécurise l'infrastructure sous-jacente, tandis que le client reste responsable de la sécurité de ses données, configurations et accès",
      "le fournisseur cloud est entièrement responsable de toute la sécurité, y compris les mots de passe des utilisateurs du client",
      "le client est seul responsable de la sécurité physique des datacenters",
      "ce modèle ne s'applique qu'aux offres IaaS, jamais au SaaS"
    ],
    "a": 0,
    "exp": "Dans le cloud, la sécurité se répartit entre le fournisseur (sécurité physique des datacenters, de l'infrastructure, de l'hyperviseur) et le client (configuration sécurisée de ses ressources, gestion des accès, protection de ses données), la frontière exacte variant selon qu'on utilise de l'IaaS, du PaaS ou du SaaS."
  }
];
